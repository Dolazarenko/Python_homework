"""Завдання 4 (Django): CRUD, вибірки, Q, aggregate/annotate, N+1."""
import os
from datetime import date, timedelta

import django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from django.contrib.auth import get_user_model
from django.db import connection, transaction
from django.db.models import Avg, Count, Max, Min, Q
from django.test.utils import CaptureQueriesContext

from library.models import Author, Book, Genre, Loan, ReaderProfile

User = get_user_model()


def h(t):
    print(f'\n=== {t} ===')


# чистимо дані для відтворюваності
for M in (Loan, Book, ReaderProfile, Genre, Author):
    M.objects.all().delete()
User.objects.all().delete()

h('CREATE')
shev = Author.objects.create(full_name='Тарас Шевченко', birth_year=1814, country='Україна')
franko = Author.objects.create(full_name='Іван Франко', birth_year=1856, country='Україна')
orwell = Author.objects.create(full_name='George Orwell', birth_year=1903, country='UK')
poetry = Genre.objects.create(name='Поезія')
novel = Genre.objects.create(name='Роман')
dyst = Genre.objects.create(name='Антиутопія')
sci = Genre.objects.create(name='Науково-популярна', is_fiction=False)
b1 = Book.objects.create(title='Кобзар', isbn='9780000000001', year=1840, copies=5, author=shev)
b2 = Book.objects.create(title='Захар Беркут', isbn='9780000000002', year=1883, copies=2, author=franko)
b3 = Book.objects.create(title='1984', isbn='9780000000003', year=1949, copies=3, author=orwell, language='en')
b4 = Book.objects.create(title='Звіряча ферма', isbn='9780000000004', year=1945, copies=4, author=orwell, language='en')
b1.genres.set([poetry]); b2.genres.set([novel]); b3.genres.set([novel, dyst]); b4.genres.add(dyst)
u = User.objects.create_user('olena', password='pass12345')
reader = ReaderProfile.objects.create(user=u, card_number='LIB-0001', phone='+380501112233')
today = date.today()
Loan.objects.create(reader=reader, book=b1, loaned_at=today - timedelta(days=40), due_at=today - timedelta(days=10))
Loan.objects.create(reader=reader, book=b3, loaned_at=today - timedelta(days=5), due_at=today + timedelta(days=9))
print('Авторів:', Author.objects.count(), '| Книг:', Book.objects.count(), '| Видач:', Loan.objects.count())

h('READ: filter / exclude / Q')
print('filter(year__lt=1900):', list(Book.objects.filter(year__lt=1900)))
print('exclude(language="uk"):', list(Book.objects.exclude(language='uk')))
print('Q OR (Кобзар | рік>1948):', list(Book.objects.filter(Q(title='Кобзар') | Q(year__gt=1948))))
print('Q NOT (не англійські):', list(Book.objects.filter(~Q(language='en'))))
print('Q AND+NOT (автор Orwell, не 1984):', list(Book.objects.filter(Q(author=orwell) & ~Q(title='1984'))))

h('READ: aggregate')
print(Book.objects.aggregate(total=Count('id'), avg_year=Avg('year'), oldest=Min('year'), newest=Max('year')))

h('READ: annotate')
for a in Author.objects.annotate(n_books=Count('books')).order_by('-n_books', 'full_name'):
    print(f'{a.full_name}: {a.n_books} книг')
for g in Genre.objects.annotate(n=Count('books')).filter(n__gt=0).order_by('-n', 'name'):
    print(f'Жанр {g.name}: {g.n}')

h('Зворотні зв\'язки')
print('orwell.books.all():', list(orwell.books.all()))
print('dyst.books.all():', list(dyst.books.all()))
print('u.reader_profile:', u.reader_profile)
print('reader.loans.count():', reader.loans.count())

h('N+1: без оптимізації')
with CaptureQueriesContext(connection) as c1:
    for b in Book.objects.all():
        _ = b.author.full_name
print('Запитів:', len(c1))
h('select_related')
with CaptureQueriesContext(connection) as c2:
    for b in Book.objects.select_related('author'):
        _ = b.author.full_name
print('Запитів:', len(c2))
h('prefetch_related (M2M)')
with CaptureQueriesContext(connection) as c3:
    for b in Book.objects.prefetch_related('genres'):
        _ = [g.name for g in b.genres.all()]
print('Запитів:', len(c3))

h('UPDATE')
n = Book.objects.filter(author=orwell).update(copies=10)
print('Оновлено рядків (update):', n)
b2.title = 'Захар Беркут (вид. 2)'; b2.save(update_fields=['title'])
b2.refresh_from_db(); print('після save():', b2.title)

h('DELETE + політики on_delete')
from django.db.models import ProtectedError
try:
    orwell.delete()
except ProtectedError as e:
    print('PROTECT спрацював: автора з книгами не видалити')
Loan.objects.filter(book=b1).delete()
print('Видалено книгу:', b1.delete())
u.delete()
print('Після видалення User профіль читача каскадно видалено:', ReaderProfile.objects.count() == 0,
      '| видач залишилось:', Loan.objects.count())

h('Атомарність (transaction.atomic)')
try:
    with transaction.atomic():
        Genre.objects.create(name='Тимчасовий')
        Genre.objects.create(name='Поезія')  # unique -> IntegrityError
except Exception as e:
    print('Помилка:', type(e).__name__, '→ відкат; "Тимчасовий" існує?',
          Genre.objects.filter(name='Тимчасовий').exists())
