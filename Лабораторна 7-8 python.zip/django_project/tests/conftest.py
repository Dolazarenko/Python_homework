from datetime import date, timedelta

import pytest
from django.contrib.auth import get_user_model

from library.models import Author, Book, Genre, Loan, ReaderProfile


@pytest.fixture
def user(db):
    return get_user_model().objects.create_user('olena', password='pass12345')


@pytest.fixture
def author(db):
    return Author.objects.create(full_name='Тарас Шевченко', birth_year=1814)


@pytest.fixture
def genre(db):
    return Genre.objects.create(name='Поезія')


@pytest.fixture
def book(author, genre):
    b = Book.objects.create(title='Кобзар', isbn='9780000000001', year=1840, author=author)
    b.genres.add(genre)
    return b


@pytest.fixture
def reader(user):
    return ReaderProfile.objects.create(user=user, card_number='LIB-0001')


@pytest.fixture
def loan(reader, book):
    return Loan.objects.create(reader=reader, book=book,
                               loaned_at=date(2026, 1, 1), due_at=date(2026, 1, 15))


@pytest.fixture
def auth_client(client, user):
    client.force_login(user)
    return client
