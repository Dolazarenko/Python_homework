import pytest
from django.db import IntegrityError, transaction
from django.db.models import ProtectedError

from library.models import Author, Book, Genre, ReaderProfile


def test_book_creation_and_defaults(book):
    assert book.pk is not None
    assert book.copies == 1          # значення за замовчуванням
    assert book.language == 'uk'     # значення за замовчуванням
    assert book.genres.count() == 1  # M2M


def test_str_representations(book, author, genre, reader, loan):
    assert str(book) == 'Кобзар (1840)'
    assert str(author) == 'Тарас Шевченко'
    assert str(genre) == 'Поезія'
    assert str(reader) == 'LIB-0001 (olena)'
    assert str(loan) == 'Кобзар → LIB-0001'


def test_isbn_unique(book, author):
    with pytest.raises(IntegrityError), transaction.atomic():
        Book.objects.create(title='Дубль', isbn=book.isbn, year=2000, author=author)


def test_protect_author_with_books(book, author):
    with pytest.raises(ProtectedError):
        author.delete()
    assert Author.objects.filter(pk=author.pk).exists()


def test_cascade_user_deletes_profile_and_loans(user, reader, loan):
    user.delete()
    assert ReaderProfile.objects.count() == 0
    assert reader.loans.model.objects.count() == 0


def test_one_to_one_reverse_access(user, reader):
    assert user.reader_profile == reader
    with pytest.raises(IntegrityError), transaction.atomic():
        ReaderProfile.objects.create(user=user, card_number='LIB-0002')  # другий профіль


@pytest.mark.parametrize('name, ok', [
    ('Роман', True),
    ('A' * 80, True),      # межа max_length
    ('A' * 81, False),     # перевищення
    ('', False),           # порожнє
])
def test_genre_name_validation(db, name, ok):
    from django.core.exceptions import ValidationError
    genre = Genre(name=name)
    if ok:
        genre.full_clean()
    else:
        with pytest.raises(ValidationError):
            genre.full_clean()


@pytest.mark.parametrize('code, valid', [('uk', True), ('en', True), ('de', True), ('fr', False)])
def test_book_language_choices(author, code, valid):
    from django.core.exceptions import ValidationError
    b = Book(title='T', isbn='1', year=2000, author=author, language=code)
    if valid:
        b.full_clean()
    else:
        with pytest.raises(ValidationError):
            b.full_clean()
