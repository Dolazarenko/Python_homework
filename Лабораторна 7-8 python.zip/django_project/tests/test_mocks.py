from datetime import date
from unittest.mock import MagicMock, patch

import pytest

from library import services


# --- Мок 1: ЗОВНІШНЯ залежність (HTTP до Open Library) ---
@patch('library.services.requests.get')
def test_fetch_book_info_mocks_http(mock_get):
    fake = MagicMock()
    fake.json.return_value = {'ISBN:123': {'title': 'Кобзар', 'number_of_pages': 400}}
    mock_get.return_value = fake

    info = services.fetch_book_info('123')

    assert info == {'title': 'Кобзар', 'pages': 400}
    mock_get.assert_called_once_with(
        services.OPENLIBRARY_URL,
        params={'bibkeys': 'ISBN:123', 'format': 'json', 'jscmd': 'data'},
        timeout=5)
    fake.raise_for_status.assert_called_once_with()


@patch('library.services.requests.get')
def test_fetch_book_info_not_found(mock_get):
    mock_get.return_value.json.return_value = {}
    assert services.fetch_book_info('000') is None
    mock_get.assert_called_once()


# --- Мок 2: ВНУТРІШНЯ/побічна залежність (поточний час) ---
@pytest.mark.parametrize('today, expected', [
    (date(2026, 1, 20), True),    # після due_at -> прострочена
    (date(2026, 1, 15), False),   # межа: у день терміну ще не прострочена
    (date(2026, 1, 10), False),
])
def test_is_loan_overdue_with_mocked_time(loan, today, expected):
    with patch('library.services.timezone.localdate', return_value=today) as mock_today:
        assert services.is_loan_overdue(loan) is expected
        mock_today.assert_called_once_with()


def test_returned_loan_never_overdue_and_clock_not_used(loan):
    loan.returned_at = date(2026, 1, 5)
    with patch('library.services.timezone.localdate') as mock_today:
        assert services.is_loan_overdue(loan) is False
        mock_today.assert_not_called()
