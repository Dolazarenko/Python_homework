import pytest
from django.urls import reverse


def test_book_list_ok_and_content(client, book):
    resp = client.get(reverse('library:book_list'))
    assert resp.status_code == 200
    assert 'library/book_list.html' in [t.name for t in resp.templates]
    assert 'Кобзар' in resp.content.decode()
    assert 'Тарас Шевченко' in resp.content.decode()


def test_book_list_search_no_match(client, book):
    resp = client.get(reverse('library:book_list'), {'q': 'немає такої'})
    assert resp.status_code == 200
    assert 'Книг не знайдено' in resp.content.decode()


def test_book_detail_ok(client, book):
    resp = client.get(reverse('library:book_detail', args=[book.pk]))
    assert resp.status_code == 200
    assert book.isbn in resp.content.decode()


@pytest.mark.parametrize('pk', [0, 99999])
def test_book_detail_404(client, db, pk):
    assert client.get(reverse('library:book_detail', args=[pk])).status_code == 404


def test_my_loans_anonymous_redirects_to_login(client, db):
    resp = client.get(reverse('library:my_loans'))
    assert resp.status_code == 302
    assert resp.url.startswith('/accounts/login/')


def test_my_loans_authenticated_shows_only_own(auth_client, loan, author, django_user_model):
    from datetime import date
    from library.models import Book, Loan, ReaderProfile
    other_user = django_user_model.objects.create_user('other', password='x')
    other_reader = ReaderProfile.objects.create(user=other_user, card_number='LIB-0002')
    other_book = Book.objects.create(title='Чужа книга', isbn='9780000000009', year=2000, author=author)
    Loan.objects.create(reader=other_reader, book=other_book,
                        loaned_at=date(2026, 1, 1), due_at=date(2026, 1, 15))
    resp = auth_client.get(reverse('library:my_loans'))
    assert resp.status_code == 200
    body = resp.content.decode()
    assert 'Кобзар' in body
    assert 'Чужа книга' not in body
