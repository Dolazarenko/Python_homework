from django.urls import path
from . import views

app_name = 'library'
urlpatterns = [
    path('', views.book_list, name='book_list'),
    path('books/<int:pk>/', views.book_detail, name='book_detail'),
    path('my-loans/', views.my_loans, name='my_loans'),
]
