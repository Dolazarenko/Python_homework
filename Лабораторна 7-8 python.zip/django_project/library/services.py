"""Сервіси з зовнішніми та побічними залежностями (об'єкти для мокінгу)."""
import requests
from django.utils import timezone

OPENLIBRARY_URL = 'https://openlibrary.org/api/books'


def fetch_book_info(isbn):
    """Зовнішній HTTP-запит до Open Library. Повертає dict або None."""
    resp = requests.get(OPENLIBRARY_URL,
                        params={'bibkeys': f'ISBN:{isbn}', 'format': 'json', 'jscmd': 'data'},
                        timeout=5)
    resp.raise_for_status()
    data = resp.json().get(f'ISBN:{isbn}')
    if not data:
        return None
    return {'title': data.get('title', ''), 'pages': data.get('number_of_pages')}


def is_loan_overdue(loan):
    """Прострочена, якщо не повернута і due_at < сьогодні (залежить від поточного часу)."""
    if loan.returned_at is not None:
        return False
    return loan.due_at < timezone.localdate()
