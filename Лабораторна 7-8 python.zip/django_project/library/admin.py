from django.contrib import admin
from .models import Author, Book, Genre, Loan, ReaderProfile

for m in (Author, Book, Genre, Loan, ReaderProfile):
    admin.site.register(m)
