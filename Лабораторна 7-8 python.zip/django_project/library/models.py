from django.conf import settings
from django.db import models


class Author(models.Model):
    """Автор книг."""
    full_name = models.CharField('ПІБ', max_length=150, unique=True)
    birth_year = models.PositiveSmallIntegerField('рік народження', null=True, blank=True)
    country = models.CharField('країна', max_length=80, blank=True)

    class Meta:
        ordering = ['full_name']
        verbose_name = 'автор'
        verbose_name_plural = 'автори'

    def __str__(self):
        return self.full_name


class Genre(models.Model):
    """Жанр книги."""
    name = models.CharField('назва', max_length=80, unique=True)
    description = models.TextField('опис', blank=True)
    is_fiction = models.BooleanField('художня література', default=True)

    class Meta:
        ordering = ['name']
        verbose_name = 'жанр'
        verbose_name_plural = 'жанри'

    def __str__(self):
        return self.name


class Book(models.Model):
    """Книга: належить одному автору, має багато жанрів."""
    LANGUAGES = [('uk', 'Українська'), ('en', 'Англійська'), ('de', 'Німецька')]
    title = models.CharField('назва', max_length=200)
    isbn = models.CharField('ISBN', max_length=13, unique=True)
    year = models.PositiveSmallIntegerField('рік видання')
    copies = models.PositiveIntegerField('кількість примірників', default=1)
    language = models.CharField('мова', max_length=2, choices=LANGUAGES, default='uk')
    # Автора з книгами видаляти не можна — PROTECT
    author = models.ForeignKey(Author, on_delete=models.PROTECT,
                               related_name='books', verbose_name='автор')
    genres = models.ManyToManyField(Genre, related_name='books',
                                    blank=True, verbose_name='жанри')

    class Meta:
        ordering = ['title']
        verbose_name = 'книга'
        verbose_name_plural = 'книги'

    def __str__(self):
        return f'{self.title} ({self.year})'


class ReaderProfile(models.Model):
    """Профіль читача: рівно один на користувача (1:1)."""
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                related_name='reader_profile', verbose_name='користувач')
    card_number = models.CharField('номер квитка', max_length=20, unique=True)
    phone = models.CharField('телефон', max_length=20, blank=True)
    registered_at = models.DateField('дата реєстрації', auto_now_add=True)

    class Meta:
        ordering = ['card_number']
        verbose_name = 'профіль читача'
        verbose_name_plural = 'профілі читачів'

    def __str__(self):
        return f'{self.card_number} ({self.user})'


class Loan(models.Model):
    """Видача книги читачеві."""
    reader = models.ForeignKey(ReaderProfile, on_delete=models.CASCADE,
                               related_name='loans', verbose_name='читач')
    # Книгу, що є у видачах, видаляти не можна — зберігаємо історію
    book = models.ForeignKey(Book, on_delete=models.PROTECT,
                             related_name='loans', verbose_name='книга')
    loaned_at = models.DateField('дата видачі')
    due_at = models.DateField('повернути до')
    returned_at = models.DateField('дата повернення', null=True, blank=True)

    class Meta:
        ordering = ['-loaned_at']
        verbose_name = 'видача'
        verbose_name_plural = 'видачі'

    def __str__(self):
        return f'{self.book.title} → {self.reader.card_number}'
