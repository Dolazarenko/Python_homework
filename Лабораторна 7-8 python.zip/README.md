# Лабораторна: Django + Flask, міграції, ORM, PyTest

Предметна область: **бібліотека** (автори, жанри, книги, читачі, видачі).

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt

# Django
cd django_project
python manage.py migrate
python orm_demo.py
pytest -v
pytest --cov=library --cov-branch --cov-report=term-missing

# Flask
cd ../flask_project
flask db upgrade            # DATABASE_URL = sqlite:///<проєкт>/library.db
python orm_demo.py
pytest -v
pytest --cov=app --cov-branch --cov-report=term-missing
```
Повний звіт: `REPORT.md`.
