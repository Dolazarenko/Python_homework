from datetime import date

from . import db

# Явна проміжна таблиця для зв'язку «багато-до-багатьох» Book <-> Genre
book_genres = db.Table(
    'book_genres',
    db.Column('book_id', db.Integer, db.ForeignKey('book.id', ondelete='CASCADE'), primary_key=True),
    db.Column('genre_id', db.Integer, db.ForeignKey('genre.id', ondelete='CASCADE'), primary_key=True),
)


class Author(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(150), unique=True, nullable=False)
    birth_year = db.Column(db.SmallInteger)
    country = db.Column(db.String(80), default='')

    def __repr__(self):
        return f'<Author {self.full_name}>'


class Genre(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=True, nullable=False)
    is_fiction = db.Column(db.Boolean, default=True, nullable=False)

    def __repr__(self):
        return f'<Genre {self.name}>'


class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    isbn = db.Column(db.String(13), unique=True, nullable=False)
    year = db.Column(db.SmallInteger, nullable=False)
    copies = db.Column(db.Integer, default=1, nullable=False)
    language = db.Column(db.String(2), default='uk', server_default='uk', nullable=False)
    author_id = db.Column(db.Integer, db.ForeignKey('author.id'), nullable=False)  # 1:N

    # 1:N, backref створює Author.books та Book.author
    author = db.relationship('Author', backref=db.backref('books', lazy='select'))
    # M:N через book_genres, backref створює Genre.books
    genres = db.relationship('Genre', secondary=book_genres,
                             backref=db.backref('books', lazy='select'))

    def to_dict(self):
        return {'id': self.id, 'title': self.title, 'isbn': self.isbn, 'year': self.year,
                'copies': self.copies, 'language': self.language, 'author': self.author.full_name,
                'genres': sorted(g.name for g in self.genres)}

    def __repr__(self):
        return f'<Book {self.title} ({self.year})>'


class Reader(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)

    # 1:1 — uselist=False; backref дає ReaderCard.reader
    card = db.relationship('ReaderCard', backref='reader', uselist=False,
                           cascade='all, delete-orphan')
    loans = db.relationship('Loan', backref='reader', cascade='all, delete-orphan')

    def __repr__(self):
        return f'<Reader {self.name}>'


class ReaderCard(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    number = db.Column(db.String(20), unique=True, nullable=False)
    phone = db.Column(db.String(20), default='')
    reader_id = db.Column(db.Integer, db.ForeignKey('reader.id'), unique=True, nullable=False)

    def __repr__(self):
        return f'<ReaderCard {self.number}>'


class Loan(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    reader_id = db.Column(db.Integer, db.ForeignKey('reader.id'), nullable=False)
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'), nullable=False)
    loaned_at = db.Column(db.Date, nullable=False, default=date.today)
    due_at = db.Column(db.Date, nullable=False)
    returned_at = db.Column(db.Date)

    book = db.relationship('Book', backref='loans')

    def __repr__(self):
        return f'<Loan book={self.book_id} reader={self.reader_id}>'
