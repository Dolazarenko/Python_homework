from flask import Blueprint, jsonify, request
from sqlalchemy.exc import IntegrityError

from . import db
from .models import Author, Book, Genre

bp = Blueprint('api', __name__, url_prefix='/api')


@bp.get('/books')
def list_books():
    q = request.args.get('q')
    query = db.select(Book).order_by(Book.title)
    if q:
        query = query.where(Book.title.ilike(f'%{q}%'))
    return jsonify([b.to_dict() for b in db.session.scalars(query)])


@bp.get('/books/<int:book_id>')
def get_book(book_id):
    book = db.session.get(Book, book_id)
    if book is None:
        return jsonify({'error': 'not found'}), 404
    return jsonify(book.to_dict())


@bp.post('/books')
def create_book():
    data = request.get_json(silent=True)
    required = ('title', 'isbn', 'year', 'author')
    if not data or any(k not in data for k in required):
        return jsonify({'error': 'required: ' + ', '.join(required)}), 400
    author = db.session.scalar(db.select(Author).filter_by(full_name=data['author']))
    if author is None:
        author = Author(full_name=data['author'])
    book = Book(title=data['title'], isbn=data['isbn'], year=data['year'], author=author)
    for name in data.get('genres', []):
        genre = db.session.scalar(db.select(Genre).filter_by(name=name)) or Genre(name=name)
        book.genres.append(genre)
    db.session.add(book)
    try:
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        return jsonify({'error': 'isbn already exists'}), 409
    return jsonify(book.to_dict()), 201
