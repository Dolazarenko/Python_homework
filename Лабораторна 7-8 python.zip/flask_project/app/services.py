from datetime import date, timedelta

import requests

from . import db
from .models import Book, Loan, Reader

FINE_PER_DAY = 2  # грн за день прострочення
NOTIFY_URL = 'https://notify.example.com/api/send'


def today():
    """Поточна дата (окрема функція, щоб її можна було підмінити моком)."""
    return date.today()


def calc_fine(loan):
    if loan.returned_at is not None:
        return 0
    days = (today() - loan.due_at).days
    return max(days, 0) * FINE_PER_DAY


def send_overdue_notice(email, text):
    """ЗОВНІШНЯ залежність: HTTP-виклик сервісу сповіщень."""
    resp = requests.post(NOTIFY_URL, json={'to': email, 'text': text}, timeout=5)
    return resp.status_code == 200


def lend_book(reader_id, book_id, days=14):
    """Транзакція: зменшити copies і створити видачу — або все, або нічого."""
    try:
        book = db.session.get(Book, book_id)
        reader = db.session.get(Reader, reader_id)
        if book is None or reader is None:
            raise ValueError('Книгу або читача не знайдено')
        book.copies -= 1
        if book.copies < 0:
            raise ValueError('Немає вільних примірників')
        loan = Loan(reader=reader, book=book, loaned_at=today(),
                    due_at=today() + timedelta(days=days))
        db.session.add(loan)
        db.session.commit()
        return loan
    except Exception:
        db.session.rollback()
        raise
