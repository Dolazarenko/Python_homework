"""Завдання 4 (Flask): CRUD через db.session, агрегація, транзакції."""
from datetime import date, timedelta

from sqlalchemy import func, or_, not_

from app import create_app, db
from app.models import Author, Book, Genre, Loan, Reader, ReaderCard, book_genres
from app.services import lend_book

app = create_app()


def h(t):
    print(f'\n=== {t} ===')


with app.app_context():
    # очищення
    for M in (Loan, ReaderCard, Reader, Book, Genre, Author):
        db.session.query(M).delete()
    db.session.execute(book_genres.delete())
    db.session.commit()

    h('CREATE')
    shev, franko, orwell = (Author(full_name='Тарас Шевченко', birth_year=1814),
                            Author(full_name='Іван Франко', birth_year=1856),
                            Author(full_name='George Orwell', birth_year=1903))
    poetry, novel, dyst = Genre(name='Поезія'), Genre(name='Роман'), Genre(name='Антиутопія')
    b1 = Book(title='Кобзар', isbn='9780000000001', year=1840, copies=5, author=shev, genres=[poetry])
    b2 = Book(title='Захар Беркут', isbn='9780000000002', year=1883, copies=2, author=franko, genres=[novel])
    b3 = Book(title='1984', isbn='9780000000003', year=1949, copies=1, author=orwell, language='en', genres=[novel, dyst])
    b4 = Book(title='Звіряча ферма', isbn='9780000000004', year=1945, copies=4, author=orwell, language='en', genres=[dyst])
    reader = Reader(name='Олена', email='olena@example.com',
                    card=ReaderCard(number='LIB-0001', phone='+380501112233'))
    db.session.add_all([b1, b2, b3, b4, reader])
    db.session.commit()
    print('Авторів:', db.session.scalar(db.select(func.count(Author.id))),
          '| Книг:', db.session.scalar(db.select(func.count(Book.id))))

    h('READ: filter / OR / NOT')
    print('year<1900:', db.session.scalars(db.select(Book).where(Book.year < 1900).order_by(Book.title)).all())
    print('language!="uk":', db.session.scalars(db.select(Book).where(Book.language != 'uk').order_by(Book.title)).all())
    print('OR (Кобзар | рік>1948):', db.session.scalars(
        db.select(Book).where(or_(Book.title == 'Кобзар', Book.year > 1948)).order_by(Book.title)).all())
    print('NOT англійські:', db.session.scalars(
        db.select(Book).where(not_(Book.language == 'en')).order_by(Book.title)).all())

    h('READ: агрегація та group by')
    print(db.session.execute(db.select(func.count(Book.id), func.avg(Book.year),
                                       func.min(Book.year), func.max(Book.year))).one())
    rows = db.session.execute(
        db.select(Author.full_name, func.count(Book.id).label('n'))
        .join(Book).group_by(Author.id).order_by(func.count(Book.id).desc(), Author.full_name)).all()
    for name, n in rows:
        print(f'{name}: {n}')

    h('Зв\'язки (backref)')
    print('orwell.books:', sorted(b.title for b in orwell.books))
    print('dyst.books:', sorted(b.title for b in dyst.books))
    print('reader.card:', reader.card, '| card.reader:', reader.card.reader)

    h('UPDATE')
    b2.title = 'Захар Беркут (вид. 2)'
    db.session.commit()
    n = db.session.query(Book).filter(Book.author_id == orwell.id).update({'copies': 10})
    db.session.commit()
    print('Оновлено масово:', n, '| назва:', db.session.get(Book, b2.id).title)

    h('Транзакція: успішна (commit)')
    loan = lend_book(reader.id, b1.id)
    print('Видача створена:', loan, '| copies Кобзаря:', db.session.get(Book, b1.id).copies)

    h('Транзакція: помилка → rollback')
    db.session.get(Book, b3.id).copies = 1
    db.session.commit()
    lend_book(reader.id, b3.id)             # успішно: 1 -> 0
    try:
        lend_book(reader.id, b3.id)         # copies стане -1 -> ValueError -> rollback
    except ValueError as e:
        print('Помилка:', e)
    print('copies "1984" після відкату:', db.session.get(Book, b3.id).copies,
          '| видач "1984":', db.session.query(Loan).filter_by(book_id=b3.id).count())

    h('Явний rollback незафіксованих змін')
    db.session.add(Genre(name='Тимчасовий'))
    db.session.flush()
    print('у сесії після flush:', db.session.query(Genre).filter_by(name='Тимчасовий').count())
    db.session.rollback()
    print('після rollback:', db.session.query(Genre).filter_by(name='Тимчасовий').count())

    h('DELETE')
    db.session.query(Loan).delete()
    db.session.delete(b2)
    db.session.commit()
    print('Книг лишилось:', db.session.query(Book).count())
    db.session.delete(reader)  # cascade -> картка видаляється
    db.session.commit()
    print('Карток лишилось (cascade 1:1):', db.session.query(ReaderCard).count())
