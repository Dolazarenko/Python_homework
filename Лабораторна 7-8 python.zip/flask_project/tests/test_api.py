import pytest


def test_list_books_ok(client, book):
    resp = client.get('/api/books')
    assert resp.status_code == 200
    data = resp.get_json()
    assert len(data) == 1 and data[0]['title'] == 'Кобзар'
    assert data[0]['author'] == 'Тарас Шевченко' and data[0]['genres'] == ['Поезія']


def test_list_books_search_empty(client, book):
    resp = client.get('/api/books', query_string={'q': 'xyz'})
    assert resp.status_code == 200 and resp.get_json() == []


def test_get_book_ok_and_404(client, book):
    assert client.get(f'/api/books/{book.id}').get_json()['isbn'] == book.isbn
    resp = client.get('/api/books/9999')
    assert resp.status_code == 404
    assert resp.get_json() == {'error': 'not found'}


def test_create_book_json_201(client, db):
    payload = {'title': '1984', 'isbn': '9780000000003', 'year': 1949,
               'author': 'George Orwell', 'genres': ['Антиутопія']}
    resp = client.post('/api/books', json=payload)
    assert resp.status_code == 201
    body = resp.get_json()
    assert body['author'] == 'George Orwell' and body['genres'] == ['Антиутопія']
    assert client.get('/api/books').get_json()[0]['title'] == '1984'


@pytest.mark.parametrize('payload', [{}, {'title': 'x'}, {'title': 'x', 'isbn': '1', 'year': 1}])
def test_create_book_missing_fields_400(client, payload):
    resp = client.post('/api/books', json=payload)
    assert resp.status_code == 400


def test_create_book_not_json_400(client):
    assert client.post('/api/books', data='not json').status_code == 400


def test_create_book_duplicate_isbn_409(client, book):
    resp = client.post('/api/books', json={'title': 'Копія', 'isbn': book.isbn,
                                           'year': 2000, 'author': 'Тарас Шевченко'})
    assert resp.status_code == 409
