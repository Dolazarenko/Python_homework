from datetime import date

import pytest

from app import create_app, db as _db
from app.config import TestConfig
from app.models import Author, Book, Genre, Loan, Reader, ReaderCard


@pytest.fixture
def app():
    """Нова застосунок + чиста in-memory БД для КОЖНОГО тесту (детермінованість)."""
    app = create_app(TestConfig)
    with app.app_context():
        _db.create_all()
        yield app
        _db.session.remove()
        _db.drop_all()


@pytest.fixture
def db(app):
    return _db


@pytest.fixture
def author(db):
    a = Author(full_name='Тарас Шевченко', birth_year=1814)
    db.session.add(a)
    db.session.commit()
    return a


@pytest.fixture
def genre(db):
    g = Genre(name='Поезія')
    db.session.add(g)
    db.session.commit()
    return g


@pytest.fixture
def book(db, author, genre):
    b = Book(title='Кобзар', isbn='9780000000001', year=1840, copies=2, author=author, genres=[genre])
    db.session.add(b)
    db.session.commit()
    return b


@pytest.fixture
def reader(db):
    r = Reader(name='Олена', email='olena@example.com', card=ReaderCard(number='LIB-0001'))
    db.session.add(r)
    db.session.commit()
    return r


@pytest.fixture
def loan(db, reader, book):
    l = Loan(reader=reader, book=book, loaned_at=date(2026, 1, 1), due_at=date(2026, 1, 15))
    db.session.add(l)
    db.session.commit()
    return l
