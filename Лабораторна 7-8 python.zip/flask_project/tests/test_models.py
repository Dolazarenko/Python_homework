import pytest
from sqlalchemy.exc import IntegrityError

from app.models import Author, Book, Genre, Reader, ReaderCard, book_genres
from app.services import lend_book


def test_book_creation_defaults_and_relations(book, author, genre):
    assert book.id is not None
    assert book.language == 'uk'        # значення за замовчуванням
    assert book.author is author        # 1:N
    assert author.books == [book]       # backref
    assert genre.books == [book]        # M:N backref


def test_repr(book, author, genre, reader):
    assert repr(book) == '<Book Кобзар (1840)>'
    assert repr(author) == '<Author Тарас Шевченко>'
    assert repr(genre) == '<Genre Поезія>'
    assert repr(reader.card) == '<ReaderCard LIB-0001>'


def test_isbn_unique(db, book, author):
    db.session.add(Book(title='Дубль', isbn=book.isbn, year=2000, author=author))
    with pytest.raises(IntegrityError):
        db.session.commit()
    db.session.rollback()


def test_not_null_constraint(db):
    db.session.add(Author())  # full_name обов'язкове
    with pytest.raises(IntegrityError):
        db.session.commit()
    db.session.rollback()


def test_one_to_one_card_unique_per_reader(db, reader):
    db.session.add(ReaderCard(number='LIB-0002', reader_id=reader.id))
    with pytest.raises(IntegrityError):
        db.session.commit()
    db.session.rollback()


def test_cascade_delete_reader_removes_card_and_loans(db, reader, loan):
    db.session.delete(reader)
    db.session.commit()
    assert db.session.query(ReaderCard).count() == 0
    from app.models import Loan
    assert db.session.query(Loan).count() == 0


def test_lend_book_commits_and_decrements(db, reader, book):
    loan = lend_book(reader.id, book.id)
    assert loan.id is not None
    assert db.session.get(Book, book.id).copies == 1


def test_lend_book_rolls_back_when_no_copies(db, reader, book):
    from app.models import Loan
    book.copies = 0
    db.session.commit()
    with pytest.raises(ValueError):
        lend_book(reader.id, book.id)
    assert db.session.get(Book, book.id).copies == 0
    assert db.session.query(Loan).count() == 0


@pytest.mark.parametrize('name, is_fiction, expected_fiction', [
    ('Роман', None, True),     # default=True
    ('Наука', False, False),
    ('Проза', True, True),
])
def test_genre_default_is_fiction(db, name, is_fiction, expected_fiction):
    g = Genre(name=name) if is_fiction is None else Genre(name=name, is_fiction=is_fiction)
    db.session.add(g)
    db.session.commit()
    assert g.is_fiction is expected_fiction
