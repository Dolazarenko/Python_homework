from datetime import date
from unittest.mock import MagicMock, patch

import pytest

from app import services


# --- Мок 1: ЗОВНІШНЯ залежність (HTTP-сервіс сповіщень) ---
@patch('app.services.requests.post')
def test_send_overdue_notice_mocks_http(mock_post):
    mock_post.return_value = MagicMock(status_code=200)
    assert services.send_overdue_notice('a@b.c', 'Поверніть книгу') is True
    mock_post.assert_called_once_with(
        services.NOTIFY_URL, json={'to': 'a@b.c', 'text': 'Поверніть книгу'}, timeout=5)


@patch('app.services.requests.post')
def test_send_overdue_notice_failure(mock_post):
    mock_post.return_value = MagicMock(status_code=500)
    assert services.send_overdue_notice('a@b.c', 't') is False


# --- Мок 2: ВНУТРІШНЯ залежність (поточна дата) ---
@pytest.mark.parametrize('now, fine', [
    (date(2026, 1, 20), 10),   # 5 днів * 2 грн
    (date(2026, 1, 15), 0),    # межа: у день терміну штрафу немає
    (date(2026, 1, 1), 0),     # ще не прострочено
])
def test_calc_fine_with_mocked_today(loan, now, fine):
    with patch('app.services.today', return_value=now) as mock_today:
        assert services.calc_fine(loan) == fine
        mock_today.assert_called_once_with()
