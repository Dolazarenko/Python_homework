# Звіт з лабораторної роботи
**Тема:** Django та Flask: моделі, міграції, ORM-запити, тестування PyTest
**Предметна область:** інформаційна система бібліотеки
**Середовище:** Python 3.12.3, Django 6.1.2, Flask 3.1.3, Flask-SQLAlchemy 3.1.1, Flask-Migrate 4.1.0, pytest 9.1.1, pytest-django 4.14.0, pytest-flask 1.3.0, pytest-cov 7.1.0. СУБД: SQLite.

Проєкти нові (не продовження попередніх лабораторних): усі моделі створені з нуля. Структура:
```
lab/
├── django_project/   (config/, library/, tests/, orm_demo.py, pytest.ini)
└── flask_project/    (app/, migrations/, tests/, orm_demo.py, run.py, pytest.ini)
```

---
## Завдання 1. Моделі Django

### 1.1 Сутності та їхня роль
| Модель | Роль | Ключові поля |
|---|---|---|
| `Author` | автор книг | `full_name` (unique), `birth_year` (null), `country` (blank) |
| `Genre` | жанр | `name` (unique), `description`, `is_fiction` (default=True) |
| `Book` | книга каталогу | `title`, `isbn` (unique), `year`, `copies`, `language` (choices) |
| `ReaderProfile` | профіль читача, розширення `auth.User` | `card_number` (unique), `phone`, `registered_at` (auto_now_add) |
| `Loan` | факт видачі книги читачеві | `loaned_at`, `due_at`, `returned_at` (null) |

### 1.2 ER-діаграма (текстова)
```
Author 1 ───< Book >───< Genre          (Book—Genre: M:N, таблиця library_book_genres)
                 1
                 │
                 ^
User 1 ─── 1 ReaderProfile 1 ───< Loan >─── 1 Book
```
Читається так: `Author 1—N Book` (ForeignKey), `Book M—N Genre` (ManyToManyField), `User 1—1 ReaderProfile` (OneToOneField), `ReaderProfile 1—N Loan` і `Book 1—N Loan` (ForeignKey).

### 1.3 Семантика зв'язків та політика `on_delete`
| Зв'язок | Тип | `on_delete` | Обґрунтування |
|---|---|---|---|
| `Book.author → Author` | ForeignKey | **PROTECT** | Не можна втратити автора, поки в каталозі є його книги; видалення потребує свідомої дії (спочатку книги). Каскад мовчки знищив би каталог. |
| `Book.genres ↔ Genre` | ManyToMany | — (проміжна таблиця створюється Django) | Книга може мати кілька жанрів, жанр містить багато книг. |
| `ReaderProfile.user → User` | OneToOne | **CASCADE** | Профіль не існує без користувача; видалення акаунту має прибирати і профіль (а разом із ним — видачі, що належать читачеві). |
| `Loan.reader → ReaderProfile` | ForeignKey | **CASCADE** | Видачі особисті для читача: після видалення читача його видачі втрачають сенс. |
| `Loan.book → Book` | ForeignKey | **PROTECT** | Історію видач не можна порушити: книгу, що фігурує у видачах, видалити не можна. |

`SET_NULL` свідомо не використано: у цій предметній області немає зв'язків, де «осиротілий» запис має сенс (видача без книги або читача, книга без автора були б порушенням цілісності). Якби, наприклад, додати `Book.publisher`, там доречний був би `SET_NULL`.

Усі моделі мають `Meta` (`ordering`, `verbose_name`, `verbose_name_plural`), `__str__` та не менше трьох змістовних полів, окрім `id`. Код: `django_project/library/models.py`.

---
## Завдання 2. Міграції Django

Послідовність: початкова міграція → зміна моделі (нове поле `Book.language` з `choices` і `default='uk'`) → друга міграція.

**Створення та застосування `0001_initial`:**
```
$ python manage.py makemigrations library
Migrations for 'library':
  library/migrations/0001_initial.py
    + Create model Author
    + Create model Genre
    + Create model Book
    + Create model ReaderProfile
    + Create model Loan

$ python manage.py migrate
Operations to perform:
  Apply all migrations: admin, auth, contenttypes, library, sessions
Running migrations:
  Applying contenttypes.0001_initial... OK
  Applying auth.0001_initial... OK
  Applying admin.0001_initial... OK
  Applying admin.0002_logentry_remove_auto_add... OK
  Applying admin.0003_logentry_add_action_flag_choices... OK
  Applying contenttypes.0002_remove_content_type_name... OK
  Applying auth.0002_alter_permission_name_max_length... OK
  Applying auth.0003_alter_user_email_max_length... OK
  Applying auth.0004_alter_user_username_opts... OK
  Applying auth.0005_alter_user_last_login_null... OK
  Applying auth.0006_require_contenttypes_0002... OK
  Applying auth.0007_alter_validators_add_error_messages... OK
  Applying auth.0008_alter_user_username_max_length... OK
  Applying auth.0009_alter_user_last_name_max_length... OK
  Applying auth.0010_alter_group_name_max_length... OK
  Applying auth.0011_update_proxy_permissions... OK
  Applying auth.0012_alter_user_first_name_max_length... OK
  Applying library.0001_initial... OK
  Applying sessions.0001_initial... OK
```
**Друга міграція, `sqlmigrate`, `showmigrations`, відкат і повторне застосування:**
```
$ python manage.py makemigrations library -n book_language
Migrations for 'library':
  library/migrations/0002_book_language.py
    + Add field language to book

$ python manage.py sqlmigrate library 0002
BEGIN;
--
-- Add field language to book
--
CREATE TABLE "new__library_book" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "language" varchar(2) NOT NULL, "title" varchar(200) NOT NULL, "isbn" varchar(13) NOT NULL UNIQUE, "year" smallint unsigned NOT NULL CHECK ("year" >= 0), "copies" integer unsigned NOT NULL CHECK ("copies" >= 0), "author_id" bigint NOT NULL REFERENCES "library_author" ("id") DEFERRABLE INITIALLY DEFERRED);
INSERT INTO "new__library_book" ("id", "title", "isbn", "year", "copies", "author_id", "language") SELECT "id", "title", "isbn", "year", "copies", "author_id", 'uk' FROM "library_book";
DROP TABLE "library_book";
ALTER TABLE "new__library_book" RENAME TO "library_book";
CREATE INDEX "library_book_author_id_d9a3b67e" ON "library_book" ("author_id");
COMMIT;

$ python manage.py migrate
Operations to perform:
  Apply all migrations: admin, auth, contenttypes, library, sessions
Running migrations:
  Applying library.0002_book_language... OK

$ python manage.py showmigrations library
library
 [X] 0001_initial
 [X] 0002_book_language

$ python manage.py migrate library 0001   # відкат
Operations to perform:
  Target specific migration: 0001_initial, from library
Running migrations:
  Rendering model states... DONE
  Unapplying library.0002_book_language... OK
library
 [X] 0001_initial
 [ ] 0002_book_language

$ python manage.py migrate   # повторне застосування
Operations to perform:
  Apply all migrations: admin, auth, contenttypes, library, sessions
Running migrations:
  Applying library.0002_book_language... OK

$ python manage.py showmigrations library
library
 [X] 0001_initial
 [X] 0002_book_language

$ ls library/migrations
0001_initial.py
0002_book_language.py
__init__.py
__pycache__

# Generated by Django 6.1.2 on 2026-10-21 13:19

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('library', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='book',
            name='language',
            field=models.CharField(choices=[('uk', 'Українська'), ('en', 'Англійська'), ('de', 'Німецька')], default='uk', max_length=2, verbose_name='мова'),
        ),
    ]
```
**Файли в `library/migrations/`:**
- `__init__.py`: робить каталог пакетом Python.
- `0001_initial.py`: створює таблиці `Author`, `Genre`, `Book` (разом із M2M-таблицею), `ReaderProfile`, `Loan`.
- `0002_book_language.py`: операція `AddField` додає колонку `language`. Залежить від `0001_initial`.

**Спостереження з `sqlmigrate`:** SQLite не вміє додавати колонку з `NOT NULL` та `CHECK` «на місці», тому Django перебудовує таблицю: створює `new__library_book`, копіює дані (для існуючих рядків підставляє `'uk'`), видаляє стару й перейменовує нову, усе в одній транзакції (`BEGIN … COMMIT`). Застосовані міграції вручну не редагувалися; відкат виконано командою `migrate library 0001`. З нуля ланцюжок відтворюється: `python manage.py migrate` на порожній БД (перевірено перед пакуванням).

---
## Завдання 3. Flask-SQLAlchemy та Flask-Migrate

**СУБД:** SQLite. **URI:** `sqlite:///<абсолютний шлях>/flask_project/library.db` (змінна `DATABASE_URL` перевизначає значення; у тестах `sqlite:///:memory:`).

**Моделі** (`flask_project/app/models.py`), узгоджені з Django-версією; спрощено: немає `User`, замість нього `Reader`, а `ReaderCard` дає зв'язок 1:1:
- `Author 1—N Book`: `Book.author_id` ForeignKey + `relationship` з `backref='books'`.
- `Book M—N Genre`: **явна проміжна таблиця** `book_genres = db.Table(...)` + `relationship(secondary=book_genres, backref='books')`.
- `Reader 1—1 ReaderCard`: `ForeignKey(unique=True)` + `relationship(uselist=False, backref='reader')`.
- `Reader 1—N Loan`, `Book 1—N Loan`.

**Робочий процес:**
```
$ flask db init
Creating directory /home/claude/lab/flask_project/migrations ...  done
Creating directory /home/claude/lab/flask_project/migrations/versions ...  done
Generating /home/claude/lab/flask_project/migrations/script.py.mako ...  done
Generating /home/claude/lab/flask_project/migrations/README ...  done
Generating /home/claude/lab/flask_project/migrations/env.py ...  done
Generating /home/claude/lab/flask_project/migrations/alembic.ini ...  done
Please edit configuration/connection/logging settings in /home/claude/lab/flask_project/migrations/alembic.ini before proceeding.

$ flask db migrate -m "initial schema"
INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
INFO  [alembic.runtime.plugins] setting up autogenerate plugin alembic.autogenerate.schemas
INFO  [alembic.runtime.plugins] setting up autogenerate plugin alembic.autogenerate.tables
INFO  [alembic.runtime.plugins] setting up autogenerate plugin alembic.autogenerate.types
INFO  [alembic.runtime.plugins] setting up autogenerate plugin alembic.autogenerate.constraints
INFO  [alembic.runtime.plugins] setting up autogenerate plugin alembic.autogenerate.defaults
INFO  [alembic.runtime.plugins] setting up autogenerate plugin alembic.autogenerate.comments
INFO  [alembic.autogenerate.compare.tables] Detected added table 'author'
INFO  [alembic.autogenerate.compare.tables] Detected added table 'genre'
INFO  [alembic.autogenerate.compare.tables] Detected added table 'reader'
INFO  [alembic.autogenerate.compare.tables] Detected added table 'book'
INFO  [alembic.autogenerate.compare.tables] Detected added table 'reader_card'
INFO  [alembic.autogenerate.compare.tables] Detected added table 'book_genres'
INFO  [alembic.autogenerate.compare.tables] Detected added table 'loan'
Generating /home/claude/lab/flask_project/migrations/versions/b9b508ea3257_initial_schema.py ...  done

$ flask db upgrade
INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
INFO  [alembic.runtime.migration] Running upgrade  -> b9b508ea3257, initial schema

$ flask db current
INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
b9b508ea3257 (head)
```
Зміна моделі (`Book.language`) і друга ревізія:
```
$ flask db migrate -m "add book language"
INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
INFO  [alembic.autogenerate.compare.tables] Detected added column 'book.language'
Generating /home/claude/lab/flask_project/migrations/versions/97fb9f730f43_add_book_language.py ...  done

$ flask db upgrade
INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
INFO  [alembic.runtime.migration] Running upgrade b9b508ea3257 -> 97fb9f730f43, add book language

$ flask db history
b9b508ea3257 -> 97fb9f730f43 (head), add book language
<base> -> b9b508ea3257, initial schema

$ flask db current
97fb9f730f43 (head)

# Схема БД (sqlite3 .schema)
CREATE TABLE alembic_version (
	version_num VARCHAR(32) NOT NULL, 
	CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
);

CREATE TABLE author (
	id INTEGER NOT NULL, 
	full_name VARCHAR(150) NOT NULL, 
	birth_year SMALLINT, 
	country VARCHAR(80), 
	PRIMARY KEY (id), 
	UNIQUE (full_name)
);

CREATE TABLE book (
	id INTEGER NOT NULL, 
	title VARCHAR(200) NOT NULL, 
	isbn VARCHAR(13) NOT NULL, 
	year SMALLINT NOT NULL, 
	copies INTEGER NOT NULL, 
	author_id INTEGER NOT NULL, language VARCHAR(2) DEFAULT 'uk' NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(author_id) REFERENCES author (id), 
	UNIQUE (isbn)
);

CREATE TABLE book_genres (
	book_id INTEGER NOT NULL, 
	genre_id INTEGER NOT NULL, 
	PRIMARY KEY (book_id, genre_id), 
	FOREIGN KEY(book_id) REFERENCES book (id) ON DELETE CASCADE, 
	FOREIGN KEY(genre_id) REFERENCES genre (id) ON DELETE CASCADE
);

CREATE TABLE genre (
	id INTEGER NOT NULL, 
	name VARCHAR(80) NOT NULL, 
	is_fiction BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (name)
);

CREATE TABLE loan (
	id INTEGER NOT NULL, 
	reader_id INTEGER NOT NULL, 
	book_id INTEGER NOT NULL, 
	loaned_at DATE NOT NULL, 
	due_at DATE NOT NULL, 
	returned_at DATE, 
	PRIMARY KEY (id), 
	FOREIGN KEY(book_id) REFERENCES book (id), 
	FOREIGN KEY(reader_id) REFERENCES reader (id)
);

CREATE TABLE reader (
	id INTEGER NOT NULL, 
	name VARCHAR(120) NOT NULL, 
	email VARCHAR(120) NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (email)
);

CREATE TABLE reader_card (
	id INTEGER NOT NULL, 
	number VARCHAR(20) NOT NULL, 
	phone VARCHAR(20), 
	reader_id INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(reader_id) REFERENCES reader (id), 
	UNIQUE (number), 
	UNIQUE (reader_id)
);

# Вміст migrations/versions:
97fb9f730f43_add_book_language.py
b9b508ea3257_initial_schema.py

def upgrade():
    # ### commands auto generated by Alembic - please adjust! ###
    with op.batch_alter_table('book', schema=None) as batch_op:
        batch_op.add_column(sa.Column('language', sa.String(length=2), server_default='uk', nullable=False))

    # ### end Alembic commands ###


def downgrade():
    # ### commands auto generated by Alembic - please adjust! ###
    with op.batch_alter_table('book', schema=None) as batch_op:
        batch_op.drop_column('language')

    # ### end Alembic commands ###
```
Схема таблиць у SQLite відповідає моделям: присутні всі зовнішні ключі, `UNIQUE` на `isbn`, `reader_card.reader_id` (1:1), складений первинний ключ `book_genres`, колонка `language` у `book`. Зверніть увагу: Alembic згенерував `batch_alter_table`, бо SQLite обмежено підтримує `ALTER TABLE`.

### Порівняння Flask-Migrate (Alembic) з Django
| Аспект | Django | Flask-Migrate |
|---|---|---|
| Ініціалізація | автоматично, `migrations/` у кожному застосунку (`makemigrations`) | вручну один раз: `flask db init` |
| Створення міграції | `makemigrations` | `flask db migrate -m "..."` (autogenerate) |
| Застосування | `migrate` | `flask db upgrade` / `downgrade` |
| Нумерація | послідовна `0001`, `0002` | випадкові хеш-ідентифікатори ревізій, ланцюжок через `down_revision` |
| Реєстр застосованого | таблиця `django_migrations` | таблиця `alembic_version` (лише поточна голова) |
| Перегляд | `showmigrations`, `sqlmigrate` | `flask db history`, `current`, `upgrade --sql` |
| Перевірка autogenerate | майже надійна | **треба перечитувати вручну**: Alembic не бачить перейменувань (бачить drop+add), змін деяких типів і серверних значень |
| Зведення залежностей | автоматично між застосунками | вручну: треба змінювати `down_revision` |

**Що виконується вручну / автоматично.** У Flask вручну: `flask db init`, імпорт моделей до `create_app` (інакше autogenerate «не бачить» таблиці), перегляд згенерованого скрипту. Автоматично: порівняння моделей зі схемою та генерація операцій. У Django детекція змін і залежності між застосунками автоматичні.

**Злиття гілок.** Якщо двоє розробників створили ревізії від однієї «голови», виникають **дві голови** (`multiple heads`): `flask db upgrade` відмовиться працювати. Рішення: `flask db heads`, потім `flask db merge -m "merge" <rev1> <rev2>` створює порожню ревізію-злиття. У Django аналогічний конфлікт (два `0003_*`) вирішується `makemigrations --merge`. В обох випадках варто порівняти зміни схеми, бо автоматичне злиття не гарантує узгодженості.

---
## Завдання 4. ORM-запити

### 4.1 Django (`django_project/orm_demo.py`)
Сценарії: створення авторів, жанрів, книг, читача і двох видач (CREATE); `filter`, `exclude`, `Q` з OR / NOT / AND+NOT (READ); `aggregate` (кількість, середній/мін./макс. рік); `annotate(Count)` (книг на автора, книг на жанр); зворотні зв'язки (`orwell.books`, `user.reader_profile`); порівняння кількості SQL-запитів без оптимізації, з `select_related` і з `prefetch_related`; UPDATE (`update()` та `save(update_fields=…)`); DELETE з перевіркою `PROTECT`/`CASCADE`; `transaction.atomic`.

Фактичний вивід (збігається з очікуваним: напр., після `exclude(language="uk")` лишаються лише 2 англійські книги; N+1 дає 5 запитів = 1 + 4 книги, `select_related` дає 1, `prefetch_related` дає 2):
```

=== CREATE ===
Авторів: 3 | Книг: 4 | Видач: 2

=== READ: filter / exclude / Q ===
filter(year__lt=1900): [<Book: Захар Беркут (1883)>, <Book: Кобзар (1840)>]
exclude(language="uk"): [<Book: 1984 (1949)>, <Book: Звіряча ферма (1945)>]
Q OR (Кобзар | рік>1948): [<Book: 1984 (1949)>, <Book: Кобзар (1840)>]
Q NOT (не англійські): [<Book: Захар Беркут (1883)>, <Book: Кобзар (1840)>]
Q AND+NOT (автор Orwell, не 1984): [<Book: Звіряча ферма (1945)>]

=== READ: aggregate ===
{'total': 4, 'avg_year': 1904.25, 'oldest': 1840, 'newest': 1949}

=== READ: annotate ===
George Orwell: 2 книг
Іван Франко: 1 книг
Тарас Шевченко: 1 книг
Жанр Антиутопія: 2
Жанр Роман: 2
Жанр Поезія: 1

=== Зворотні зв'язки ===
orwell.books.all(): [<Book: 1984 (1949)>, <Book: Звіряча ферма (1945)>]
dyst.books.all(): [<Book: 1984 (1949)>, <Book: Звіряча ферма (1945)>]
u.reader_profile: LIB-0001 (olena)
reader.loans.count(): 2

=== N+1: без оптимізації ===
Запитів: 5

=== select_related ===
Запитів: 1

=== prefetch_related (M2M) ===
Запитів: 2

=== UPDATE ===
Оновлено рядків (update): 2
після save(): Захар Беркут (вид. 2)

=== DELETE + політики on_delete ===
PROTECT спрацював: автора з книгами не видалити
Видалено книгу: (2, {'library.Book_genres': 1, 'library.Book': 1})
Після видалення User профіль читача каскадно видалено: True | видач залишилось: 0

=== Атомарність (transaction.atomic) ===
Помилка: IntegrityError → відкат; "Тимчасовий" існує? False
```
### 4.2 Flask (`flask_project/orm_demo.py`)
Сценарії: CRUD через `db.session` (`add_all`, `commit`, `db.select`, `scalars`, масове `update`, `delete`); `or_`, `not_`; агрегати `func.count/avg/min/max` і `group_by`; **транзакції**: функція `lend_book` зменшує `copies` і створює `Loan` та робить `commit`; якщо вільних примірників немає, кидає `ValueError`, і `rollback` скасовує зміну `copies`. Також показано явний `flush` → `rollback`. Прямі SQL-запити не використовувались.
```

=== CREATE ===
Авторів: 3 | Книг: 4

=== READ: filter / OR / NOT ===
year<1900: [<Book Захар Беркут (1883)>, <Book Кобзар (1840)>]
language!="uk": [<Book 1984 (1949)>, <Book Звіряча ферма (1945)>]
OR (Кобзар | рік>1948): [<Book 1984 (1949)>, <Book Кобзар (1840)>]
NOT англійські: [<Book Захар Беркут (1883)>, <Book Кобзар (1840)>]

=== READ: агрегація та group by ===
(4, 1904.25, 1840, 1949)
George Orwell: 2
Іван Франко: 1
Тарас Шевченко: 1

=== Зв'язки (backref) ===
orwell.books: ['1984', 'Звіряча ферма']
dyst.books: ['1984', 'Звіряча ферма']
reader.card: <ReaderCard LIB-0001> | card.reader: <Reader Олена>

=== UPDATE ===
Оновлено масово: 2 | назва: Захар Беркут (вид. 2)

=== Транзакція: успішна (commit) ===
Видача створена: <Loan book=1 reader=1> | copies Кобзаря: 4

=== Транзакція: помилка → rollback ===
Помилка: Немає вільних примірників
copies "1984" після відкату: 0 | видач "1984": 1

=== Явний rollback незафіксованих змін ===
у сесії після flush: 1
після rollback: 0

=== DELETE ===
Книг лишилось: 3
Карток лишилось (cascade 1:1): 0
```
### 4.3 Порівняння стилю
| | Django ORM | SQLAlchemy |
|---|---|---|
| Запити | через менеджер `Model.objects` і lookups (`year__lt=`, `title__icontains`) | через вирази Python (`Book.year < 1900`), `db.select()` |
| OR / NOT | `Q(a) \| Q(b)`, `~Q(a)` | `or_()`, `not_()` |
| Агрегація | `aggregate()` / `annotate()` | `func.*` + `group_by` + явний `join` |
| Зв'язки | автоматичні зворотні (`related_name`) | `backref` вказується явно |
| Транзакції | автокоміт, `atomic()` | явний `commit()` / `rollback()` (Unit of Work) |
| Оптимізація | `select_related`, `prefetch_related` | `joinedload`, `selectinload` |

Django компактніший і «з коробки», SQLAlchemy явніший і гнучкіший, але вимагає більше коду та дисципліни з сесією.

---
## Завдання 5. PyTest: модульні тести моделей

**Налаштування:** `pytest.ini` у кожному проєкті (`DJANGO_SETTINGS_MODULE=config.settings` для Django). **Важливий нюанс:** `pytest-django` і `pytest-flask` обидва визначають фікстуру `client`, тому в одному середовищі вони конфліктують (спершу API-тести Flask були пропущені з повідомленням «no Django settings»). Рішення: у `addopts` кожного проєкту вимкнено «чужий» плагін (`-p no:flask` у Django, `-p no:django` у Flask). Альтернатива: окремі віртуальні середовища.

**Структура тестів:**
```
django_project/:
tests/__init__.py
tests/conftest.py
tests/test_mocks.py
tests/test_models.py
tests/test_views.py

flask_project/:
tests/__init__.py
tests/conftest.py
tests/test_api.py
tests/test_mocks.py
tests/test_models.py
```
Фікстури в `conftest.py`: Django: `user`, `author`, `genre`, `book`, `reader`, `loan`, `auth_client`; Flask: `app` (нова in-memory БД на кожен тест), `db`, `author`, `genre`, `book`, `reader`, `loan`; `client` надає pytest-flask.

**Перевірки (моделі):** створення об'єктів і значення за замовчуванням; `__str__`/`__repr__`; `unique` (ISBN); `max_length` і `choices` (через `full_clean`); `PROTECT` для автора; `CASCADE` для користувача/читача; обмеження 1:1; `NOT NULL` (Flask); транзакційний commit/rollback (Flask). Параметризовані тести: `test_genre_name_validation`, `test_book_language_choices` (Django), `test_genre_default_is_fiction` (Flask).

Детермінованість: кожен тест працює у власній транзакції/БД (Django: `db` + транзакція, що відкочується; Flask: `create_all`/`drop_all` на in-memory БД), даних вручну немає, порядок виконання не важливий. Примітка: `pytest-django` сам перевпорядковує тести (тести без БД ідуть першими), що видно у виводі.

**Команди та вивід:**
```
cd django_project && pytest -v
$ pytest -v
============================= test session starts ==============================
platform linux -- Python 3.12.3, pytest-9.1.1, pluggy-1.7.0 -- /home/claude/lab/venv/bin/python3
django: version: 6.1.2, settings: config.settings (from ini)
rootdir: /home/claude/lab/django_project
configfile: pytest.ini
testpaths: tests
plugins: cov-7.1.0, django-4.14.0
collecting ... collected 27 items

tests/test_mocks.py::test_is_loan_overdue_with_mocked_time[today0-True] PASSED [  3%]
tests/test_mocks.py::test_is_loan_overdue_with_mocked_time[today1-False] PASSED [  7%]
tests/test_mocks.py::test_is_loan_overdue_with_mocked_time[today2-False] PASSED [ 11%]
tests/test_mocks.py::test_returned_loan_never_overdue_and_clock_not_used PASSED [ 14%]
tests/test_models.py::test_book_creation_and_defaults PASSED             [ 18%]
tests/test_models.py::test_str_representations PASSED                    [ 22%]
tests/test_models.py::test_isbn_unique PASSED                            [ 25%]
tests/test_models.py::test_protect_author_with_books PASSED              [ 29%]
tests/test_models.py::test_cascade_user_deletes_profile_and_loans PASSED [ 33%]
tests/test_models.py::test_one_to_one_reverse_access PASSED              [ 37%]
tests/test_models.py::test_genre_name_validation[Роман-True] PASSED [ 40%]
tests/test_models.py::test_genre_name_validation[AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA-True] PASSED [ 44%]
tests/test_models.py::test_genre_name_validation[AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA-False] PASSED [ 48%]
tests/test_models.py::test_genre_name_validation[-False] PASSED          [ 51%]
tests/test_models.py::test_book_language_choices[uk-True] PASSED         [ 55%]
tests/test_models.py::test_book_language_choices[en-True] PASSED         [ 59%]
tests/test_models.py::test_book_language_choices[de-True] PASSED         [ 62%]
tests/test_models.py::test_book_language_choices[fr-False] PASSED        [ 66%]
tests/test_views.py::test_book_list_ok_and_content PASSED                [ 70%]
tests/test_views.py::test_book_list_search_no_match PASSED               [ 74%]
tests/test_views.py::test_book_detail_ok PASSED                          [ 77%]
tests/test_views.py::test_book_detail_404[0] PASSED                      [ 81%]
tests/test_views.py::test_book_detail_404[99999] PASSED                  [ 85%]
tests/test_views.py::test_my_loans_anonymous_redirects_to_login PASSED   [ 88%]
tests/test_views.py::test_my_loans_authenticated_shows_only_own PASSED   [ 92%]
tests/test_mocks.py::test_fetch_book_info_mocks_http PASSED              [ 96%]
tests/test_mocks.py::test_fetch_book_info_not_found PASSED               [100%]

============================== 27 passed in 4.33s ==============================
```
```
cd flask_project && pytest -v
$ pytest -v
============================= test session starts ==============================
platform linux -- Python 3.12.3, pytest-9.1.1, pluggy-1.7.0 -- /home/claude/lab/venv/bin/python3
rootdir: /home/claude/lab/flask_project
configfile: pytest.ini
testpaths: tests
plugins: flask-1.3.0, cov-7.1.0
collecting ... collected 25 items

tests/test_api.py::test_list_books_ok PASSED                             [  4%]
tests/test_api.py::test_list_books_search_empty PASSED                   [  8%]
tests/test_api.py::test_get_book_ok_and_404 PASSED                       [ 12%]
tests/test_api.py::test_create_book_json_201 PASSED                      [ 16%]
tests/test_api.py::test_create_book_missing_fields_400[payload0] PASSED  [ 20%]
tests/test_api.py::test_create_book_missing_fields_400[payload1] PASSED  [ 24%]
tests/test_api.py::test_create_book_missing_fields_400[payload2] PASSED  [ 28%]
tests/test_api.py::test_create_book_not_json_400 PASSED                  [ 32%]
tests/test_api.py::test_create_book_duplicate_isbn_409 PASSED            [ 36%]
tests/test_mocks.py::test_send_overdue_notice_mocks_http PASSED          [ 40%]
tests/test_mocks.py::test_send_overdue_notice_failure PASSED             [ 44%]
tests/test_mocks.py::test_calc_fine_with_mocked_today[now0-10] PASSED    [ 48%]
tests/test_mocks.py::test_calc_fine_with_mocked_today[now1-0] PASSED     [ 52%]
tests/test_mocks.py::test_calc_fine_with_mocked_today[now2-0] PASSED     [ 56%]
tests/test_models.py::test_book_creation_defaults_and_relations PASSED   [ 60%]
tests/test_models.py::test_repr PASSED                                   [ 64%]
tests/test_models.py::test_isbn_unique PASSED                            [ 68%]
tests/test_models.py::test_not_null_constraint PASSED                    [ 72%]
tests/test_models.py::test_one_to_one_card_unique_per_reader PASSED      [ 76%]
tests/test_models.py::test_cascade_delete_reader_removes_card_and_loans PASSED [ 80%]
tests/test_models.py::test_lend_book_commits_and_decrements PASSED       [ 84%]
tests/test_models.py::test_lend_book_rolls_back_when_no_copies PASSED    [ 88%]
tests/test_models.py::test_genre_default_is_fiction[Роман-None-True] PASSED [ 92%]
tests/test_models.py::test_genre_default_is_fiction[Наука-False-False] PASSED [ 96%]
tests/test_models.py::test_genre_default_is_fiction[Проза-True-True] PASSED [100%]

============================== 25 passed in 0.53s ==============================
```
Разом: 27 + 25 = **52 тести**, усі пройшли.

---
## Завдання 6. Інтеграційні тести HTTP

Тестовий клієнт працює на тестовій БД (Django створює й знищує `test_*` БД автоматично; у Flask це in-memory БД з фікстури `app`); продуктивні `db.sqlite3` / `library.db` не використовуються.

| № | Фреймворк | Тест | Маршрут | Сценарій | Очікуваний результат |
|---|---|---|---|---|---|
| 1 | Django | `test_book_list_ok_and_content` | `GET /` | позитивний | 200, шаблон `library/book_list.html`, у тілі назва книги й автор |
| 2 | Django | `test_book_list_search_no_match` | `GET /?q=…` | граничний (порожній результат) | 200, текст «Книг не знайдено» |
| 3 | Django | `test_book_detail_ok` | `GET /books/<pk>/` | позитивний | 200, у тілі ISBN |
| 4 | Django | `test_book_detail_404` (pk=0, 99999) | `GET /books/<pk>/` | негативний | 404 |
| 5 | Django | `test_my_loans_anonymous_redirects_to_login` | `GET /my-loans/` | негативний (неавторизований) | 302 → `/accounts/login/…` |
| 6 | Django | `test_my_loans_authenticated_shows_only_own` | `GET /my-loans/` | позитивний (авторизований) | 200, видно свої видачі, чужих немає |
| 7 | Flask | `test_list_books_ok` | `GET /api/books` | позитивний | 200, JSON-список з автором і жанрами |
| 8 | Flask | `test_get_book_ok_and_404` | `GET /api/books/<id>` | позитивний + негативний | 200 / 404 `{"error": "not found"}` |
| 9 | Flask | `test_create_book_json_201` | `POST /api/books` (JSON) | позитивний | 201, книга створена разом з автором і жанром |
| 10 | Flask | `test_create_book_missing_fields_400` (3 набори) | `POST /api/books` | негативний | 400 |
| 11 | Flask | `test_create_book_not_json_400` | `POST /api/books` (не JSON) | негативний | 400 |
| 12 | Flask | `test_create_book_duplicate_isbn_409` | `POST /api/books` | негативний (порушення unique) | 409, відкат сесії |

Усі ці тести входять до виводу `pytest -v` вище (файли `test_views.py`, `test_api.py`). Охоплено 5 різних маршрутів (`/`, `/books/<pk>/`, `/my-loans/`, `/api/books`, `/api/books/<id>`), є позитивні й негативні сценарії.

---
## Завдання 7. Моки та покриття коду

### 7.1 Мок-тести
| Проєкт | Тест | Що підмінено | Тип | Чому |
|---|---|---|---|---|
| Django | `test_fetch_book_info_mocks_http` | `library.services.requests.get` (HTTP до Open Library) | **зовнішня** | Без моку тест залежав би від мережі й стороннього сервісу: був би повільним, нестабільним, а відповідь могла б змінюватися. З моком тест миттєвий і детермінований. |
| Django | `test_is_loan_overdue_with_mocked_time` | `library.services.timezone.localdate` (поточна дата) | **внутрішня/побічна** | Результат залежить від «сьогодні»; без підміни тест ламався б з часом. З моком перевіряємо межові дати (день перед, у день, після терміну). |
| Flask | `test_send_overdue_notice_mocks_http` | `app.services.requests.post` (сервіс сповіщень) | зовнішня | Не відправляємо реальних запитів, перевіряємо формування запиту. |
| Flask | `test_calc_fine_with_mocked_today` | `app.services.today` | внутрішня | Детермінований розрахунок штрафу для довільної дати. |

Перевірка викликів: `mock_get.assert_called_once_with(URL, params=…, timeout=5)`, `mock_post.assert_called_once_with(URL, json=…, timeout=5)`, `mock_today.assert_called_once_with()`, а у тесті повернутої видачі `mock_today.assert_not_called()` (годинник не повинен використовуватись). Мокалася лише зовнішня/побічна залежність, сама логіка (`is_loan_overdue`, `calc_fine`, розбір JSON) виконується реально.

### 7.2 Покриття (`pytest --cov`, з `--cov-branch`)
Django:
```
$ pytest --cov=library --cov-branch --cov-report=term-missing
...........................                                              [100%]
================================ tests coverage ================================
_______________ coverage: platform linux, python 3.12.3-final-0 ________________

Name                                       Stmts   Miss Branch BrPart  Cover   Missing
--------------------------------------------------------------------------------------
library/__init__.py                            0      0      0      0   100%
library/admin.py                               4      0      2      0   100%
library/apps.py                                3      0      0      0   100%
library/migrations/0001_initial.py             7      0      0      0   100%
library/migrations/0002_book_language.py       4      0      0      0   100%
library/migrations/__init__.py                 0      0      0      0   100%
library/models.py                             60      0      0      0   100%
library/services.py                           14      0      4      0   100%
library/urls.py                                4      0      0      0   100%
library/views.py                              16      0      2      0   100%
--------------------------------------------------------------------------------------
TOTAL                                        112      0      8      0   100%
27 passed in 4.96s
```
Flask:
```
$ pytest --cov=app --cov-branch --cov-report=term-missing
.........................                                                [100%]
================================ tests coverage ================================
_______________ coverage: platform linux, python 3.12.3-final-0 ________________

Name              Stmts   Miss Branch BrPart  Cover   Missing
-------------------------------------------------------------
app/__init__.py      15      0      0      0   100%
app/config.py         8      0      0      0   100%
app/models.py        55      2      0      0    96%   67, 91
app/routes.py        38      0     10      0   100%
app/services.py      32      2      6      2    89%   19, 36
-------------------------------------------------------------
TOTAL               148      4     16      2    96%
25 passed in 1.11s
```
**Колонки:** `Stmts`: кількість виконуваних операторів у модулі; `Miss`: скільки з них жодного разу не виконалось; `Branch`: кількість гілок (умовних переходів); `BrPart`: гілки, пройдені лише частково (наприклад, `if` перевірено лише в одному напрямку); `Cover`: відсоток покриття; `Missing`: номери рядків (і переходи), що не виконались.

**Аналіз прогалин.**
- Django: усі 112 операторів і 8 гілок покрито (100%). Слід розуміти, що 100% покриття означає лише «кожен рядок виконано», а не «усе правильно перевірено». Показник охоплює й файли міграцій та `admin.py`, що вони виконуються під час імпорту. Порожню заглушку `library/tests.py` від `startapp` видалено, бо вона штучно знижувала покриття (тести живуть у `tests/`).
- Flask, `app/models.py` (96%): не виконано рядки 67 і 91, тобто `__repr__` моделей `Reader` та `Loan`. Це допоміжне відлагоджувальне представлення, прогалина виправдана, але закривається одним тестом.
- Flask, `app/services.py` (89%, 2 часткові гілки): рядок 19, `return 0` у `calc_fine` для вже повернутої книги, і рядок 36, `raise ValueError('Книгу або читача не знайдено')` у `lend_book`. Це **змістовні** гілки (повернута книга не має штрафу; видача неіснуючої книги), їх варто покрити тестами в першу чергу.
- `app/routes.py` і `app/__init__.py`: 100%.

Загальна оцінка: критичні шляхи (CRUD, обмеження, транзакції, HTTP) покриті; залишок прогалин у Flask: дві гілки сервісного шару та два `__repr__`.

---
## Висновки
Реалізовано предметну область «бібліотека» у Django (5 моделей, зв'язки FK/M2M/1:1, політики `PROTECT`/`CASCADE`) та Flask (аналогічна схема, явна `db.Table`), оформлено ланцюжки міграцій (по 2 в кожному фреймворку), виконано CRUD, агрегацію, анотацію, `Q`-об'єкти й оптимізацію N+1 (5 → 1 і 2 запити), транзакційний `rollback`. Написано 52 PyTest-тести (моделі, HTTP, моки), покриття: Django 100%, Flask 96%.
