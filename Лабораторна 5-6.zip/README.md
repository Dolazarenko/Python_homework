# Реєстрація на події: Django та Flask

## Django
    cd events_django
    python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
    pip install -r requirements.txt
    python manage.py runserver                         # http://127.0.0.1:8000
Необов'язково: `export DJANGO_SECRET_KEY=...` (інакше ключ генерується випадково).

## Flask
    cd events_flask
    python -m venv venv && source venv/bin/activate
    pip install -r requirements.txt
    flask --app app run --debug                        # http://127.0.0.1:5000
Необов'язково: `export FLASK_SECRET_KEY=...`.

## Перевірка CSRF
    curl -i -X POST -d "name=x" http://127.0.0.1:8000/register/   # Django -> 403
    curl -i -X POST -d "name=x" http://127.0.0.1:5000/register    # Flask  -> 400
