"""Швидка перевірка (запуск: python manage.py shell < tests_manual.py)."""
from django.test.utils import setup_test_environment; setup_test_environment()
from django.test import Client
c = Client()
for url in ("/", "/events/", "/register/"):
    r = c.get(url); print(url, r.status_code)
c = Client(enforce_csrf_checks=True)
r = c.post("/register/", {"name": "Тест"}); print("POST без CSRF:", r.status_code)
c = Client()
r = c.post("/register/", {"name": "Іван1", "email": "bad", "ticket_type": "", "message": "мало слів"})
print("невалідна:", r.status_code, [e for e in r.context["form"].errors])
r = c.post("/register/", {"name": "Іван Петренко", "email": "a@b.ua", "ticket_type": "vip",
    "message": "Хочу взяти участь у події цього разу"}, follow=True)
print("валідна:", r.redirect_chain, [str(m) for m in r.context["messages"]])
