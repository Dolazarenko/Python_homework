import datetime

from django.contrib import messages
from django.shortcuts import redirect, render

from .forms import RegistrationForm

EVENTS = [
    {
        "title": "Python Meetup Київ",
        "date": datetime.date(2026, 11, 14),
        "seats": 80,
        "description": "Зустріч розробників: доповіді про Django, Flask та тестування вебзастосунків із практичними прикладами.",
    },
    {
        "title": "Воркшоп з веброзробки",
        "date": datetime.date(2026, 12, 3),
        "seats": 30,
        "description": "Практичний воркшоп: за один день створюємо невеликий вебзастосунок від шаблонів до форм.",
    },
    {
        "title": "Хакатон «Відкриті дані»",
        "date": datetime.date(2027, 1, 22),
        "seats": 0,
        "description": "Командний хакатон із відкритими даними. Усі місця вже зайняті.",
    },
]


def home(request):
    context = {
        "site_name": "Реєстрація на події",       # рядок
        "events_count": len(EVENTS),               # число
        "upcoming": EVENTS[:2],                    # список
        "organizer": "",                           # порожнє -> фільтр default
    }
    return render(request, "events/home.html", context)


def event_list(request):
    context = {
        "events": EVENTS,
        "total_seats": sum(e["seats"] for e in EVENTS),
        "heading": "Усі події",
    }
    return render(request, "events/event_list.html", context)


def register(request):
    if request.method == "POST":
        form = RegistrationForm(request.POST)
        if form.is_valid():
            messages.success(
                request,
                f"Дякуємо, {form.cleaned_data['name']}! Реєстрацію прийнято.",
            )
            return redirect("events:register")  # Post/Redirect/Get
    else:
        form = RegistrationForm()
    return render(request, "events/register.html", {"form": form})
