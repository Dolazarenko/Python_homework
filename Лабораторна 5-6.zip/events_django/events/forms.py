from django import forms

TICKET_CHOICES = [
    ("", "— оберіть тип квитка —"),
    ("standard", "Стандартний"),
    ("student", "Студентський"),
    ("vip", "VIP"),
]


class RegistrationForm(forms.Form):
    """Форма реєстрації на подію (завдання 4)."""

    name = forms.CharField(
        label="Ім'я та прізвище",
        max_length=50,
        error_messages={
            "required": "Вкажіть ім'я.",
            "max_length": "Ім'я не може бути довшим за 50 символів.",
        },
    )
    email = forms.EmailField(
        label="Електронна пошта",
        error_messages={
            "required": "Вкажіть електронну пошту.",
            "invalid": "Введіть коректну адресу електронної пошти.",
        },
    )
    ticket_type = forms.ChoiceField(
        label="Тип квитка",
        choices=TICKET_CHOICES,
        error_messages={
            "required": "Оберіть тип квитка.",
            "invalid_choice": "Оберіть варіант зі списку.",
        },
    )
    message = forms.CharField(
        label="Повідомлення організаторам",
        widget=forms.Textarea(attrs={"rows": 4}),
        error_messages={"required": "Напишіть кілька слів організаторам."},
    )

    # Кастомні валідації (бізнес-правила)
    def clean_name(self):
        name = self.cleaned_data["name"].strip()
        if any(ch.isdigit() for ch in name):
            raise forms.ValidationError("Ім'я не повинно містити цифр.")
        return name

    def clean_message(self):
        message = self.cleaned_data["message"].strip()
        if len(message.split()) < 5:
            raise forms.ValidationError(
                "Повідомлення має містити щонайменше 5 слів."
            )
        return message
