import datetime

from flask import Flask, flash, redirect, render_template, url_for

from flask_wtf.csrf import CSRFProtect

from config import Config
from forms import RegistrationForm

app = Flask(__name__)  # шаблони: ./templates, статика: ./static
app.config.from_object(Config)
csrf = CSRFProtect(app)  # глобальний CSRF-захист: POST без токена -> 400

EVENTS = [
    {
        "title": "Python Meetup Київ",
        "date": datetime.date(2026, 11, 14),
        "seats": 80,
        "registered": 52,
        "description": "Зустріч розробників: доповіді про Django, Flask та тестування вебзастосунків із практичними прикладами.",
    },
    {
        "title": "Воркшоп з веброзробки",
        "date": datetime.date(2026, 12, 3),
        "seats": 30,
        "registered": 12,
        "description": "Практичний воркшоп: за один день створюємо невеликий вебзастосунок від шаблонів до форм.",
    },
    {
        "title": "Хакатон «Відкриті дані»",
        "date": datetime.date(2027, 1, 22),
        "seats": 40,
        "registered": 40,
        "description": "Командний хакатон із відкритими даними. Усі місця вже зайняті.",
    },
]


@app.context_processor
def inject_year():
    return {"current_year": datetime.date.today().year}


@app.route("/")
def home():
    return render_template(
        "home.html",
        site_name="Реєстрація на події",   # рядок
        events_count=len(EVENTS),           # число
        upcoming=EVENTS[:2],                # список
        organizer="",
    )


@app.route("/events")
def event_list():
    return render_template("event_list.html", events=EVENTS, heading="Усі події")


@app.route("/register", methods=["GET", "POST"])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        flash(f"Дякуємо, {form.name.data.strip()}! Реєстрацію прийнято.", "success")
        return redirect(url_for("register"))  # Post/Redirect/Get
    return render_template("register.html", form=form)


if __name__ == "__main__":
    app.run(debug=True)
