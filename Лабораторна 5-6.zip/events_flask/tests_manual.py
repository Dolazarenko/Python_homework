"""Швидка перевірка: python tests_manual.py"""
import re
from app import app

c = app.test_client()
for url in ("/", "/events", "/register"):
    print(url, c.get(url).status_code)

# POST без CSRF-токена
print("POST без CSRF:", c.post("/register", data={"name": "Тест"}).status_code)

def token(client):
    html = client.get("/register").get_data(as_text=True)
    return re.search(r'name="csrf_token"[^>]*value="([^"]+)"', html).group(1)

t = token(c)
r = c.post("/register", data={"csrf_token": t, "name": "Іван1", "email": "bad",
                              "ticket_type": "", "message": "мало слів"})
html = r.get_data(as_text=True)
print("невалідна:", r.status_code, html.count('class="error"'), "помилок")
r = c.post("/register", data={"csrf_token": t, "name": "Іван Петренко", "email": "a@b.ua",
    "ticket_type": "vip", "message": "Хочу взяти участь у події цього разу"}, follow_redirects=True)
print("валідна:", "Реєстрацію прийнято" in r.get_data(as_text=True))
