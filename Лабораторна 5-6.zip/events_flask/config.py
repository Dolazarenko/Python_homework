import os
import secrets


class Config:
    # Секретний ключ береться зі змінної середовища і не зберігається в репозиторії.
    # Без змінної (локальна розробка) генерується тимчасовий випадковий ключ.
    SECRET_KEY = os.environ.get("FLASK_SECRET_KEY") or secrets.token_hex(32)
    WTF_CSRF_ENABLED = True
