from flask_wtf import FlaskForm
from wtforms import SelectField, StringField, SubmitField, TextAreaField
from wtforms.validators import DataRequired, Email, Length, ValidationError

TICKET_CHOICES = [
    ("", "— оберіть тип квитка —"),
    ("standard", "Стандартний"),
    ("student", "Студентський"),
    ("vip", "VIP"),
]


class RegistrationForm(FlaskForm):
    """Еквівалент Django-форми із завдання 4."""

    name = StringField(
        "Ім'я та прізвище",
        validators=[
            DataRequired(message="Вкажіть ім'я."),
            Length(max=50, message="Ім'я не може бути довшим за 50 символів."),
        ],
    )
    email = StringField(
        "Електронна пошта",
        validators=[
            DataRequired(message="Вкажіть електронну пошту."),
            Email(message="Введіть коректну адресу електронної пошти."),
        ],
    )
    ticket_type = SelectField(
        "Тип квитка",
        choices=TICKET_CHOICES,
        validators=[DataRequired(message="Оберіть тип квитка.")],
    )
    message = TextAreaField(
        "Повідомлення організаторам",
        validators=[DataRequired(message="Напишіть кілька слів організаторам.")],
        render_kw={"rows": 4},
    )
    submit = SubmitField("Зареєструватися")

    # Кастомні валідації (бізнес-правила)
    def validate_name(self, field):
        if any(ch.isdigit() for ch in field.data):
            raise ValidationError("Ім'я не повинно містити цифр.")

    def validate_message(self, field):
        if len(field.data.split()) < 5:
            raise ValidationError("Повідомлення має містити щонайменше 5 слів.")
