"""CRUD: Create та Read для блогу (практична №7, завдання 2.1).

Запуск: python practical_07_task_2_1.py   ->   http://127.0.0.1:5003/posts

Файл також використовується завданням 2.2 (імпорт app, posts_db і функцій).
"""

import math
from datetime import datetime

from flask import Flask, abort, flash, get_flashed_messages, redirect, render_template_string, request, url_for

app = Flask(__name__)
app.secret_key = "blog-secret-key"

PER_PAGE = 5
TITLE_MAX = 120
AUTHOR_MAX = 60

# HTML-шаблони

LIST_TEMPLATE = """
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Блог</title></head>
<body>
    <h1>Публікації</h1>
    {% for message in messages %}
        <div style="color: green;">{{ message }}</div>
    {% endfor %}
    <a href="{{ url_for('post_create') }}">+ Нова публікація</a>
    <hr>
    {% for post in posts %}
    <article>
        <h2><a href="{{ url_for('post_detail', post_id=post.id) }}">{{ post.title }}</a></h2>
        <p>{{ post.content[:100] }}{% if post.content|length > 100 %}...{% endif %}</p>
        <small>{{ post.author }} | {{ post.created_at }}</small>
    </article>
    <hr>
    {% else %}
    <p>Публікацій поки немає.</p>
    {% endfor %}
    <p>
        {% if page > 1 %}<a href="{{ url_for('post_list', page=page-1) }}">« Попередня</a>{% endif %}
        Сторінка {{ page }} з {{ pages }}
        {% if page < pages %}<a href="{{ url_for('post_list', page=page+1) }}">Наступна »</a>{% endif %}
    </p>
</body>
</html>
"""

DETAIL_TEMPLATE = """
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>{{ post.title }}</title></head>
<body>
    {% for message in messages %}
        <div style="color: green;">{{ message }}</div>
    {% endfor %}
    <h1>{{ post.title }}</h1>
    <p><small>{{ post.author }} | {{ post.created_at }}</small></p>
    <p>{{ post.content }}</p>
    <p>
        {% if can_edit %}
        <a href="{{ url_for('post_edit', post_id=post.id) }}">Редагувати</a> |
        <a href="{{ url_for('post_delete', post_id=post.id) }}">Видалити</a> |
        {% endif %}
        <a href="{{ url_for('post_list') }}">До списку</a>
    </p>
</body>
</html>
"""

FORM_TEMPLATE = """
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>{{ form_title }}</title></head>
<body>
    <h1>{{ form_title }}</h1>
    {% if errors %}
    <ul style="color: red;">
        {% for error in errors %}<li>{{ error }}</li>{% endfor %}
    </ul>
    {% endif %}
    <form method="POST">
        <label>Заголовок:</label><br>
        <input type="text" name="title" value="{{ post.title if post else '' }}"
               required maxlength="120" style="width:400px;"><br><br>
        <label>Автор:</label><br>
        <input type="text" name="author" value="{{ post.author if post else '' }}"
               required maxlength="60"><br><br>
        <label>Зміст:</label><br>
        <textarea name="content" rows="10" cols="50"
                  required>{{ post.content if post else '' }}</textarea><br><br>
        <button type="submit">{{ button_text }}</button>
        <a href="{{ url_for('post_list') }}">Скасувати</a>
    </form>
</body>
</html>
"""

# Тимчасове сховище. Для завдання 2.1 порожнє, завдання 2.2 додає приклади.
posts_db: list[dict] = []


# ----- Допоміжні функції -----

def new_post_id() -> int:
    """Наступний вільний id. Обчислюється з даних, тож працює і з імпортом модуля."""
    return max((p["id"] for p in posts_db), default=0) + 1


def find_post(post_id: int) -> dict:
    """Повертає публікацію або викликає 404."""
    post = next((p for p in posts_db if p["id"] == post_id), None)
    if post is None:
        abort(404)
    return post


def validate_post_form(form) -> tuple[dict, list[str]]:
    """Перевіряє дані форми публікації.

    Returns:
        (очищені дані, список помилок). Список порожній, якщо дані коректні.
    """
    data = {
        "title": form.get("title", "").strip(),
        "author": form.get("author", "").strip(),
        "content": form.get("content", "").strip(),
    }
    errors = []
    if not data["title"]:
        errors.append("Заголовок не може бути порожнім")
    elif len(data["title"]) > TITLE_MAX:
        errors.append(f"Заголовок має бути не довшим за {TITLE_MAX} символів")
    if not data["author"]:
        errors.append("Вкажіть автора")
    elif len(data["author"]) > AUTHOR_MAX:
        errors.append(f"Ім'я автора має бути не довшим за {AUTHOR_MAX} символів")
    if not data["content"]:
        errors.append("Зміст не може бути порожнім")
    return data, errors


# ----- READ -----

@app.route("/posts")
def post_list():
    """READ: список публікацій з пагінацією (?page=1)."""
    try:
        page = int(request.args.get("page", 1))
    except ValueError:
        abort(400)
    if page < 1:
        abort(400)

    pages = max(1, math.ceil(len(posts_db) / PER_PAGE))
    if page > pages:
        abort(404)
    start = (page - 1) * PER_PAGE
    newest_first = sorted(posts_db, key=lambda p: p["id"], reverse=True)
    posts = newest_first[start:start + PER_PAGE]
    return render_template_string(LIST_TEMPLATE, posts=posts, page=page, pages=pages,
                                  messages=get_flashed_messages())


@app.route("/posts/<int:post_id>")
def post_detail(post_id: int):
    """READ: деталі однієї публікації або 404."""
    post = find_post(post_id)
    # Посилання на редагування й видалення з'являються лише тоді,
    # коли відповідні маршрути зареєстровано (їх додає завдання 2.2).
    can_edit = 'post_edit' in app.view_functions and 'post_delete' in app.view_functions
    return render_template_string(DETAIL_TEMPLATE, post=post, can_edit=can_edit,
                                  messages=get_flashed_messages())


# ----- CREATE -----

@app.route("/posts/create", methods=["GET", "POST"])
def post_create():
    """CREATE: форма (GET) і збереження нової публікації (POST)."""
    if request.method == "POST":
        data, errors = validate_post_form(request.form)
        if errors:
            # Повторно показуємо форму з введеними даними і списком помилок
            return render_template_string(
                FORM_TEMPLATE, post=data, errors=errors,
                form_title="Нова публікація", button_text="Створити",
            ), 400

        post = {"id": new_post_id(), **data,
                "created_at": datetime.now().strftime("%Y-%m-%d %H:%M")}
        posts_db.append(post)
        flash("Публікацію створено")
        return redirect(url_for("post_detail", post_id=post["id"]))

    return render_template_string(FORM_TEMPLATE, post=None, errors=[],
                                  form_title="Нова публікація", button_text="Створити")


if __name__ == "__main__":
    app.run(debug=True, port=5003)
