"""REST API: серіалізація, фільтрація, авторизація та обробка помилок (практична №7, завдання 3.2).

Запуск: python practical_07_task_3_2.py   ->   http://127.0.0.1:5006/api/v2/students

Приклади з API-ключем:  заголовок  X-API-Key: secret-api-key-123
"""

import logging
import re
import time
from datetime import datetime
from functools import wraps

from flask import Flask, g, jsonify, request

app = Flask(__name__)
app.json.ensure_ascii = False

API_KEY = "secret-api-key-123"
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
ALLOWED_FIELDS = {"id", "name", "group", "email", "gpa", "grade", "created_at"}
SORT_FIELDS = {"id", "name", "group", "gpa"}
GRADE_SCALE = [(90, "A"), (80, "B"), (70, "C"), (60, "D")]

logger = logging.getLogger("students_api")

students_db: dict[int, dict] = {}
next_id = 1


# ----- Винятки API -----

class APIError(Exception):
    """Базове виключення API. Обробляється централізовано через errorhandler."""

    def __init__(self, message: str, status_code: int = 400, details: dict | None = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.details = details or {}


@app.errorhandler(APIError)
def handle_api_error(error: APIError):
    """Єдиний формат JSON-помилок для всього API."""
    body = {
        "error": error.message,
        "status": error.status_code,
        "details": error.details,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
    }
    return jsonify(body), error.status_code


@app.errorhandler(404)
def not_found(error):
    return handle_api_error(APIError("Ресурс не знайдено", 404))


@app.errorhandler(405)
def method_not_allowed(error):
    return handle_api_error(APIError("Метод не дозволено", 405))


# ----- Серіалізатор -----

class StudentSerializer:
    """Перетворює внутрішній запис студента у відповідь API і назад."""

    @staticmethod
    def grade(gpa: float) -> str:
        for threshold, letter in GRADE_SCALE:
            if gpa >= threshold:
                return letter
        return "F"

    @staticmethod
    def serialize(student: dict, fields: list[str] | None = None) -> dict:
        """Повертає студента для відповіді.

        Додає обчислене поле grade, форматує дату, а за наявності fields
        повертає лише вказані поля.
        """
        created = datetime.fromisoformat(student["created_at"]).strftime("%Y-%m-%d %H:%M")
        data = {**student, "created_at": created, "grade": StudentSerializer.grade(student["gpa"])}
        if fields:
            return {name: data[name] for name in fields if name in data}
        return {name: data[name] for name in ALLOWED_FIELDS if name in data}

    @staticmethod
    def deserialize(data: dict, partial: bool = False) -> tuple[dict, dict]:
        """Перевіряє та очищає вхідні дані. Повертає (чисті дані, помилки)."""
        clean, errors = {}, {}
        required = [] if partial else ["name", "group", "email", "gpa"]
        for field in required:
            if field not in data:
                errors[field] = "обов'язкове поле"

        if "name" in data:
            value = data["name"]
            if isinstance(value, str) and value.strip():
                clean["name"] = value.strip()
            else:
                errors["name"] = "непорожній рядок"
        if "group" in data:
            value = data["group"]
            if isinstance(value, str) and value.strip():
                clean["group"] = value.strip()
            else:
                errors["group"] = "непорожній рядок"
        if "email" in data:
            value = data["email"]
            if isinstance(value, str) and EMAIL_RE.match(value.strip()):
                clean["email"] = value.strip().lower()
            else:
                errors["email"] = "некоректний формат e-mail"
        if "gpa" in data:
            value = data["gpa"]
            if isinstance(value, bool) or not isinstance(value, (int, float, str)):
                errors["gpa"] = "число від 0 до 100"
            else:
                try:
                    gpa = float(value)  # перетворення типу: рядок "88.5" також допустимий
                except ValueError:
                    errors["gpa"] = "число від 0 до 100"
                else:
                    if 0 <= gpa <= 100:
                        clean["gpa"] = gpa
                    else:
                        errors["gpa"] = "число від 0 до 100"
        return clean, errors

    @staticmethod
    def serialize_list(students: list[dict], fields: list[str] | None = None) -> list[dict]:
        return [StudentSerializer.serialize(s, fields) for s in students]


# ----- Middleware -----

@app.before_request
def log_request():
    """Запам'ятовує час початку і записує метод та адресу запиту."""
    g.start = time.perf_counter()
    logger.info("→ %s %s", request.method, request.full_path.rstrip("?"))


@app.after_request
def add_headers(response):
    """Додає X-Request-Time і CORS-заголовок до кожної відповіді та логує її статус."""
    duration_ms = (time.perf_counter() - g.get("start", time.perf_counter())) * 1000
    response.headers["X-Request-Time"] = f"{duration_ms:.2f} ms"
    response.headers["Access-Control-Allow-Origin"] = "*"
    logger.info("← %s %s", response.status_code, request.path)
    return response


# ----- Авторизація -----

def require_api_key(f):
    """Дозволяє запит лише з правильним заголовком X-API-Key, інакше 401."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        if request.headers.get("X-API-Key") != API_KEY:
            raise APIError("Невірний або відсутній API-ключ", 401)
        return f(*args, **kwargs)
    return wrapper


# ----- Допоміжні -----

def parse_fields(raw: str | None) -> list[str] | None:
    if not raw:
        return None
    fields = [f.strip() for f in raw.split(",") if f.strip()]
    unknown = [f for f in fields if f not in ALLOWED_FIELDS]
    if unknown:
        raise APIError("Невідомі поля у параметрі fields", 400,
                       {"unknown": unknown, "allowed": sorted(ALLOWED_FIELDS)})
    return fields


# ----- Ендпоінти -----

@app.route("/api/v2/students", methods=["GET"])
def get_students_v2():
    """Список студентів.

    Параметри:
        fields  — які поля повернути, наприклад ?fields=name,gpa
        search  — текстовий пошук у name, group, email
        sort    — поле сортування (id, name, group, gpa)
        order   — asc або desc
    """
    fields = parse_fields(request.args.get("fields"))
    search = request.args.get("search", "").strip().lower()
    sort = request.args.get("sort", "id")
    order = request.args.get("order", "asc")

    if sort not in SORT_FIELDS:
        raise APIError("Недопустиме поле сортування", 400, {"allowed": sorted(SORT_FIELDS)})
    if order not in {"asc", "desc"}:
        raise APIError("Недопустимий напрямок сортування", 400, {"allowed": ["asc", "desc"]})

    result = list(students_db.values())
    if search:
        result = [s for s in result
                  if search in s["name"].lower() or search in s["group"].lower()
                  or search in s["email"]]
    result.sort(key=lambda s: s[sort], reverse=(order == "desc"))

    return jsonify({
        "count": len(result),
        "students": StudentSerializer.serialize_list(result, fields),
    }), 200


@app.route("/api/v2/students", methods=["POST"])
@require_api_key
def create_student_v2():
    """Створення студента з авторизацією і десеріалізацією. 201 при успіху."""
    global next_id
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        raise APIError("Очікується JSON-об'єкт у тілі запиту", 400)

    clean, errors = StudentSerializer.deserialize(data)
    if errors:
        raise APIError("Помилка валідації", 400, errors)
    if any(s["email"] == clean["email"] for s in students_db.values()):
        raise APIError("Студент з таким e-mail уже існує", 409)

    student = {"id": next_id, **clean, "created_at": datetime.now().isoformat(timespec="seconds")}
    students_db[next_id] = student
    next_id += 1
    return jsonify(StudentSerializer.serialize(student)), 201


def seed_demo_data() -> None:
    global next_id
    demo = [
        {"name": "Іваненко О.", "group": "КІ-21", "email": "ivan@kpi.ua", "gpa": 85.5},
        {"name": "Петренко М.", "group": "КІ-21", "email": "petro@kpi.ua", "gpa": 92.0},
        {"name": "Сидоренко А.", "group": "КІ-22", "email": "syd@kpi.ua", "gpa": 78.3},
        {"name": "Коваль Л.", "group": "КІ-22", "email": "koval@kpi.ua", "gpa": 95.1},
    ]
    for record in demo:
        students_db[next_id] = {"id": next_id, **record,
                                "created_at": datetime.now().isoformat(timespec="seconds")}
        next_id += 1


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s", datefmt="%H:%M:%S")
    seed_demo_data()
    app.run(debug=True, port=5006)
