"""Cookies та sessions у Flask (практична №6, завдання 1.3).

Запуск: python practical_06_task_1_3.py   ->   http://127.0.0.1:5002/

Різниця між cookies і sessions:
  * cookie зберігається у браузері, клієнт може її змінити; сервер лише читає її з кожним запитом;
  * session зберігається у cookie 'session', але вміст підписано секретним ключем.
    Клієнт бачить вміст (він закодований, не зашифрований), але змінити його без ключа не може.
    Тому в session можна тримати стан (кошик, ім'я користувача), але не паролі чи секрети.
"""

from datetime import timedelta

from flask import Flask, jsonify, make_response, redirect, request, session, url_for, abort

app = Flask(__name__)
app.json.ensure_ascii = False

app.secret_key = "super-secret-key-for-session"  # для підпису сесій
app.permanent_session_lifetime = timedelta(days=30)
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")

COOKIE_MAX_AGE = 30 * 24 * 60 * 60  # 30 днів у секундах
THEMES = {"light", "dark"}
LANGUAGES = {"uk", "en"}

LOGIN_FORM = """
<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Вхід</title></head>
<body>
    <h1>Вхід</h1>
    <form method="POST" action="/login">
        <input type="text" name="username" placeholder="Ім'я" required>
        <button type="submit">Увійти</button>
    </form>
</body></html>
"""

# Тимчасова "база" товарів
products_db = {
    1: {"name": "Ноутбук", "price": 25000},
    2: {"name": "Смартфон", "price": 12000},
    3: {"name": "Навушники", "price": 2000},
}


# ----- Cookies -----

@app.route("/set-theme/<theme>")
def set_theme(theme: str):
    """Встановити тему (light або dark) у cookie 'theme' на 30 днів."""
    if theme not in THEMES:
        return jsonify({"error": f"Тема має бути одною з: {', '.join(sorted(THEMES))}"}), 400
    response = make_response(jsonify({"theme": theme, "saved": True}))
    response.set_cookie("theme", theme, max_age=COOKIE_MAX_AGE,
                        httponly=True, samesite="Lax")
    return response


@app.route("/get-theme")
def get_theme():
    """Прочитати тему з cookie. Якщо cookie немає — 'light'."""
    return jsonify({"theme": request.cookies.get("theme", "light")})


@app.route("/set-language/<lang>")
def set_language(lang: str):
    """Встановити мову у cookie 'language'."""
    if lang not in LANGUAGES:
        return jsonify({"error": f"Мова має бути одною з: {', '.join(sorted(LANGUAGES))}"}), 400
    response = make_response(jsonify({"language": lang, "saved": True}))
    response.set_cookie("language", lang, max_age=COOKIE_MAX_AGE,
                        httponly=True, samesite="Lax")
    return response


@app.route("/preferences")
def preferences():
    """Усі cookies, які браузер надіслав із запитом."""
    return jsonify(dict(request.cookies))


# ----- Sessions: кошик -----

@app.route("/cart/add/<int:product_id>")
def add_to_cart(product_id: int):
    """Додати товар до кошика, який зберігається в session."""
    if product_id not in products_db:
        abort(404)
    cart = list(session.get("cart", []))
    cart.append(product_id)
    session["cart"] = cart  # присвоєння, а не зміна списку на місці, гарантує збереження session
    return jsonify({"added": products_db[product_id]["name"], "cart_size": len(cart)})


@app.route("/cart")
def view_cart():
    """Вміст кошика з назвами, цінами та підсумком."""
    items = []
    total = 0
    for product_id in session.get("cart", []):
        product = products_db[product_id]
        items.append({"id": product_id, **product})
        total += product["price"]
    return jsonify({"items": items, "count": len(items), "total": total})


@app.route("/cart/clear")
def clear_cart():
    """Очистити кошик."""
    session.pop("cart", None)
    return jsonify({"cart": [], "message": "Кошик очищено"})


# ----- Sessions: авторизація (імітація) -----

@app.route("/login", methods=["GET", "POST"])
def login():
    """GET — форма входу. POST — зберегти ім'я користувача в session.

    Для JSON-запиту повертається JSON, для звичайної форми — redirect на профіль.
    """
    if request.method == "GET":
        return LOGIN_FORM

    if request.is_json:
        username = (request.get_json(silent=True) or {}).get("username", "")
    else:
        username = request.form.get("username", "")
    username = str(username).strip()
    if not (1 <= len(username) <= 30):
        return jsonify({"error": "Ім'я має містити від 1 до 30 символів"}), 400

    session.permanent = True
    session["username"] = username
    if request.is_json:
        return jsonify({"message": "Вхід виконано", "username": username})
    return redirect(url_for("profile"))


@app.route("/logout")
def logout():
    """Вихід: видалити ім'я користувача з session."""
    session.pop("username", None)
    return jsonify({"message": "Вихід виконано"})


@app.route("/profile")
def profile():
    """Профіль доступний лише авторизованому користувачу. Інакше — redirect на вхід."""
    username = session.get("username")
    if not username:
        return redirect(url_for("login"))
    return jsonify({"username": username, "cart_size": len(session.get("cart", []))})


# ----- Порівняння cookies і sessions -----

@app.route("/storage")
def storage():
    """Показує окремо вміст cookies (зберігаються у браузері) і session (підписані дані)."""
    return jsonify({
        "cookies": dict(request.cookies),
        "session": dict(session),
    })


if __name__ == "__main__":
    app.run(debug=True, port=5002)
