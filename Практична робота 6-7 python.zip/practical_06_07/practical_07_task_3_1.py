"""REST API для ресурсу «Студент» (практична №7, завдання 3.1).

Запуск: python practical_07_task_3_1.py   ->   http://127.0.0.1:5005/api/students

Коди відповідей:
  200 — успішний GET, PUT, PATCH
  201 — створено (POST), із заголовком Location
  204 — видалено (DELETE), без тіла
  400 — некоректні дані або параметри запиту
  404 — ресурс не знайдено
  409 — конфлікт: email уже зайнятий
"""

import re
from datetime import datetime

from flask import Flask, abort, jsonify, request, url_for

app = Flask(__name__)
app.json.ensure_ascii = False

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
SORT_FIELDS = {"id", "name", "group", "gpa"}

# "База даних" студентів: id -> запис
students_db: dict[int, dict] = {}
next_id = 1


# ----- Валідація -----

def validate_student(data: dict, partial: bool = False) -> tuple[dict, dict]:
    """Перевіряє дані студента.

    Args:
        data: вхідний JSON-об'єкт.
        partial: якщо True, перевіряються лише передані поля (для PATCH).

    Returns:
        (очищені поля, словник помилок {поле: повідомлення}).
    """
    clean, errors = {}, {}
    required = [] if partial else ["name", "group", "email", "gpa"]

    for field in required:
        if field not in data:
            errors[field] = "обов'язкове поле"

    if "name" in data:
        name = data["name"]
        if not isinstance(name, str) or not name.strip() or len(name) > 100:
            errors["name"] = "рядок від 1 до 100 символів"
        else:
            clean["name"] = name.strip()

    if "group" in data:
        group = data["group"]
        if not isinstance(group, str) or not group.strip() or len(group) > 20:
            errors["group"] = "рядок від 1 до 20 символів"
        else:
            clean["group"] = group.strip()

    if "email" in data:
        email = data["email"]
        if not isinstance(email, str) or not EMAIL_RE.match(email.strip()):
            errors["email"] = "некоректний формат e-mail"
        else:
            clean["email"] = email.strip().lower()

    if "gpa" in data:
        gpa = data["gpa"]
        if isinstance(gpa, bool) or not isinstance(gpa, (int, float)) or not 0 <= gpa <= 100:
            errors["gpa"] = "число від 0 до 100"
        else:
            clean["gpa"] = float(gpa)

    return clean, errors


def json_body() -> dict:
    """Повертає JSON-об'єкт з тіла запиту або викликає 400."""
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        abort(400, description="Очікується JSON-об'єкт у тілі запиту")
    return data


def email_taken(email: str, exclude_id: int | None = None) -> bool:
    return any(s["email"] == email and s["id"] != exclude_id for s in students_db.values())


def get_or_404(student_id: int) -> dict:
    student = students_db.get(student_id)
    if student is None:
        abort(404)
    return student


def int_arg(name: str, default: int, minimum: int = 1, maximum: int | None = None) -> int:
    raw = request.args.get(name)
    if raw is None:
        return default
    try:
        value = int(raw)
    except ValueError:
        abort(400, description=f"Параметр '{name}' має бути цілим числом")
    if value < minimum or (maximum is not None and value > maximum):
        abort(400, description=f"Параметр '{name}' поза допустимим діапазоном")
    return value


# ----- Ендпоінти -----

@app.route("/api/students", methods=["GET"])
def get_students():
    """Список студентів з фільтрами group, min_gpa, сортуванням, пагінацією."""
    group = request.args.get("group", "").strip().lower()
    min_gpa_raw = request.args.get("min_gpa")
    sort_by = request.args.get("sort_by", "id")
    order = request.args.get("order", "asc")
    page = int_arg("page", default=1)
    per_page = int_arg("per_page", default=10, maximum=100)

    if sort_by not in SORT_FIELDS:
        return jsonify({"error": "Помилка параметра", "details": {
            "sort_by": f"має бути одним із: {', '.join(sorted(SORT_FIELDS))}"}}), 400
    if order not in {"asc", "desc"}:
        return jsonify({"error": "Помилка параметра", "details": {"order": "asc або desc"}}), 400

    result = list(students_db.values())
    if group:
        result = [s for s in result if s["group"].lower() == group]
    if min_gpa_raw is not None:
        try:
            min_gpa = float(min_gpa_raw)
        except ValueError:
            return jsonify({"error": "Помилка параметра", "details": {"min_gpa": "має бути числом"}}), 400
        result = [s for s in result if s["gpa"] >= min_gpa]

    result.sort(key=lambda s: s[sort_by], reverse=(order == "desc"))
    total = len(result)
    pages = max(1, -(-total // per_page))  # ceil без math
    start = (page - 1) * per_page
    return jsonify({
        "count": total,
        "page": page,
        "per_page": per_page,
        "pages": pages,
        "students": result[start:start + per_page],
    }), 200


@app.route("/api/students", methods=["POST"])
def create_student():
    """Створити студента. 201 із заголовком Location; 400 при помилках; 409 при дубліку email."""
    global next_id
    clean, errors = validate_student(json_body())
    if errors:
        return jsonify({"error": "Помилка валідації", "details": errors}), 400
    if email_taken(clean["email"]):
        return jsonify({"error": "Студент з таким e-mail уже існує"}), 409

    student = {"id": next_id, **clean, "created_at": datetime.now().isoformat(timespec="seconds")}
    students_db[next_id] = student
    next_id += 1

    response = jsonify(student)
    response.status_code = 201
    response.headers["Location"] = url_for("get_student", student_id=student["id"])
    return response


@app.route("/api/students/stats", methods=["GET"])
def students_stats():
    """Статистика: загальна кількість, середній бал, кількість по групах, топ-3 за балом."""
    students = list(students_db.values())
    groups: dict[str, int] = {}
    for s in students:
        groups[s["group"]] = groups.get(s["group"], 0) + 1
    avg = round(sum(s["gpa"] for s in students) / len(students), 2) if students else 0.0
    top = sorted(students, key=lambda s: s["gpa"], reverse=True)[:3]
    return jsonify({
        "total": len(students),
        "avg_gpa": avg,
        "groups": groups,
        "top_students": [{"id": s["id"], "name": s["name"], "gpa": s["gpa"]} for s in top],
    }), 200


@app.route("/api/students/<int:student_id>", methods=["GET"])
def get_student(student_id: int):
    """Деталі студента або 404."""
    return jsonify(get_or_404(student_id)), 200


@app.route("/api/students/<int:student_id>", methods=["PUT"])
def update_student(student_id: int):
    """Повне оновлення: усі поля обов'язкові."""
    student = get_or_404(student_id)
    clean, errors = validate_student(json_body())
    if errors:
        return jsonify({"error": "Помилка валідації", "details": errors}), 400
    if email_taken(clean["email"], exclude_id=student_id):
        return jsonify({"error": "Студент з таким e-mail уже існує"}), 409
    student.update(clean)
    return jsonify(student), 200


@app.route("/api/students/<int:student_id>", methods=["PATCH"])
def patch_student(student_id: int):
    """Часткове оновлення: змінюються лише передані поля."""
    student = get_or_404(student_id)
    clean, errors = validate_student(json_body(), partial=True)
    if errors:
        return jsonify({"error": "Помилка валідації", "details": errors}), 400
    if "email" in clean and email_taken(clean["email"], exclude_id=student_id):
        return jsonify({"error": "Студент з таким e-mail уже існує"}), 409
    student.update(clean)
    return jsonify(student), 200


@app.route("/api/students/<int:student_id>", methods=["DELETE"])
def delete_student(student_id: int):
    """Видалити студента. 204 без тіла або 404."""
    get_or_404(student_id)
    del students_db[student_id]
    return "", 204


# ----- Обробка помилок у JSON -----

@app.errorhandler(400)
def bad_request(error):
    return jsonify({"error": "Некоректний запит", "status": 400,
                    "details": error.description}), 400


@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Ресурс не знайдено", "status": 404}), 404


@app.errorhandler(405)
def method_not_allowed(error):
    return jsonify({"error": "Метод не дозволено", "status": 405}), 405


@app.errorhandler(422)
def unprocessable(error):
    return jsonify({"error": "Помилка валідації", "status": 422}), 422


def seed_demo_data() -> None:
    """Заповнює сховище тестовими студентами (для __main__ та демонстрації)."""
    global next_id
    demo = [
        {"name": "Іваненко О.", "group": "КІ-21", "email": "ivan@kpi.ua", "gpa": 85.5},
        {"name": "Петренко М.", "group": "КІ-21", "email": "petro@kpi.ua", "gpa": 92.0},
        {"name": "Сидоренко А.", "group": "КІ-22", "email": "syd@kpi.ua", "gpa": 78.3},
        {"name": "Коваль Л.", "group": "КІ-22", "email": "koval@kpi.ua", "gpa": 95.1},
    ]
    for record in demo:
        students_db[next_id] = {"id": next_id, **record,
                                "created_at": datetime.now().isoformat(timespec="seconds")}
        next_id += 1


if __name__ == "__main__":
    seed_demo_data()
    app.run(debug=True, port=5005)
