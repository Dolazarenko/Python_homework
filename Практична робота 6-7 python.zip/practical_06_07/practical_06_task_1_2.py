"""Views/контролери для обробки запитів у Flask (практична №6, завдання 1.2).

Запуск: python practical_06_task_1_2.py   ->   http://127.0.0.1:5001/api/items
"""

from functools import wraps

from flask import Flask, abort, jsonify, request, url_for

app = Flask(__name__)
app.json.ensure_ascii = False  # кирилиця в JSON читається без \u-кодів

SORT_FIELDS = {"name", "price"}
ORDER_VALUES = {"asc", "desc"}


def validate_json(required_fields):
    """Декоратор: перевіряє, що тіло запиту є JSON і містить обов'язкові поля."""
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            data = request.get_json(silent=True)
            if data is None:
                return jsonify({"error": "Очікується JSON"}), 400
            if not isinstance(data, dict):
                return jsonify({"error": "JSON має бути об'єктом"}), 400
            missing = [field for field in required_fields if field not in data]
            if missing:
                return jsonify({"error": f"Відсутні поля: {', '.join(missing)}"}), 400
            return f(*args, **kwargs)
        return wrapper
    return decorator


def validate_item(data: dict) -> list[str]:
    """Перевіряє значення полів товару. Повертає список помилок (порожній, якщо все коректно)."""
    errors = []
    name = data.get("name")
    if not isinstance(name, str) or not name.strip():
        errors.append("name має бути непорожнім рядком")
    price = data.get("price")
    if isinstance(price, bool) or not isinstance(price, (int, float)):
        errors.append("price має бути числом")
    elif price <= 0:
        errors.append("price має бути більшим за 0")
    category = data.get("category")
    if not isinstance(category, str) or not category.strip():
        errors.append("category має бути непорожнім рядком")
    return errors


def parse_float_arg(name: str) -> float | None:
    raw = request.args.get(name)
    if raw is None:
        return None
    try:
        return float(raw)
    except ValueError:
        abort(400, description=f"Параметр '{name}' має бути числом")


# ----- Views -----

@app.route("/api/items", methods=["GET"])
def get_items():
    """GET /api/items: список з фільтрацією та сортуванням.

    Параметри: category, min_price, max_price, sort (name|price), order (asc|desc).
    """
    category = request.args.get("category", "").strip().lower()
    min_price = parse_float_arg("min_price")
    max_price = parse_float_arg("max_price")
    sort = request.args.get("sort", "name")
    order = request.args.get("order", "asc")
    if sort not in SORT_FIELDS:
        return jsonify({"error": f"sort має бути одним із: {', '.join(sorted(SORT_FIELDS))}"}), 400
    if order not in ORDER_VALUES:
        return jsonify({"error": "order має бути asc або desc"}), 400

    result = list(items_db.values())
    if category:
        result = [i for i in result if i["category"].lower() == category]
    if min_price is not None:
        result = [i for i in result if i["price"] >= min_price]
    if max_price is not None:
        result = [i for i in result if i["price"] <= max_price]
    result.sort(key=lambda i: i[sort], reverse=(order == "desc"))

    return jsonify({
        "count": len(result),
        "filters": {"category": category or None, "min_price": min_price,
                    "max_price": max_price, "sort": sort, "order": order},
        "items": result,
    }), 200


@app.route("/api/items", methods=["POST"])
@validate_json(["name", "price", "category"])
def create_item():
    """POST /api/items: створити товар. Успіх — 201 із заголовком Location."""
    global next_id
    data = request.get_json()
    errors = validate_item(data)
    if errors:
        return jsonify({"error": "Помилка валідації", "details": errors}), 400

    item = {"id": next_id, "name": data["name"].strip(), "price": data["price"],
            "category": data["category"].strip()}
    items_db[next_id] = item
    next_id += 1

    response = jsonify(item)
    response.status_code = 201
    response.headers["Location"] = url_for("get_item", item_id=item["id"])
    return response


@app.route("/api/items/<int:item_id>", methods=["GET"])
def get_item(item_id: int):
    """GET /api/items/<id>: деталі товару або 404."""
    item = items_db.get(item_id)
    if item is None:
        abort(404)
    return jsonify(item), 200


@app.route("/api/items/<int:item_id>", methods=["PUT"])
@validate_json(["name", "price", "category"])
def update_item(item_id: int):
    """PUT /api/items/<id>: повне оновлення товару (усі поля обов'язкові)."""
    if item_id not in items_db:
        abort(404)
    data = request.get_json()
    errors = validate_item(data)
    if errors:
        return jsonify({"error": "Помилка валідації", "details": errors}), 400

    items_db[item_id] = {"id": item_id, "name": data["name"].strip(),
                         "price": data["price"], "category": data["category"].strip()}
    return jsonify(items_db[item_id]), 200


@app.route("/api/items/<int:item_id>", methods=["DELETE"])
def delete_item(item_id: int):
    """DELETE /api/items/<id>: видалити товар. Успіх — 204 без тіла."""
    if items_db.pop(item_id, None) is None:
        abort(404)
    return "", 204


# ----- Обробка помилок у JSON -----

@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Ресурс не знайдено"}), 404


@app.errorhandler(400)
def bad_request(error):
    return jsonify({"error": "Некоректний запит", "details": error.description}), 400


@app.errorhandler(405)
def method_not_allowed(error):
    return jsonify({"error": "Метод не дозволено для цього ресурсу"}), 405


# Тимчасова «база даних»
items_db = {
    1: {"id": 1, "name": "Ноутбук", "price": 25000, "category": "електроніка"},
    2: {"id": 2, "name": "Книга Python", "price": 500, "category": "книги"},
    3: {"id": 3, "name": "Навушники", "price": 2000, "category": "електроніка"},
}
next_id = 4


if __name__ == "__main__":
    app.run(debug=True, port=5001)
