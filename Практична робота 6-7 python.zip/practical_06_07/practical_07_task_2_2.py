"""CRUD: Update та Delete для блогу (практична №7, завдання 2.2).

Запуск: python practical_07_task_2_2.py   ->   http://127.0.0.1:5004/posts

Файл імпортує застосунок і шаблони з завдання 2.1 та додає редагування й видалення.
"""

from datetime import datetime

from flask import flash, redirect, render_template_string, request, url_for

from practical_07_task_2_1 import (
    FORM_TEMPLATE,
    app,
    find_post,
    posts_db,
    validate_post_form,
)

DELETE_CONFIRM_TEMPLATE = """
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Видалення</title></head>
<body>
    <h1>Підтвердження видалення</h1>
    <p>Ви дійсно бажаєте видалити публікацію «<strong>{{ post.title }}</strong>»?</p>
    <form method="POST">
        <button type="submit" style="color: red;">Так, видалити</button>
        <a href="{{ url_for('post_detail', post_id=post.id) }}">Скасувати</a>
    </form>
</body>
</html>
"""


@app.route("/posts/<int:post_id>/edit", methods=["GET", "POST"])
def post_edit(post_id: int):
    """UPDATE: форма з поточними даними (GET) і збереження змін (POST)."""
    post = find_post(post_id)

    if request.method == "POST":
        data, errors = validate_post_form(request.form)
        if errors:
            # Показуємо введені значення разом із помилками, дані в базі не змінюються
            return render_template_string(
                FORM_TEMPLATE, post={"id": post_id, **data}, errors=errors,
                form_title="Редагування публікації", button_text="Зберегти зміни",
            ), 400

        post.update(data)
        post["updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M")
        flash("Публікацію оновлено")
        return redirect(url_for("post_detail", post_id=post_id))

    return render_template_string(
        FORM_TEMPLATE, post=post, errors=[],
        form_title="Редагування публікації", button_text="Зберегти зміни",
    )


@app.route("/posts/<int:post_id>/delete", methods=["GET", "POST"])
def post_delete(post_id: int):
    """DELETE: сторінка підтвердження (GET) і видалення (POST)."""
    post = find_post(post_id)

    if request.method == "POST":
        posts_db.remove(post)
        flash(f"Публікацію «{post['title']}» видалено")
        return redirect(url_for("post_list"))

    return render_template_string(DELETE_CONFIRM_TEMPLATE, post=post)


# Приклади для демонстрації: додаються лише коли сховище порожнє
SEED_POSTS = [
    {"id": 1, "title": "Перша публікація", "content": "Зміст першої публікації.",
     "author": "Іван", "created_at": "2025-01-15 10:00"},
    {"id": 2, "title": "Друга публікація", "content": "Зміст другої публікації.",
     "author": "Марія", "created_at": "2025-01-20 12:30"},
]
if not posts_db:
    posts_db.extend(SEED_POSTS)


if __name__ == "__main__":
    app.run(debug=True, port=5004)
