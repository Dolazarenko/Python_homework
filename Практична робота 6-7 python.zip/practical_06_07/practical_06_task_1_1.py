"""Маршрутизація Flask: GET, POST, динамічні параметри (практична №6, завдання 1.1).

Запуск: python practical_06_task_1_1.py   ->   http://127.0.0.1:5000/
"""

import math
from datetime import date
from html import escape

from flask import Flask, abort, redirect, render_template_string, request, url_for

app = Flask(__name__)

# Базовий шаблон сторінки. Вміст (content) передається вже екранованим HTML,
# тому у шаблоні використано фільтр safe.
BASE_TEMPLATE = """
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>{{ title }}</title></head>
<body>
    <h1>{{ title }}</h1>
    <nav>
        <a href="{{ url_for('index') }}">Головна</a> |
        <a href="{{ url_for('post_list') }}">Публікації</a> |
        <a href="{{ url_for('search') }}">Пошук</a> |
        <a href="{{ url_for('post_create') }}">Нова публікація</a>
    </nav>
    <hr>
    {{ content | safe }}
</body>
</html>
"""

# Тимчасове сховище публікацій
posts_db = [
    {"id": 1, "title": "Вступ до Python", "content": "Python — потужна мова програмування.",
     "author": "Іван", "created": date(2025, 1, 15)},
    {"id": 2, "title": "Flask для початківців", "content": "Flask — мікрофреймворк для веб-застосунків.",
     "author": "Марія", "created": date(2025, 2, 3)},
    {"id": 3, "title": "REST API", "content": "REST — архітектурний стиль побудови веб-сервісів.",
     "author": "Петро", "created": date(2025, 2, 20)},
    {"id": 4, "title": "Маршрути в Django", "content": "Django використовує urlpatterns і path().",
     "author": "Іван", "created": date(2025, 3, 8)},
]


def render_page(title: str, content: str):
    return render_template_string(BASE_TEMPLATE, title=title, content=content)


def next_post_id() -> int:
    return max((p["id"] for p in posts_db), default=0) + 1


def positive_int_arg(name: str, default: int, maximum: int | None = None) -> int:
    """Зчитує цілий параметр запиту. Некоректне значення дає відповідь 400."""
    raw = request.args.get(name)
    if raw is None:
        return default
    try:
        value = int(raw)
    except ValueError:
        abort(400, description=f"Параметр '{name}' має бути цілим числом")
    if value < 1:
        abort(400, description=f"Параметр '{name}' має бути більшим за 0")
    return min(value, maximum) if maximum else value


def post_link(post: dict) -> str:
    return (f"<li><a href='{url_for('post_detail', post_id=post['id'])}'>"
            f"{escape(post['title'])}</a> — {escape(post['author'])}, {post['created']}</li>")


# ----- Маршрути -----

@app.route("/")
def index():
    """Головна сторінка (GET /)."""
    content = f"<p>Ласкаво просимо до блогу. Публікацій: {len(posts_db)}.</p>"
    return render_page("Головна", content)


@app.route("/posts")
def post_list():
    """Список публікацій з пагінацією (GET /posts?page=1&per_page=10)."""
    page = positive_int_arg("page", default=1)
    per_page = positive_int_arg("per_page", default=10, maximum=50)
    pages = max(1, math.ceil(len(posts_db) / per_page))
    if page > pages:
        abort(404)
    chunk = posts_db[(page - 1) * per_page: page * per_page]

    items = "".join(post_link(p) for p in chunk)
    nav = []
    if page > 1:
        nav.append(f"<a href='{url_for('post_list', page=page - 1, per_page=per_page)}'>« Попередня</a>")
    if page < pages:
        nav.append(f"<a href='{url_for('post_list', page=page + 1, per_page=per_page)}'>Наступна »</a>")
    content = (f"<p>Сторінка {page} з {pages}</p><ul>{items}</ul>"
               f"<p>{' | '.join(nav)}</p>")
    return render_page("Публікації", content)


@app.route("/posts/<int:post_id>")
def post_detail(post_id: int):
    """Деталі публікації (GET /posts/<id>). Для неіснуючого id — 404."""
    post = next((p for p in posts_db if p["id"] == post_id), None)
    if post is None:
        abort(404)
    content = (f"<h2>{escape(post['title'])}</h2>"
               f"<p>{escape(post['content'])}</p>"
               f"<p><small>Автор: {escape(post['author'])}, {post['created']}</small></p>")
    return render_page(post["title"], content)


FORM_HTML = """
<form method="POST">
    <p>Заголовок: <input type="text" name="title" value="{title}" required></p>
    <p>Автор: <input type="text" name="author" value="{author}" required></p>
    <p>Зміст:<br><textarea name="content" rows="6" cols="50" required>{content}</textarea></p>
    <button type="submit">Створити</button>
</form>
"""


@app.route("/posts/create", methods=["GET", "POST"])
def post_create():
    """GET — форма створення; POST — обробка даних, збереження і redirect."""
    if request.method == "GET":
        return render_page("Нова публікація", FORM_HTML.format(title="", author="", content=""))

    title = request.form.get("title", "").strip()
    author = request.form.get("author", "").strip()
    content = request.form.get("content", "").strip()
    if not (title and author and content):
        error = "<p style='color:red'>Заповніть усі поля.</p>"
        form = FORM_HTML.format(title=escape(title), author=escape(author), content=escape(content))
        return render_page("Нова публікація", error + form), 400

    new_post = {"id": next_post_id(), "title": title, "content": content,
                "author": author, "created": date.today()}
    posts_db.append(new_post)
    return redirect(url_for("post_detail", post_id=new_post["id"]))


@app.route("/search")
def search():
    """Пошук за параметром q (GET /search?q=python)."""
    query = request.args.get("q", "").strip()
    form = (f"<form method='GET'>"
            f"<input type='text' name='q' value='{escape(query)}'>"
            f"<button type='submit'>Знайти</button></form>")
    if not query:
        return render_page("Пошук", form + "<p>Введіть слово для пошуку.</p>")

    needle = query.lower()
    found = [p for p in posts_db
             if needle in p["title"].lower() or needle in p["content"].lower()]
    items = "".join(post_link(p) for p in found) or "<li>Нічого не знайдено.</li>"
    return render_page("Пошук", form + f"<p>Результати для «{escape(query)}»:</p><ul>{items}</ul>")


@app.route("/archive/<int:year>/<int:month>")
def archive(year: int, month: int):
    """Архів публікацій за роком і місяцем (GET /archive/2025/2)."""
    if not 1 <= month <= 12:
        abort(404)
    found = [p for p in posts_db if p["created"].year == year and p["created"].month == month]
    items = "".join(post_link(p) for p in found) or "<li>За цей період публікацій немає.</li>"
    return render_page(f"Архів: {month:02d}.{year}", f"<ul>{items}</ul>")


@app.route("/user/<string:username>")
def user_profile(username: str):
    """Публікації автора (GET /user/Іван). Якщо автора немає — 404."""
    found = [p for p in posts_db if p["author"].lower() == username.lower()]
    if not found:
        abort(404)
    items = "".join(post_link(p) for p in found)
    return render_page(f"Автор: {escape(username)}", f"<ul>{items}</ul>")


if __name__ == "__main__":
    app.run(debug=True, port=5000)
