"""Моделі: хешування паролів, обмеження БД, обчислення сум."""

import pytest
from sqlalchemy.exc import IntegrityError

from bookshop.extensions import db
from bookshop.models import Author, Order, User
from bookshop.services import create_order, get_or_create_author
from conftest import make_book, make_user


def test_password_is_stored_as_hash(app):
    user = make_user("hash@test.ua", "mypassword")
    assert user.password_hash != "mypassword"
    assert user.check_password("mypassword")
    assert not user.check_password("wrong")


def test_isbn_is_unique(app, books):
    from conftest import make_book as again
    with pytest.raises(IntegrityError):
        again("Дубль", 1)  # той самий номер -> той самий ISBN
    db.session.rollback()


def test_price_is_kept_in_cents(app, books):
    assert books[0].price_cents == 10000
    assert books[0].price == 100.0
    assert books[2].price == 50.5


def test_author_lookup_is_case_insensitive(app, books):
    first = get_or_create_author("АВТОР")
    assert first.name == "Автор"
    assert db.session.scalar(db.select(db.func.count()).select_from(Author)) == 2


def test_order_total_is_sum_of_items(app, customer, books):
    order = create_order(customer, {books[0].id: 2, books[2].id: 1})
    assert order.total_cents == 2 * 10000 + 5050
    assert order.total == 250.5
    assert sum(item.subtotal_cents for item in order.items) == order.total_cents


def test_user_orders_are_newest_first(app, customer, books):
    first = create_order(customer, {books[0].id: 1})
    second = create_order(customer, {books[0].id: 1})
    assert [o.id for o in customer.orders] == [second.id, first.id]


def test_to_dict_contains_expected_fields(app, books):
    data = books[0].to_dict()
    assert data["title"] == "Книга A"
    assert data["author"] == "Автор"
    assert data["price"] == 100.0
    assert "password_hash" not in make_user("x@test.ua", "pass12").to_dict()
