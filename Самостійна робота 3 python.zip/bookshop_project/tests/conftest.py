"""Спільні фікстури: застосунок з чистою in-memory базою, користувачі, книги."""

import pytest

from bookshop import create_app
from bookshop.config import TestConfig
from bookshop.extensions import db
from bookshop.models import Book, User
from bookshop.services import get_or_create_author
from library.validators import make_isbn13


@pytest.fixture
def app():
    app = create_app(TestConfig)
    with app.app_context():
        db.create_all()
        yield app
        db.session.remove()
        db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


def make_user(email: str, password: str, name: str = "Тест", is_admin: bool = False) -> User:
    user = User(email=email, name=name, is_admin=is_admin)
    user.set_password(password)
    db.session.add(user)
    db.session.commit()
    return user


def make_book(title: str, number: int, stock: int = 5, price_cents: int = 10000,
              author_name: str = "Автор") -> Book:
    author = get_or_create_author(author_name)
    book = Book(title=title, title_key=title.casefold(), isbn=make_isbn13(f"{number:09d}"),
                year=2000, price_cents=price_cents, stock=stock, author=author, description="Опис")
    db.session.add(book)
    db.session.commit()
    return book


@pytest.fixture
def customer(app):
    return make_user("reader@test.ua", "secret123", "Читач")


@pytest.fixture
def other_customer(app):
    return make_user("other@test.ua", "secret456", "Інший читач")


@pytest.fixture
def admin(app):
    return make_user("admin@test.ua", "admin123", "Адмін", is_admin=True)


@pytest.fixture
def books(app):
    return [
        make_book("Книга A", 1, stock=5, price_cents=10000),
        make_book("Книга B", 2, stock=0, price_cents=20000),
        make_book("Книга C", 3, stock=2, price_cents=5050, author_name="Інший автор"),
    ]


def login_web(client, email: str, password: str):
    return client.post("/login", data={"email": email, "password": password})


def login_api(client, email: str, password: str):
    return client.post("/api/auth/login", json={"email": email, "password": password})
