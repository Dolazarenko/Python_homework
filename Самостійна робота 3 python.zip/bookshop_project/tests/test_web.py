"""HTML-інтерфейс: каталог, кошик, оформлення, облікові записи, адмін-панель."""

from bookshop.extensions import db
from bookshop.models import Book, Order
from bookshop.services import create_order
from conftest import login_web, make_book


def test_catalog_lists_books(client, books):
    response = client.get("/books")
    assert response.status_code == 200
    assert "Книга A" in response.get_data(as_text=True)


def test_catalog_search_by_title(client, books):
    body = client.get("/books?q=книга+b").get_data(as_text=True)
    assert "Книга B" in body
    assert "Книга A" not in body


def test_catalog_search_by_isbn(client, books):
    isbn = books[0].isbn
    body = client.get(f"/books?q={isbn}").get_data(as_text=True)
    assert "Книга A" in body
    assert "Книга C" not in body


def test_book_detail_and_404(client, books):
    assert client.get(f"/books/{books[0].id}").status_code == 200
    assert client.get("/books/9999").status_code == 404


def test_add_to_cart_stores_in_session(client, books):
    response = client.post(f"/cart/add/{books[0].id}", data={"quantity": "2"})
    assert response.status_code == 302
    assert "Книга A" in client.get("/cart").get_data(as_text=True)


def test_out_of_stock_shows_message(client, books):
    response = client.post(f"/cart/add/{books[1].id}", data={"quantity": "1"},
                           follow_redirects=True)
    assert "На складі лише 0" in response.get_data(as_text=True)


def test_checkout_requires_login(client, books):
    client.post(f"/cart/add/{books[0].id}", data={"quantity": "1"})
    response = client.post("/checkout")
    assert response.status_code == 302
    assert "/login" in response.location


def test_checkout_creates_order_and_clears_cart(client, customer, books):
    login_web(client, "reader@test.ua", "secret123")
    client.post(f"/cart/add/{books[0].id}", data={"quantity": "2"})
    response = client.post("/checkout")
    assert response.status_code == 302
    assert "/orders/" in response.location
    assert db.session.get(Book, books[0].id).stock == 3
    assert db.session.scalar(db.select(db.func.count()).select_from(Order)) == 1
    assert "Кошик порожній" in client.get("/cart").get_data(as_text=True)


def test_register_logs_user_in(client, app):
    response = client.post("/register", data={"name": "Нова", "email": "new@test.ua",
                                              "password": "pass123"})
    assert response.status_code == 302
    assert "Вийти" in client.get("/books").get_data(as_text=True)


def test_register_duplicate_email_rejected(client, customer):
    response = client.post("/register", data={"name": "Ще раз", "email": "reader@test.ua",
                                              "password": "pass123"})
    assert response.status_code == 400
    assert "уже існує" in response.get_data(as_text=True)


def test_register_short_password_rejected(client):
    response = client.post("/register", data={"name": "X", "email": "x@test.ua",
                                              "password": "123"})
    assert response.status_code == 400
    assert "не коротшим за 6" in response.get_data(as_text=True)


def test_wrong_password_rejected(client, customer):
    response = login_web(client, "reader@test.ua", "wrong")
    assert response.status_code == 401
    assert "Невірний" in response.get_data(as_text=True)


def test_external_next_url_is_ignored(client, customer):
    response = client.post("/login?next=https://evil.example/steal",
                           data={"email": "reader@test.ua", "password": "secret123"})
    assert response.status_code == 302
    assert response.location.endswith("/books")
    assert "evil.example" not in response.location


def test_user_cannot_see_other_users_order(client, customer, other_customer, books):
    order = create_order(other_customer, {books[0].id: 1})
    login_web(client, "reader@test.ua", "secret123")
    assert client.get(f"/orders/{order.id}").status_code == 404


def test_orders_page_lists_own_orders(client, customer, books):
    create_order(customer, {books[0].id: 1})
    login_web(client, "reader@test.ua", "secret123")
    assert "Замовлень ще немає" not in client.get("/orders").get_data(as_text=True)


def test_admin_pages_forbidden_for_customer(client, customer):
    login_web(client, "reader@test.ua", "secret123")
    assert client.get("/admin/books").status_code == 403
    assert client.get("/admin/books/new").status_code == 403


def test_admin_pages_redirect_anonymous(client, books):
    assert client.get("/admin/books").status_code == 302


def test_admin_creates_book_via_form(client, admin, app):
    login_web(client, "admin@test.ua", "admin123")
    from library.validators import make_isbn13
    response = client.post("/admin/books/new", data={
        "title": "Нова книга", "author": "Новий автор", "isbn": make_isbn13("000000301"),
        "year": "2024", "price": "250", "stock": "7", "description": "Опис",
    })
    assert response.status_code == 302
    assert db.session.scalar(db.select(db.func.count()).select_from(Book)) == 1


def test_admin_form_shows_validation_errors(client, admin):
    login_web(client, "admin@test.ua", "admin123")
    response = client.post("/admin/books/new", data={
        "title": "", "author": "A", "isbn": "123", "year": "3000", "price": "-1", "stock": "1",
    })
    body = response.get_data(as_text=True)
    assert response.status_code == 400
    assert "ISBN" in body or "контрольна" in body or "формат" in body


def test_admin_edits_book(client, admin, books):
    login_web(client, "admin@test.ua", "admin123")
    response = client.post(f"/admin/books/{books[0].id}/edit", data={
        "title": "Перейменована", "author": "Автор", "isbn": books[0].isbn,
        "year": "2001", "price": "123.45", "stock": "9", "description": "Новий опис",
    })
    assert response.status_code == 302
    book = db.session.get(Book, books[0].id)
    assert book.title == "Перейменована"
    assert book.price_cents == 12345


def test_admin_cannot_delete_book_with_orders(client, admin, customer, books):
    create_order(customer, {books[0].id: 1})
    login_web(client, "admin@test.ua", "admin123")
    response = client.post(f"/admin/books/{books[0].id}/delete", follow_redirects=True)
    assert "є у замовленнях" in response.get_data(as_text=True)
    assert db.session.get(Book, books[0].id) is not None


def test_admin_deletes_unused_book(client, admin, books):
    login_web(client, "admin@test.ua", "admin123")
    client.post(f"/admin/books/{books[2].id}/delete")
    assert db.session.get(Book, books[2].id) is None
