"""Інтеграція з модулем 2: правила ISBN, років і помилок беруться з пакета library."""

from bookshop.extensions import db
from bookshop.models import Author, Book
from bookshop.services import import_catalog_from_library, validate_book_data
from library.validators import make_isbn13

VALID = {"title": "Чистий код", "author": "Роберт Мартін", "year": "2008", "price": "690",
         "stock": "4", "isbn": "978-0-306-40615-7", "description": ""}


def test_valid_book_passes_library_rules(app):
    clean, errors = validate_book_data(VALID)
    assert errors == {}
    assert clean["isbn"] == "9780306406157"   # дефіси прибрано правилом normalize_isbn
    assert clean["year"] == 2008              # рядок перетворено на число
    assert clean["price_cents"] == 69000


def test_invalid_checksum_rejected(app):
    clean, errors = validate_book_data({**VALID, "isbn": "9780306406158"})
    assert "isbn" in errors
    assert "контрольна сума" in errors["isbn"]


def test_year_out_of_range_rejected(app):
    _, errors = validate_book_data({**VALID, "year": "3000"})
    assert "year" in errors


def test_missing_required_fields_reported(app):
    _, errors = validate_book_data({"price": "10"})
    assert {"title", "isbn", "year", "author"} <= set(errors)


def test_negative_stock_and_price_rejected(app):
    _, errors = validate_book_data({**VALID, "price": "-5", "stock": "-1"})
    assert "price" in errors and "stock" in errors


def test_import_saves_valid_and_rejects_invalid(app):
    records = [
        {**VALID, "isbn": make_isbn13("000000101")},
        {**VALID, "title": "Поганий", "isbn": "123"},
    ]
    saved, rejected = import_catalog_from_library(records)
    assert len(saved) == 1
    assert len(rejected) == 1
    assert "ISBN" in rejected[0][1]
    assert db.session.scalar(db.select(db.func.count()).select_from(Book)) == 1


def test_import_rejects_duplicate_isbn_inside_batch(app):
    record = {**VALID, "isbn": make_isbn13("000000102")}
    saved, rejected = import_catalog_from_library([record, dict(record)])
    assert len(saved) == 1
    assert len(rejected) == 1


def test_import_reuses_one_author_for_several_books(app):
    records = [{**VALID, "isbn": make_isbn13(f"{n:09d}"), "title": f"Книга {n}"}
               for n in (201, 202, 203)]
    saved, _ = import_catalog_from_library(records)
    assert len(saved) == 3
    assert db.session.scalar(db.select(db.func.count()).select_from(Author)) == 1
