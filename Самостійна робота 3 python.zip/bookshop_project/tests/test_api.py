"""REST API: коди відповідей, права доступу, пагінація, замовлення."""

from bookshop.extensions import db
from bookshop.models import Book
from bookshop.services import create_order
from conftest import login_api, make_book
from library.validators import make_isbn13


def test_list_books_paginated(client, books):
    data = client.get("/api/books?per_page=2&page=2").get_json()
    assert data["count"] == 3
    assert data["pages"] == 2
    assert len(data["books"]) == 1


def test_list_books_search(client, books):
    data = client.get("/api/books?q=книга+c").get_json()
    assert [b["title"] for b in data["books"]] == ["Книга C"]


def test_list_books_invalid_params(client, books):
    response = client.get("/api/books?per_page=500")
    assert response.status_code == 400


def test_book_detail_and_404(client, books):
    assert client.get(f"/api/books/{books[0].id}").get_json()["title"] == "Книга A"
    assert client.get("/api/books/9999").status_code == 404


def test_create_book_requires_auth(client, books):
    response = client.post("/api/books", json={"title": "X"})
    assert response.status_code == 401


def test_create_book_forbidden_for_customer(client, customer):
    login_api(client, "reader@test.ua", "secret123")
    response = client.post("/api/books", json={"title": "X"})
    assert response.status_code == 403


def test_admin_creates_book(client, admin):
    login_api(client, "admin@test.ua", "admin123")
    response = client.post("/api/books", json={
        "title": "API книга", "author": "Автор API", "isbn": make_isbn13("000000401"),
        "year": 2022, "price": 99.9, "stock": 3, "description": ""})
    assert response.status_code == 201
    assert response.headers["Location"].endswith(f"/api/books/{response.get_json()['id']}")
    assert response.get_json()["price"] == 99.9


def test_create_book_validation_400(client, admin):
    login_api(client, "admin@test.ua", "admin123")
    response = client.post("/api/books", json={"title": "", "isbn": "123", "year": 1,
                                               "author": "A", "price": 10})
    assert response.status_code == 400
    assert {"title", "isbn", "year"} <= set(response.get_json()["details"])


def test_create_book_duplicate_isbn_409(client, admin, books):
    login_api(client, "admin@test.ua", "admin123")
    response = client.post("/api/books", json={
        "title": "Дубль", "author": "A", "isbn": books[0].isbn, "year": 2000, "price": 5})
    assert response.status_code == 409


def test_update_book_put(client, admin, books):
    login_api(client, "admin@test.ua", "admin123")
    response = client.put(f"/api/books/{books[0].id}", json={
        "title": "Нова назва", "author": "Автор", "isbn": books[0].isbn,
        "year": 2010, "price": 50, "stock": 1, "description": ""})
    assert response.status_code == 200
    assert response.get_json()["title"] == "Нова назва"


def test_update_missing_book_404(client, admin):
    login_api(client, "admin@test.ua", "admin123")
    response = client.put("/api/books/9999", json={"title": "X"})
    assert response.status_code == 404


def test_delete_book_without_orders(client, admin, books):
    login_api(client, "admin@test.ua", "admin123")
    response = client.delete(f"/api/books/{books[2].id}")
    assert response.status_code == 204
    assert response.get_data() == b""


def test_delete_book_with_orders_conflict(client, admin, customer, books):
    create_order(customer, {books[0].id: 1})
    login_api(client, "admin@test.ua", "admin123")
    assert client.delete(f"/api/books/{books[0].id}").status_code == 409


def test_login_wrong_password_401(client, customer):
    assert login_api(client, "reader@test.ua", "bad").status_code == 401


def test_login_me_logout_cycle(client, customer):
    assert client.get("/api/auth/me").status_code == 401
    assert login_api(client, "reader@test.ua", "secret123").status_code == 200
    assert client.get("/api/auth/me").get_json()["email"] == "reader@test.ua"
    assert client.post("/api/auth/logout").status_code == 204
    assert client.get("/api/auth/me").status_code == 401


def test_order_creation_flow(client, customer, books):
    login_api(client, "reader@test.ua", "secret123")
    response = client.post("/api/orders", json={"items": [{"book_id": books[0].id, "quantity": 2}]})
    assert response.status_code == 201
    assert response.get_json()["total"] == 200.0
    assert db.session.get(Book, books[0].id).stock == 3
    orders = client.get("/api/orders").get_json()["orders"]
    assert len(orders) == 1
    assert client.get(f"/api/orders/{orders[0]['id']}").status_code == 200


def test_order_insufficient_stock_400(client, customer, books):
    login_api(client, "reader@test.ua", "secret123")
    response = client.post("/api/orders", json={"items": [{"book_id": books[1].id, "quantity": 1}]})
    assert response.status_code == 400
    assert "Недостатньо" in response.get_json()["error"]


def test_order_validation_400(client, customer, books):
    login_api(client, "reader@test.ua", "secret123")
    assert client.post("/api/orders", json={"items": []}).status_code == 400
    response = client.post("/api/orders", json={"items": [{"book_id": 1, "quantity": 0}]})
    assert response.status_code == 400
    assert response.get_json()["details"][0]["quantity"]


def test_orders_require_auth(client, books):
    assert client.post("/api/orders", json={"items": []}).status_code == 401
    assert client.get("/api/orders").status_code == 401


def test_other_users_order_is_404(client, customer, other_customer, books):
    order = create_order(other_customer, {books[0].id: 1})
    login_api(client, "reader@test.ua", "secret123")
    assert client.get(f"/api/orders/{order.id}").status_code == 404


def test_unknown_api_route_returns_json_404(client):
    response = client.get("/api/nothing")
    assert response.status_code == 404
    assert response.is_json
