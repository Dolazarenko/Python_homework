"""Сесії та куки: атрибути безпеки, збереження кошика, ізоляція клієнтів."""

from conftest import login_web


def test_session_cookie_has_security_attributes(client, customer):
    response = login_web(client, "reader@test.ua", "secret123")
    cookie = response.headers.get("Set-Cookie", "")
    assert "HttpOnly" in cookie
    assert "SameSite=Lax" in cookie


def test_theme_cookie_attributes(client):
    response = client.get("/settings/theme/dark")
    cookie = response.headers.get("Set-Cookie", "")
    assert "theme=dark" in cookie
    assert "Max-Age=2592000" in cookie
    assert "HttpOnly" in cookie


def test_theme_cookie_changes_page_class(client, books):
    client.get("/settings/theme/dark")
    assert "theme-dark" in client.get("/books").get_data(as_text=True)


def test_invalid_theme_rejected(client):
    assert client.get("/settings/theme/neon").status_code == 400


def test_cart_persists_between_requests(client, books):
    client.post(f"/cart/add/{books[0].id}", data={"quantity": "1"})
    client.post(f"/cart/add/{books[2].id}", data={"quantity": "1"})
    body = client.get("/cart").get_data(as_text=True)
    assert "Книга A" in body and "Книга C" in body


def test_cart_is_isolated_between_clients(app, books):
    first = app.test_client()
    second = app.test_client()
    first.post(f"/cart/add/{books[0].id}", data={"quantity": "1"})
    assert "Кошик порожній" in second.get("/cart").get_data(as_text=True)


def test_logout_removes_access_but_keeps_session_cookie(client, customer):
    login_web(client, "reader@test.ua", "secret123")
    client.post("/logout")
    assert client.get("/orders").status_code == 302


def test_session_stores_user_id_not_password(app, client, customer):
    login_web(client, "reader@test.ua", "secret123")
    with client.session_transaction() as sess:
        assert sess["user_id"] == customer.id
        assert "secret123" not in str(dict(sess))
