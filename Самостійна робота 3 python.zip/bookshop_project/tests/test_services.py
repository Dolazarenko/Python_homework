"""Бізнес-логіка: кошик, склад, оформлення замовлень."""

import pytest

from bookshop.extensions import db
from bookshop.models import Book
from bookshop.services import ShopError, cart_add, cart_summary, create_order


def test_cart_add_within_stock(app, books):
    cart = cart_add({}, books[0], 3)
    assert cart == {str(books[0].id): 3}


def test_cart_add_accumulates_quantity(app, books):
    cart = cart_add({str(books[0].id): 2}, books[0], 3)
    assert cart[str(books[0].id)] == 5


def test_cart_add_beyond_stock_rejected(app, books):
    with pytest.raises(ShopError, match="На складі лише"):
        cart_add({}, books[0], 6)   # на складі 5


def test_cart_add_out_of_stock_rejected(app, books):
    with pytest.raises(ShopError):
        cart_add({}, books[1], 1)   # stock = 0


def test_cart_limit_per_item(app, books):
    with pytest.raises(ShopError, match="від 1 до 10"):
        cart_add({}, books[0], 11)


def test_cart_quantity_must_be_positive(app, books):
    with pytest.raises(ShopError):
        cart_add({}, books[0], 0)


def test_cart_summary_totals(app, books):
    summary = cart_summary({str(books[0].id): 2, str(books[2].id): 1})
    assert summary["count"] == 3
    assert summary["total"] == 250.5


def test_cart_summary_skips_deleted_books(app, books):
    cart = {str(books[0].id): 1, "9999": 4}
    summary = cart_summary(cart)
    assert [line["book"].id for line in summary["lines"]] == [books[0].id]


def test_create_order_decrements_stock(app, customer, books):
    create_order(customer, {books[0].id: 2})
    assert db.session.get(Book, books[0].id).stock == 3


def test_create_order_with_insufficient_stock_changes_nothing(app, customer, books):
    before = db.session.get(Book, books[0].id).stock
    with pytest.raises(ShopError, match="Недостатньо"):
        create_order(customer, {books[0].id: 1, books[1].id: 1})   # books[1] stock = 0
    assert db.session.get(Book, books[0].id).stock == before


def test_create_order_empty_cart_rejected(app, customer):
    with pytest.raises(ShopError, match="порожній"):
        create_order(customer, {})


def test_create_order_unknown_book_rejected(app, customer):
    with pytest.raises(ShopError, match="більше немає"):
        create_order(customer, {9999: 1})


def test_order_keeps_price_at_purchase_time(app, customer, books):
    order = create_order(customer, {books[0].id: 1})
    books[0].price_cents = 99999
    db.session.commit()
    assert order.items[0].unit_price_cents == 10000
