"""Команда flask seed: створює таблиці, облікові записи і каталог через модуль 2."""

from bookshop.extensions import db
from bookshop.models import Book, User


def test_seed_creates_users_and_catalog(app):
    result = app.test_cli_runner().invoke(args=["seed"])
    assert result.exit_code == 0
    assert "Збережено книг" in result.output
    assert "Відхилено" in result.output          # навмисно некоректний запис
    assert db.session.scalar(db.select(db.func.count()).select_from(User)) == 2
    assert db.session.scalar(db.select(db.func.count()).select_from(Book)) == 7


def test_seed_twice_does_not_duplicate_users(app):
    runner = app.test_cli_runner()
    runner.invoke(args=["seed"])
    result = runner.invoke(args=["seed"])
    assert result.exit_code == 0
    assert db.session.scalar(db.select(db.func.count()).select_from(User)) == 2
