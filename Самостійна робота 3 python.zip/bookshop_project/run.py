"""Запуск веб-застосунку: python run.py  ->  http://127.0.0.1:5010/"""

from bookshop import create_app

app = create_app()

if __name__ == "__main__":
    app.run(debug=True, port=5010)
