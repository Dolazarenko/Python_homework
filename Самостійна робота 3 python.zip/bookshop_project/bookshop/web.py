"""HTML-маршрути: каталог, кошик, оформлення, облікові записи, замовлення, адмін-панель."""

import math

from flask import (Blueprint, current_app, flash, redirect, render_template, request,
                   session, url_for, abort)

from .auth import admin_required, current_user, login_required
from .extensions import db
from .models import Book, Order, User
from .services import (ShopError, cart_add, cart_summary, create_order, save_book,
                       search_books, validate_book_data)

web_bp = Blueprint("web", __name__)

THEMES = {"light", "dark"}


@web_bp.app_context_processor
def inject_globals():
    """Дані для всіх шаблонів: поточний користувач, кількість товарів у кошику, тема."""
    cart = session.get("cart", {})
    return {
        "current_user": current_user(),
        "cart_count": sum(cart.values()),
        "theme": request.cookies.get("theme", "light"),
    }


@web_bp.route("/")
def index():
    return redirect(url_for("web.books"))


def safe_next_url(target: str | None) -> str:
    """Дозволяє лише внутрішні адреси, щоб параметр next не вів на сторонній сайт."""
    if target and target.startswith("/") and not target.startswith("//"):
        return target
    return url_for("web.books")


# ----- Каталог -----

@web_bp.route("/books")
def books():
    query = request.args.get("q", "").strip()
    page = max(1, request.args.get("page", 1, type=int))
    per_page = current_app.config["PER_PAGE"]
    total, items = search_books(query, (page - 1) * per_page, per_page)
    pages = max(1, math.ceil(total / per_page))
    return render_template("books.html", books=items, q=query, page=page, pages=pages)


@web_bp.route("/books/<int:book_id>")
def book_detail(book_id: int):
    book = db.get_or_404(Book, book_id)
    return render_template("book_detail.html", book=book)


# ----- Кошик (session) -----

@web_bp.route("/cart")
def cart_view():
    summary = cart_summary(session.get("cart", {}))
    return render_template("cart.html", cart=summary)


@web_bp.route("/cart/add/<int:book_id>", methods=["POST"])
def cart_add_item(book_id: int):
    book = db.get_or_404(Book, book_id)
    quantity = request.form.get("quantity", 1, type=int)
    try:
        session["cart"] = cart_add(session.get("cart", {}), book, quantity)
        flash(f"«{book.title}» додано до кошика")
    except ShopError as exc:
        flash(str(exc))
    return redirect(url_for("web.book_detail", book_id=book_id))


@web_bp.route("/cart/remove/<int:book_id>", methods=["POST"])
def cart_remove_item(book_id: int):
    cart = dict(session.get("cart", {}))
    cart.pop(str(book_id), None)
    session["cart"] = cart
    return redirect(url_for("web.cart_view"))


@web_bp.route("/checkout", methods=["POST"])
@login_required
def checkout():
    cart = session.get("cart", {})
    try:
        order = create_order(current_user(), {int(k): v for k, v in cart.items()})
    except ShopError as exc:
        flash(str(exc))
        return redirect(url_for("web.cart_view"))
    session.pop("cart", None)
    flash(f"Замовлення №{order.id} оформлено")
    return redirect(url_for("web.order_detail", order_id=order.id))


# ----- Облікові записи -----

@web_bp.route("/register", methods=["GET", "POST"])
def register():
    errors = {}
    form = {"name": "", "email": ""}
    if request.method == "POST":
        form = {"name": request.form.get("name", "").strip(),
                "email": request.form.get("email", "").strip().lower()}
        password = request.form.get("password", "")
        if not form["name"]:
            errors["name"] = "Вкажіть ім'я"
        if "@" not in form["email"]:
            errors["email"] = "Некоректний e-mail"
        if len(password) < 6:
            errors["password"] = "Пароль має бути не коротшим за 6 символів"
        if not errors and db.session.execute(
                db.select(User).where(User.email == form["email"])).scalar_one_or_none():
            errors["email"] = "Користувач з таким e-mail уже існує"
        if not errors:
            user = User(name=form["name"], email=form["email"])
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            session["user_id"] = user.id
            flash("Реєстрацію завершено")
            return redirect(url_for("web.books"))
    return render_template("register.html", errors=errors, form=form), (400 if errors else 200)


@web_bp.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        user = db.session.execute(db.select(User).where(User.email == email)).scalar_one_or_none()
        if user and user.check_password(request.form.get("password", "")):
            session["user_id"] = user.id
            flash(f"Ласкаво просимо, {user.name}")
            return redirect(safe_next_url(request.args.get("next")))
        error = "Невірний e-mail або пароль"
    return render_template("login.html", error=error), (401 if error else 200)


@web_bp.route("/logout", methods=["POST"])
def logout():
    session.pop("user_id", None)
    flash("Ви вийшли з облікового запису")
    return redirect(url_for("web.books"))


@web_bp.route("/settings/theme/<theme>")
def set_theme(theme: str):
    """Зберігає тему оформлення в cookie на 30 днів."""
    if theme not in THEMES:
        abort(400)
    response = redirect(request.referrer or url_for("web.books"))
    response.set_cookie("theme", theme, max_age=30 * 24 * 3600, httponly=True, samesite="Lax")
    return response


# ----- Замовлення користувача -----

@web_bp.route("/orders")
@login_required
def orders():
    return render_template("orders.html", orders=current_user().orders)


@web_bp.route("/orders/<int:order_id>")
@login_required
def order_detail(order_id: int):
    order = db.session.get(Order, order_id)
    if order is None or order.user_id != current_user().id:
        abort(404)  # чужі замовлення не показуємо взагалі
    return render_template("order_detail.html", order=order)


# ----- Адміністрування книг (CRUD) -----

@web_bp.route("/admin/books")
@admin_required
def admin_books():
    return render_template("admin_books.html", books=db.session.scalars(
        db.select(Book).order_by(Book.id)).all())


@web_bp.route("/admin/books/new", methods=["GET", "POST"])
@admin_required
def admin_book_create():
    errors, values = {}, {}
    if request.method == "POST":
        values = request.form.to_dict()
        clean, errors = validate_book_data(values)
        if not errors:
            try:
                book = save_book(clean)
                flash(f"Книгу «{book.title}» додано")
                return redirect(url_for("web.admin_books"))
            except ShopError as exc:
                errors["isbn"] = str(exc)
    return render_template("book_form.html", errors=errors, values=values,
                           title="Нова книга", book=None), (400 if errors else 200)


@web_bp.route("/admin/books/<int:book_id>/edit", methods=["GET", "POST"])
@admin_required
def admin_book_edit(book_id: int):
    book = db.get_or_404(Book, book_id)
    errors, values = {}, {}
    if request.method == "POST":
        values = request.form.to_dict()
        clean, errors = validate_book_data(values)
        if not errors:
            try:
                save_book(clean, book)
                flash(f"Зміни в «{book.title}» збережено")
                return redirect(url_for("web.admin_books"))
            except ShopError as exc:
                errors["isbn"] = str(exc)
    else:
        values = {"title": book.title, "isbn": book.isbn, "year": book.year,
                  "author": book.author.name, "price": book.price, "stock": book.stock,
                  "description": book.description}
    return render_template("book_form.html", errors=errors, values=values,
                           title="Редагування книги", book=book), (400 if errors else 200)


@web_bp.route("/admin/books/<int:book_id>/delete", methods=["POST"])
@admin_required
def admin_book_delete(book_id: int):
    book = db.get_or_404(Book, book_id)
    if book.order_items:
        flash(f"Неможливо видалити «{book.title}»: книга є у замовленнях")
        return redirect(url_for("web.admin_books"))
    db.session.delete(book)
    db.session.commit()
    flash(f"Книгу «{book.title}» видалено")
    return redirect(url_for("web.admin_books"))
