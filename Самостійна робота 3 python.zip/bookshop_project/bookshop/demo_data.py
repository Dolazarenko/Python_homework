"""Демонстраційний каталог. ISBN формує функція make_isbn13 з модуля 2, тож усі коди коректні.

Останній запис навмисно має некоректний ISBN: команда seed покаже, як модуль 2 його відхиляє.
"""

from library.validators import make_isbn13

DEMO_BOOKS = [
    {"title": "Кобзар", "author": "Тарас Шевченко", "year": 1840, "price": 180, "stock": 12,
     "description": "Збірка поезій, що стала класикою української літератури."},
    {"title": "Лісова пісня", "author": "Леся Українка", "year": 1911, "price": 150, "stock": 8,
     "description": "Драма-феєрія про Мавку та Лукаша."},
    {"title": "Тіні забутих предків", "author": "Михайло Коцюбинський", "year": 1911, "price": 210,
     "stock": 5, "description": "Повість про кохання та гуцульські звичаї."},
    {"title": "Захар Беркут", "author": "Іван Франко", "year": 1883, "price": 130, "stock": 0,
     "description": "Історична повість про боротьбу з монголами."},
    {"title": "Чистий код", "author": "Роберт Мартін", "year": 2008, "price": 690, "stock": 4,
     "description": "Принципи написання читабельного та підтримуваного коду."},
    {"title": "Програмування на Python", "author": "Марк Лутц", "year": 2013, "price": 890, "stock": 6,
     "description": "Підручник з мови Python для початківців і досвідчених розробників."},
    {"title": "Патерни проєктування", "author": "Ерік Гамма", "year": 1994, "price": 760, "stock": 3,
     "description": "23 класичні патерни об'єктно-орієнтованого проєктування."},
]

for index, record in enumerate(DEMO_BOOKS, start=1):
    record["isbn"] = make_isbn13(f"{index:09d}")

INVALID_RECORD = {
    "title": "Книга з помилковим ISBN", "author": "Невідомий автор", "year": 2020,
    "price": 100, "stock": 1, "isbn": "978-1-2345-6789-0",
}

DEMO_USERS = [
    {"email": "admin@bookshop.ua", "name": "Адміністратор", "password": "admin123", "is_admin": True},
    {"email": "reader@bookshop.ua", "name": "Читач", "password": "reader123", "is_admin": False},
]
