"""Команди командного рядка: flask seed (створює таблиці, користувачів і каталог)."""

import click
from flask import Flask

from .demo_data import DEMO_BOOKS, DEMO_USERS, INVALID_RECORD
from .extensions import db
from .models import User
from .services import import_catalog_from_library


def register_cli(app: Flask) -> None:
    @app.cli.command("seed")
    def seed():
        """Створює таблиці та демонстраційні дані. Каталог імпортується через модуль 2."""
        db.create_all()
        for account in DEMO_USERS:
            if db.session.execute(db.select(User).where(User.email == account["email"])).scalar_one_or_none():
                continue
            user = User(email=account["email"], name=account["name"], is_admin=account["is_admin"])
            user.set_password(account["password"])
            db.session.add(user)
        db.session.commit()
        click.echo("Облікові записи: admin@bookshop.ua / admin123, reader@bookshop.ua / reader123")

        saved, rejected = import_catalog_from_library(DEMO_BOOKS + [INVALID_RECORD])
        click.echo(f"Збережено книг: {len(saved)}")
        for title, reason in rejected:
            click.echo(f"Відхилено «{title}»: {reason}")
