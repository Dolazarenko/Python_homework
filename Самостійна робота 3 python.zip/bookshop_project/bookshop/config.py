"""Конфігурація застосунку."""

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


class Config:
    SECRET_KEY = os.environ.get("BOOKSHOP_SECRET_KEY", "dev-only-change-me")
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "BOOKSHOP_DATABASE_URL", f"sqlite:///{BASE_DIR / 'bookshop.db'}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SESSION_COOKIE_HTTPONLY = True   # JavaScript не може прочитати cookie сесії
    SESSION_COOKIE_SAMESITE = "Lax"  # захист від CSRF для більшості міжсайтових запитів
    PER_PAGE = 6
    MAX_QTY_PER_ITEM = 10
    TESTING = False


class TestConfig(Config):
    TESTING = True
    SECRET_KEY = "test-secret"
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
