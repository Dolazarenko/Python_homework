"""Спільні розширення (об'єкт бази даних створюється тут, ініціалізується у фабриці)."""

from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()
