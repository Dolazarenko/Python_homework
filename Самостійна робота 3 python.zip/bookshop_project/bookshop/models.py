"""Моделі бази даних: користувачі, автори, книги, замовлення."""

from datetime import datetime

from werkzeug.security import check_password_hash, generate_password_hash

from .extensions import db


class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    name = db.Column(db.String(80), nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    is_admin = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False)

    orders = db.relationship("Order", back_populates="user", order_by="Order.id.desc()")

    def set_password(self, raw: str) -> None:
        """Зберігає хеш пароля, а не сам пароль."""
        self.password_hash = generate_password_hash(raw)

    def check_password(self, raw: str) -> bool:
        return check_password_hash(self.password_hash, raw)

    def to_dict(self) -> dict:
        return {"id": self.id, "email": self.email, "name": self.name, "is_admin": self.is_admin}


class Author(db.Model):
    __tablename__ = "authors"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    # Ключ для пошуку без урахування регістру (casefold). SQLite lower() не працює з кирилицею.
    name_key = db.Column(db.String(120), unique=True, nullable=False)

    books = db.relationship("Book", back_populates="author")


class Book(db.Model):
    __tablename__ = "books"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    title_key = db.Column(db.String(200), nullable=False, index=True)
    isbn = db.Column(db.String(13), unique=True, nullable=False)
    year = db.Column(db.Integer, nullable=False)
    price_cents = db.Column(db.Integer, nullable=False)   # ціна в копійках, щоб уникнути похибок float
    stock = db.Column(db.Integer, default=0, nullable=False)
    description = db.Column(db.Text, default="", nullable=False)
    author_id = db.Column(db.Integer, db.ForeignKey("authors.id"), nullable=False)

    author = db.relationship("Author", back_populates="books")
    order_items = db.relationship("OrderItem", back_populates="book")

    @property
    def price(self) -> float:
        return self.price_cents / 100

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "isbn": self.isbn,
            "year": self.year,
            "price": self.price,
            "stock": self.stock,
            "description": self.description,
            "author": self.author.name,
        }


class Order(db.Model):
    __tablename__ = "orders"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False)
    status = db.Column(db.String(20), default="new", nullable=False)
    total_cents = db.Column(db.Integer, default=0, nullable=False)

    user = db.relationship("User", back_populates="orders")
    items = db.relationship("OrderItem", back_populates="order", cascade="all, delete-orphan")

    @property
    def total(self) -> float:
        return self.total_cents / 100

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "status": self.status,
            "created_at": self.created_at.isoformat(timespec="seconds"),
            "total": self.total,
            "items": [item.to_dict() for item in self.items],
        }


class OrderItem(db.Model):
    __tablename__ = "order_items"

    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey("orders.id"), nullable=False)
    book_id = db.Column(db.Integer, db.ForeignKey("books.id"), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    unit_price_cents = db.Column(db.Integer, nullable=False)

    order = db.relationship("Order", back_populates="items")
    book = db.relationship("Book", back_populates="order_items")

    @property
    def subtotal_cents(self) -> int:
        return self.quantity * self.unit_price_cents

    def to_dict(self) -> dict:
        return {
            "book_id": self.book_id,
            "title": self.book.title,
            "quantity": self.quantity,
            "unit_price": self.unit_price_cents / 100,
        }
