"""Фабрика застосунку «Книгарня»."""

from flask import Flask, jsonify, request

from .config import Config
from .extensions import db


def create_app(config_class=Config) -> Flask:
    app = Flask(__name__)
    app.config.from_object(config_class)
    app.json.ensure_ascii = False
    db.init_app(app)

    from .api import api_bp
    from .web import web_bp
    from .cli import register_cli

    app.register_blueprint(web_bp)
    app.register_blueprint(api_bp, url_prefix="/api")
    register_cli(app)

    @app.errorhandler(404)
    def not_found(error):
        if request.path.startswith("/api/"):
            return jsonify({"error": "Ресурс не знайдено"}), 404
        return "<h1>404</h1><p>Сторінку не знайдено.</p>", 404

    @app.errorhandler(403)
    def forbidden(error):
        if request.path.startswith("/api/"):
            return jsonify({"error": "Недостатньо прав"}), 403
        return "<h1>403</h1><p>Недостатньо прав для цієї дії.</p>", 403

    return app
