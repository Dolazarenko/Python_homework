"""Бізнес-логіка книгарні.

Перевірка даних книг виконується правилами модуля 2 (пакет library), тобто
тими самими функціями, що й у системі управління бібліотекою.
"""

from flask import current_app
from sqlalchemy.exc import SQLAlchemyError

from library import LibraryService
from library.exceptions import LibraryError, ValidationError as LibraryValidationError
from library.validators import non_empty_str, normalize_isbn, valid_isbn, year_in_range

from .extensions import db
from .models import Author, Book, Order, OrderItem


class ShopError(Exception):
    """Помилка бізнес-логіки магазину (показується користувачу)."""


# ----- Книги -----

def _check(field: str, check, value, errors: dict) -> None:
    try:
        check(field, value)
    except LibraryValidationError as exc:
        errors[field] = str(exc)


def validate_book_data(data: dict) -> tuple[dict, dict]:
    """Перевіряє та очищає дані книги. Повертає (очищені дані, помилки)."""
    errors: dict[str, str] = {}
    clean: dict = {}

    title = data.get("title")
    _check("title", non_empty_str, title, errors)
    clean["title"] = (title or "").strip()

    isbn = data.get("isbn")
    _check("isbn", valid_isbn, isbn, errors)
    clean["isbn"] = normalize_isbn(isbn or "")

    year = data.get("year")
    if isinstance(year, str) and year.strip().isdigit():
        year = int(year)
    _check("year", year_in_range, year, errors)
    clean["year"] = year

    author = data.get("author")
    _check("author", non_empty_str, author, errors)
    clean["author"] = (author or "").strip()

    price = data.get("price")
    try:
        price_value = float(price)
    except (TypeError, ValueError):
        errors["price"] = "має бути числом"
    else:
        if price_value <= 0:
            errors["price"] = "має бути більшим за 0"
        else:
            clean["price_cents"] = round(price_value * 100)

    stock = data.get("stock", 0)
    try:
        stock_value = int(stock)
    except (TypeError, ValueError):
        errors["stock"] = "має бути цілим числом"
    else:
        if stock_value < 0:
            errors["stock"] = "не може бути від'ємним"
        else:
            clean["stock"] = stock_value

    clean["description"] = str(data.get("description", "") or "").strip()
    return clean, errors


def get_or_create_author(name: str) -> Author:
    key = name.strip().casefold()
    author = db.session.execute(
        db.select(Author).where(Author.name_key == key)
    ).scalar_one_or_none()
    if author is None:
        author = Author(name=name.strip(), name_key=key)
        db.session.add(author)
    return author


def search_books(query: str, offset: int, limit: int) -> tuple[int, list[Book]]:
    """Пошук за назвою або ISBN без урахування регістру. Повертає (загальна кількість, сторінка)."""
    statement = db.select(Book).order_by(Book.title)
    needle = query.strip().casefold()
    if needle:
        like = f"%{needle}%"
        statement = statement.where(Book.title_key.like(like) | Book.isbn.like(like))
    total = db.session.scalar(db.select(db.func.count()).select_from(statement.subquery()))
    books = db.session.scalars(statement.offset(offset).limit(limit)).all()
    return total, list(books)


def save_book(clean: dict, book: Book | None = None) -> Book:
    """Створює або оновлює книгу. Дубль ISBN дає ShopError."""
    duplicate = db.session.execute(
        db.select(Book).where(Book.isbn == clean["isbn"])
    ).scalar_one_or_none()
    if duplicate is not None and (book is None or duplicate.id != book.id):
        raise ShopError(f"Книга з ISBN {clean['isbn']} вже є у каталозі")

    # Автора знаходимо до створення книги: запит у сесії може скинути незавершені зміни
    author = get_or_create_author(clean["author"])
    if book is None:
        book = Book()
        db.session.add(book)
    book.title = clean["title"]
    book.title_key = clean["title"].casefold()
    book.isbn = clean["isbn"]
    book.year = clean["year"]
    book.price_cents = clean["price_cents"]
    book.stock = clean["stock"]
    book.description = clean["description"]
    book.author = author
    db.session.commit()
    return book


def import_catalog_from_library(records: list[dict]) -> tuple[list[Book], list[tuple[str, str]]]:
    """Імпортує каталог через сервіс модуля 2 і зберігає його в базі даних.

    Кожен запис спершу проходить LibraryService.import_book (правила модуля 2).
    Відхилені записи повертаються разом із причиною.

    Returns:
        (збережені книги, список (назва, причина) для відхилених записів).
    """
    service = LibraryService()
    extra_by_isbn: dict[str, dict] = {}
    rejected: list[tuple[str, str]] = []

    for record in records:
        try:
            lib_book = service.import_book(record)
        except LibraryError as exc:
            rejected.append((str(record.get("title", "")), str(exc)))
            continue
        extra_by_isbn[lib_book.isbn] = record

    saved: list[Book] = []
    for lib_book in service.books.all():
        record = extra_by_isbn[lib_book.isbn]
        if db.session.execute(db.select(Book).where(Book.isbn == lib_book.isbn)).scalar_one_or_none():
            rejected.append((lib_book.title, "книга з таким ISBN вже є в базі"))
            continue
        clean, _ = validate_book_data({**record, "author": lib_book.author.name})
        saved.append(save_book(clean))
    return saved, rejected


# ----- Кошик (зберігається в session) -----

def cart_add(cart: dict, book: Book, quantity: int) -> dict:
    """Додає книгу в кошик. Перевіряє ліміт кількості і залишок на складі."""
    max_qty = current_app.config["MAX_QTY_PER_ITEM"]
    if quantity < 1 or quantity > max_qty:
        raise ShopError(f"Кількість має бути від 1 до {max_qty}")
    new_qty = cart.get(str(book.id), 0) + quantity
    if new_qty > max_qty:
        raise ShopError(f"Не більше {max_qty} примірників однієї книги")
    if new_qty > book.stock:
        raise ShopError(f"На складі лише {book.stock} прим. книги «{book.title}»")
    cart = dict(cart)
    cart[str(book.id)] = new_qty
    return cart


def cart_summary(cart: dict) -> dict:
    """Повертає позиції кошика з книгами та підсумком. Видалені книги пропускає."""
    items = []
    total_cents = 0
    for book_id, quantity in cart.items():
        book = db.session.get(Book, int(book_id))
        if book is None:
            continue
        subtotal = quantity * book.price_cents
        total_cents += subtotal
        items.append({"book": book, "quantity": quantity, "subtotal": subtotal / 100})
    return {"lines": items, "count": sum(i["quantity"] for i in items), "total": total_cents / 100}


# ----- Замовлення -----

def create_order(user, quantities: dict[int, int]) -> Order:
    """Оформлює замовлення: перевіряє склад, списує книги, зберігає позиції.

    Усі перевірки виконуються до змін, тож помилка не залишає склад у неузгодженому стані.
    """
    if not quantities:
        raise ShopError("Кошик порожній")

    books: dict[int, Book] = {}
    for book_id, quantity in quantities.items():
        if quantity < 1:
            raise ShopError("Кількість має бути більшою за 0")
        book = db.session.get(Book, book_id)
        if book is None:
            raise ShopError(f"Книгу з id={book_id} більше немає в каталозі")
        if quantity > book.stock:
            raise ShopError(f"Недостатньо «{book.title}» на складі: доступно {book.stock}")
        books[book_id] = book

    order = Order(user=user)
    for book_id, quantity in quantities.items():
        book = books[book_id]
        book.stock -= quantity
        order.items.append(OrderItem(book=book, quantity=quantity,
                                     unit_price_cents=book.price_cents))
    order.total_cents = sum(item.subtotal_cents for item in order.items)
    db.session.add(order)
    try:
        db.session.commit()
    except SQLAlchemyError:
        db.session.rollback()
        raise ShopError("Не вдалося зберегти замовлення, спробуйте ще раз")
    return order
