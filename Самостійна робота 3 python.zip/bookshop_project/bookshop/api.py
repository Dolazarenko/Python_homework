"""REST API (JSON). Авторизація — через session-cookie, що видається на /api/auth/login.

Коди відповідей:
  200 — успіх; 201 — створено (з Location); 204 — видалено без тіла
  400 — некоректні дані; 401 — не авторизовано; 403 — недостатньо прав
  404 — ресурс не знайдено; 409 — конфлікт (дубль ISBN або зайнятий email)
"""

import math

from flask import Blueprint, abort, jsonify, request, session, url_for

from .auth import admin_required, current_user, login_required
from .extensions import db
from .models import Book, Order, User
from .services import ShopError, create_order, save_book, search_books, validate_book_data

api_bp = Blueprint("api", __name__)


def json_object() -> dict:
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        abort(400)
    return data


def error(message: str, status: int, details=None):
    body = {"error": message}
    if details is not None:
        body["details"] = details
    return jsonify(body), status


# ----- Авторизація -----

@api_bp.route("/auth/login", methods=["POST"])
def api_login():
    data = json_object()
    email = str(data.get("email", "")).strip().lower()
    user = db.session.execute(db.select(User).where(User.email == email)).scalar_one_or_none()
    if user is None or not user.check_password(str(data.get("password", ""))):
        return error("Невірний e-mail або пароль", 401)
    session["user_id"] = user.id
    return jsonify(user.to_dict()), 200


@api_bp.route("/auth/logout", methods=["POST"])
def api_logout():
    session.pop("user_id", None)
    return "", 204


@api_bp.route("/auth/me")
@login_required
def api_me():
    return jsonify(current_user().to_dict()), 200


# ----- Книги -----

@api_bp.route("/books", methods=["GET"])
def api_books_list():
    """Список книг: ?q=пошук&page=1&per_page=10."""
    query = request.args.get("q", "").strip()
    page = request.args.get("page", 1, type=int)
    per_page = request.args.get("per_page", 10, type=int)
    if page < 1 or not 1 <= per_page <= 50:
        return error("Некоректні параметри пагінації", 400,
                     {"page": "має бути від 1", "per_page": "від 1 до 50"})

    total, books = search_books(query, (page - 1) * per_page, per_page)
    return jsonify({
        "count": total,
        "page": page,
        "per_page": per_page,
        "pages": max(1, math.ceil(total / per_page)),
        "books": [b.to_dict() for b in books],
    }), 200


@api_bp.route("/books/<int:book_id>", methods=["GET"])
def api_book_detail(book_id: int):
    return jsonify(db.get_or_404(Book, book_id).to_dict()), 200


@api_bp.route("/books", methods=["POST"])
@admin_required
def api_book_create():
    clean, errors = validate_book_data(json_object())
    if errors:
        return error("Помилка валідації", 400, errors)
    try:
        book = save_book(clean)
    except ShopError as exc:
        return error(str(exc), 409)
    response = jsonify(book.to_dict())
    response.status_code = 201
    response.headers["Location"] = url_for("api.api_book_detail", book_id=book.id)
    return response


@api_bp.route("/books/<int:book_id>", methods=["PUT"])
@admin_required
def api_book_update(book_id: int):
    book = db.get_or_404(Book, book_id)
    clean, errors = validate_book_data(json_object())
    if errors:
        return error("Помилка валідації", 400, errors)
    try:
        save_book(clean, book)
    except ShopError as exc:
        return error(str(exc), 409)
    return jsonify(book.to_dict()), 200


@api_bp.route("/books/<int:book_id>", methods=["DELETE"])
@admin_required
def api_book_delete(book_id: int):
    book = db.get_or_404(Book, book_id)
    if book.order_items:
        return error("Книга є у замовленнях і не може бути видалена", 409)
    db.session.delete(book)
    db.session.commit()
    return "", 204


# ----- Замовлення -----

@api_bp.route("/orders", methods=["GET"])
@login_required
def api_orders_list():
    return jsonify({"orders": [o.to_dict() for o in current_user().orders]}), 200


@api_bp.route("/orders/<int:order_id>", methods=["GET"])
@login_required
def api_order_detail(order_id: int):
    order = db.session.get(Order, order_id)
    if order is None or order.user_id != current_user().id:
        return error("Замовлення не знайдено", 404)
    return jsonify(order.to_dict()), 200


@api_bp.route("/orders", methods=["POST"])
@login_required
def api_order_create():
    """Тіло: {"items": [{"book_id": 1, "quantity": 2}, ...]}."""
    data = json_object()
    items = data.get("items")
    if not isinstance(items, list) or not items:
        return error("Очікується непорожній список items", 400)

    quantities: dict[int, int] = {}
    problems = []
    for index, item in enumerate(items):
        book_id = item.get("book_id") if isinstance(item, dict) else None
        quantity = item.get("quantity", 1) if isinstance(item, dict) else None
        if not isinstance(book_id, int) or isinstance(book_id, bool):
            problems.append({"index": index, "book_id": "має бути цілим числом"})
        elif not isinstance(quantity, int) or isinstance(quantity, bool) or quantity < 1:
            problems.append({"index": index, "quantity": "має бути цілим числом від 1"})
        else:
            quantities[book_id] = quantities.get(book_id, 0) + quantity
    if problems:
        return error("Помилка валідації", 400, problems)

    try:
        order = create_order(current_user(), quantities)
    except ShopError as exc:
        return error(str(exc), 400)
    response = jsonify(order.to_dict())
    response.status_code = 201
    response.headers["Location"] = url_for("api.api_order_detail", order_id=order.id)
    return response
