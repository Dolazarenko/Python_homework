"""Авторизація: поточний користувач із session, декоратори доступу для HTML і API."""

from functools import wraps

from flask import flash, jsonify, redirect, request, session, url_for

from .extensions import db
from .models import User


def current_user() -> User | None:
    user_id = session.get("user_id")
    return db.session.get(User, user_id) if user_id else None


def login_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        if current_user() is None:
            if request.path.startswith("/api/"):
                return jsonify({"error": "Потрібна авторизація"}), 401
            flash("Увійдіть, щоб продовжити")
            return redirect(url_for("web.login", next=request.path))
        return view(*args, **kwargs)
    return wrapper


def admin_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        user = current_user()
        if user is None:
            if request.path.startswith("/api/"):
                return jsonify({"error": "Потрібна авторизація"}), 401
            flash("Увійдіть, щоб продовжити")
            return redirect(url_for("web.login", next=request.path))
        if not user.is_admin:
            if request.path.startswith("/api/"):
                return jsonify({"error": "Недостатньо прав"}), 403
            return "<h1>403</h1><p>Лише для адміністраторів.</p>", 403
        return view(*args, **kwargs)
    return wrapper
