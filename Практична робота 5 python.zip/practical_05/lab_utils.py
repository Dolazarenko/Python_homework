"""Спільні допоміжні функції практичних скриптів.

Забезпечують коректний вивід українських літер та символів ✓ ✗ ⚠
і єдине оформлення заголовків, зручне для скріншотів.
"""

import os
import sys

WIDTH = 72
OK = "✓"
FAIL = "✗"
WARN = "⚠"


def setup_console() -> None:
    """Перемикає консоль і потоки виводу на UTF-8.

    У Windows також виконується chcp 65001: без неї кирилиця
    у PowerShell та cmd відображається як набір випадкових символів.
    """
    if os.name == "nt":
        os.system("chcp 65001 > nul")
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")


def title(text: str) -> None:
    """Виводить заголовок у рамці на всю ширину консолі для скріншота."""
    print("=" * WIDTH)
    print(text.center(WIDTH).rstrip())
    print("=" * WIDTH)


def section(text: str) -> None:
    """Виводить заголовок розділу з відступом зверху."""
    print(f"\n--- {text} ---")


def mark(flag: bool) -> str:
    """Повертає символ успіху або невдачі."""
    return OK if flag else FAIL
