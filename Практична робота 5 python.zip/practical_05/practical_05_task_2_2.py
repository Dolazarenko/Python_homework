"""Аналізатор конфігурації Django-проєкту (завдання 2.2).

Файл settings.py не виконується, а розбирається модулем ast,
тому аналіз безпечний і не потребує встановленого Django.

Запуск:
    python practical_05_task_2_2.py                      аналізує mysite/mysite/settings.py
    python practical_05_task_2_2.py ШЛЯХ/ДО/settings.py  аналізує вказаний файл
"""

import ast
import os
import sys

from lab_utils import FAIL, OK, WARN, section, setup_console, title

DEFAULT_SETTINGS = os.path.join("mysite", "mysite", "settings.py")
DB_NAMES = {"sqlite3": "SQLite", "postgresql": "PostgreSQL", "mysql": "MySQL", "oracle": "Oracle"}


def _load_tree(settings_path: str) -> ast.Module | None:
    """Розбирає файл у синтаксичне дерево. Повертає None, якщо файл зламаний."""
    with open(settings_path, encoding="utf-8") as f:
        source = f.read()
    try:
        return ast.parse(source, filename=settings_path)
    except SyntaxError as exc:
        print(f"{FAIL} Синтаксична помилка у {settings_path}: {exc}")
        return None


def _find_assignment(tree: ast.Module, name: str) -> ast.expr | None:
    """Знаходить вираз присвоєння верхнього рівня, наприклад DEBUG = True.

    Якщо присвоєння повторюється, береться останнє, як це робить Python.
    """
    value = None
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == name:
                    value = node.value
    return value


def _literal(node: ast.expr | None, default=None):
    """Повертає Python-значення вузла, якщо це літерал; інакше текст виразу."""
    if node is None:
        return default
    try:
        return ast.literal_eval(node)
    except ValueError:
        return ast.unparse(node)


def _database_engine(tree: ast.Module) -> str:
    """Витягує ENGINE бази 'default' зі словника DATABASES."""
    node = _find_assignment(tree, "DATABASES")
    if not isinstance(node, ast.Dict):
        return "не знайдено"
    for key, value in zip(node.keys, node.values):
        is_default = isinstance(key, ast.Constant) and key.value == "default"
        if is_default and isinstance(value, ast.Dict):
            for inner_key, inner_value in zip(value.keys, value.values):
                if isinstance(inner_key, ast.Constant) and inner_key.value == "ENGINE":
                    engine = str(_literal(inner_value, ""))
                    short = engine.rsplit(".", 1)[-1]
                    return f"{engine} ({DB_NAMES.get(short, short)})"
    return "не знайдено"


def analyze_settings(settings_path: str) -> dict:
    """Аналізує файл settings.py і повертає ключові параметри.

    Args:
        settings_path: шлях до файлу settings.py.

    Returns:
        Словник з ключами DEBUG, INSTALLED_APPS, DATABASES, LANGUAGE_CODE,
        TIME_ZONE, ALLOWED_HOSTS, SECRET_KEY. Порожній словник, якщо файл зламаний.
    """
    tree = _load_tree(settings_path)
    if tree is None:
        return {}

    secret = _find_assignment(tree, "SECRET_KEY")
    if secret is None:
        secret_source = "не задано"
    elif "environ" in ast.unparse(secret):
        secret_source = "зі змінної оточення"
    else:
        secret_source = "захардкоджений у коді"

    return {
        "DEBUG": _literal(_find_assignment(tree, "DEBUG"), "не задано"),
        "INSTALLED_APPS": _literal(_find_assignment(tree, "INSTALLED_APPS"), []),
        "DATABASES": _database_engine(tree),
        "LANGUAGE_CODE": _literal(_find_assignment(tree, "LANGUAGE_CODE"), "не задано"),
        "TIME_ZONE": _literal(_find_assignment(tree, "TIME_ZONE"), "не задано"),
        "ALLOWED_HOSTS": _literal(_find_assignment(tree, "ALLOWED_HOSTS"), []),
        "SECRET_KEY": secret_source,
    }


def check_security(settings_path: str) -> list[str]:
    """Перевіряє базові правила безпеки конфігурації.

    Правила:
        1. DEBUG має бути False у production.
        2. SECRET_KEY не має бути захардкоджений у коді.
        3. ALLOWED_HOSTS має бути заповнений у production.

    Args:
        settings_path: шлях до файлу settings.py.

    Returns:
        Список попереджень. Порожній, якщо порушень немає.
    """
    tree = _load_tree(settings_path)
    if tree is None:
        return ["Файл не вдалося розібрати, перевірка неможлива"]

    warnings = []

    if _literal(_find_assignment(tree, "DEBUG"), False) is True:
        warnings.append("DEBUG = True: у production вимкніть, інакше користувачі бачитимуть внутрішні помилки")

    secret = _find_assignment(tree, "SECRET_KEY")
    if isinstance(secret, ast.Constant):
        warnings.append("SECRET_KEY захардкоджений у коді: читайте його з os.environ")
    elif secret is not None and "insecure" in ast.unparse(secret):
        warnings.append("SECRET_KEY має небезпечне запасне значення: задайте змінну DJANGO_SECRET_KEY")

    if not _literal(_find_assignment(tree, "ALLOWED_HOSTS"), []):
        warnings.append("ALLOWED_HOSTS порожній: для production вкажіть дозволені домени")

    return warnings


def main() -> int:
    setup_console()
    settings_path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_SETTINGS

    title("АНАЛІЗ КОНФІГУРАЦІЇ DJANGO")
    print(f"Файл: {settings_path}")
    if not os.path.exists(settings_path):
        print(f"{FAIL} Файл не знайдено. Спершу створіть проєкт: django-admin startproject mysite")
        return 1

    config = analyze_settings(settings_path)
    if not config:
        return 1

    section("Ключові параметри")
    for key, value in config.items():
        if key != "INSTALLED_APPS":
            print(f"  {key:<15} {value}")

    apps = config["INSTALLED_APPS"]
    section(f"INSTALLED_APPS ({len(apps)} додатків)")
    for app in apps:
        print(f"  - {app}")

    section("Перевірка безпеки")
    warnings = check_security(settings_path)
    if warnings:
        for warning in warnings:
            print(f"  {WARN} {warning}")
        print(f"\nЗнайдено попереджень: {len(warnings)}")
    else:
        print(f"  Попереджень не знайдено {OK}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
