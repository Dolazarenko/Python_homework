"""Скрипт перевірки середовища розробки (завдання 1.1).

Запуск: python practical_05_task_1_1.py
"""

import importlib
import sys
from importlib.metadata import PackageNotFoundError, version

from lab_utils import FAIL, OK, WARN, mark, section, setup_console, title

MIN_PYTHON = (3, 10)
PACKAGES = ["django", "flask"]


def check_python_version() -> bool:
    """Перевіряє версію Python (не нижче 3.10) і стан віртуального середовища.

    Returns:
        True, якщо версія Python достатня.
    """
    v = sys.version_info
    print(f"Python {v.major}.{v.minor}.{v.micro}")
    print(f"Інтерпретатор: {sys.executable}")
    in_venv = sys.prefix != sys.base_prefix
    print(f"Віртуальне середовище активне: {'так' if in_venv else 'ні'}")
    if (v.major, v.minor) < MIN_PYTHON:
        print(f"{WARN} Потрібна версія Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]} або новіша")
        return False
    return True


def check_package(package_name: str) -> bool:
    """Перевіряє, чи встановлено пакет, і виводить його версію.

    Args:
        package_name: назва пакета для перевірки.

    Returns:
        True, якщо пакет встановлено і його можна імпортувати.
    """
    try:
        importlib.import_module(package_name)
        pkg_version = version(package_name)
    except (ImportError, PackageNotFoundError):
        print(f"  {package_name:<10} НЕ ВСТАНОВЛЕНО {FAIL}")
        return False
    print(f"  {package_name:<10} {pkg_version:<10} {OK}")
    return True


def main() -> int:
    setup_console()
    title("ПЕРЕВІРКА СЕРЕДОВИЩА РОЗРОБКИ")

    section("Python")
    python_ok = check_python_version()

    section("Пакети")
    results = {pkg: check_package(pkg) for pkg in PACKAGES}
    missing = [pkg for pkg, found in results.items() if not found]

    section("Підсумок")
    print(f"Встановлено пакетів: {len(PACKAGES) - len(missing)} з {len(PACKAGES)}")
    if missing:
        print(f"{FAIL} Відсутні: {', '.join(missing)}")
        print(f"Встановити: python -m pip install {' '.join(missing)}")
    else:
        print(f"{OK} Усі пакети на місці")

    all_ok = python_ok and not missing
    print(f"\nРезультат: {mark(all_ok)}")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
