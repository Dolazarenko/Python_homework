"""Генератор requirements.txt та перевірка відтворюваності середовища (завдання 1.2).

Запуск:
    python practical_05_task_1_2.py                    створити файл (якщо його немає) і перевірити
    python practical_05_task_1_2.py --regenerate       перезаписати requirements.txt поточними пакетами
    python practical_05_task_1_2.py --compare PATH     порівняти з іншим середовищем
                                                       (PATH — python усередині іншого venv)
"""

import argparse
import json
import os
import subprocess
import sys
from importlib.metadata import PackageNotFoundError, version

from lab_utils import FAIL, OK, mark, section, setup_console, title

REQUIREMENTS_FILE = "requirements.txt"
SYSTEM_PACKAGES = {"pip", "setuptools", "wheel", "pkg-resources"}


def normalize(name: str) -> str:
    """Приводить назву пакета до єдиного вигляду (PEP 503): нижній регістр і '-'."""
    return name.lower().replace("_", "-")


def get_installed_packages(python: str = sys.executable) -> list[dict]:
    """Повертає встановлені пакети з версіями, відсортовані за назвою.

    Args:
        python: інтерпретатор, для якого потрібен список пакетів.

    Returns:
        Список словників {'name': ..., 'version': ...}.

    Raises:
        RuntimeError: якщо pip не вдалося виконати або його вивід не розпарсено.
    """
    result = subprocess.run(
        [python, "-m", "pip", "list", "--format=json"],
        capture_output=True, text=True, encoding="utf-8",
    )
    if result.returncode != 0:
        raise RuntimeError(f"pip завершився з помилкою: {result.stderr.strip()}")
    try:
        packages = json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Не вдалося розпарсити вивід pip: {exc}") from exc
    return sorted(packages, key=lambda p: normalize(p["name"]))


def _user_packages(python: str = sys.executable) -> dict[str, str]:
    """Повертає {назва: версія} без системних пакетів (pip, setuptools, wheel)."""
    return {
        normalize(p["name"]): p["version"]
        for p in get_installed_packages(python)
        if normalize(p["name"]) not in SYSTEM_PACKAGES
    }


def generate_requirements(packages: list[dict], filename: str = REQUIREMENTS_FILE) -> int:
    """Записує пакети у файл requirements.txt у форматі package==version.

    Args:
        packages: список словників з ключами 'name' та 'version'.
        filename: ім'я файлу для запису.

    Returns:
        Кількість записаних пакетів.
    """
    lines = [
        "# Залежності практичної роботи №5",
        "# Відтворити: python -m pip install -r requirements.txt",
    ]
    written = 0
    for pkg in packages:
        if normalize(pkg["name"]) in SYSTEM_PACKAGES:
            continue
        lines.append(f"{pkg['name']}=={pkg['version']}")
        written += 1
    with open(filename, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return written


def read_requirements(filename: str) -> dict[str, str]:
    """Читає requirements.txt і повертає {назва: очікувана версія}.

    Порожні рядки та коментарі пропускаються.
    """
    requirements = {}
    with open(filename, encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#") or "==" not in line:
                continue
            name, _, expected = line.partition("==")
            requirements[normalize(name.strip())] = expected.strip()
    return requirements


def verify_requirements(filename: str = REQUIREMENTS_FILE) -> bool:
    """Перевіряє, чи всі пакети з requirements.txt встановлені з потрібними версіями.

    Args:
        filename: шлях до файлу requirements.txt.

    Returns:
        True, якщо всі залежності задоволені.
    """
    if not os.path.exists(filename):
        print(f"{FAIL} Файл {filename} не знайдено.")
        print("  Створіть його: python practical_05_task_1_2.py --regenerate")
        return False

    requirements = read_requirements(filename)
    all_ok = True
    for name, expected in requirements.items():
        try:
            installed = version(name)
        except PackageNotFoundError:
            print(f"  {name:<22} очікується {expected}, НЕ ВСТАНОВЛЕНО {FAIL}")
            all_ok = False
            continue
        if installed != expected:
            print(f"  {name:<22} очікується {expected}, встановлено {installed} {FAIL}")
            all_ok = False
    if all_ok:
        print(f"  Усі {len(requirements)} залежностей відповідають файлу {OK}")
    return all_ok


def compare_environments(other_python: str) -> bool:
    """Порівнює набір пакетів поточного середовища з іншим інтерпретатором.

    Args:
        other_python: шлях до python іншого venv.

    Returns:
        True, якщо набори пакетів і їх версії збігаються.
    """
    current = _user_packages()
    other = _user_packages(other_python)

    print(f"Пакетів у поточному середовищі: {len(current)}")
    print(f"Пакетів в іншому середовищі:    {len(other)}")

    only_here = sorted(set(current) - set(other))
    only_there = sorted(set(other) - set(current))
    changed = sorted(n for n in set(current) & set(other) if current[n] != other[n])

    if not (only_here or only_there or changed):
        print(f"Набори пакетів і версії ідентичні {OK}")
        return True

    for name in only_here:
        print(f"  лише в поточному: {name}=={current[name]} {FAIL}")
    for name in only_there:
        print(f"  лише в іншому:    {name}=={other[name]} {FAIL}")
    for name in changed:
        print(f"  різні версії: {name} {current[name]} / {other[name]} {FAIL}")
    return False


def main() -> int:
    parser = argparse.ArgumentParser(description="Відтворюваність середовища (практична №5, завдання 1.2)")
    parser.add_argument("--regenerate", action="store_true", help="перезаписати requirements.txt")
    parser.add_argument("--compare", metavar="PATH", help="python іншого venv для порівняння")
    args = parser.parse_args()

    setup_console()
    title("ВІДТВОРЮВАНІСТЬ СЕРЕДОВИЩА")

    section("Поточне середовище")
    try:
        packages = [p for p in get_installed_packages()
                    if normalize(p["name"]) not in SYSTEM_PACKAGES]
    except RuntimeError as exc:
        print(f"{FAIL} {exc}")
        return 1
    print(f"Знайдено пакетів без системних: {len(packages)}")
    for pkg in packages[:10]:
        print(f"  {pkg['name']}=={pkg['version']}")
    if len(packages) > 10:
        print(f"  ... та ще {len(packages) - 10}")

    section("requirements.txt")
    if args.regenerate or not os.path.exists(REQUIREMENTS_FILE):
        written = generate_requirements(packages)
        print(f"Файл {REQUIREMENTS_FILE} створено, пакетів: {written} {OK}")
    else:
        print(f"Файл {REQUIREMENTS_FILE} вже є, перевіряємо його вміст")

    section("Перевірка залежностей")
    ok = verify_requirements()
    print(f"Результат: {mark(ok)}")

    if args.compare:
        section("Порівняння з іншим середовищем")
        print(f"Інтерпретатор: {args.compare}")
        same = compare_environments(args.compare)
        print(f"Результат: {mark(same)}")
        ok = ok and same

    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
