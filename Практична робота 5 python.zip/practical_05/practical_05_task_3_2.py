"""Порівняльний аналіз структури Django- та Flask-проєктів (завдання 3.2).

Запуск (з каталогу practical_05):
    python practical_05_task_3_2.py
"""

import os
import sys

from lab_utils import section, setup_console, title

DJANGO_PATH = "mysite"
FLASK_PATH = "myflaskapp"
IGNORED_NAMES = {"__pycache__", "venv", "venv2", ".venv", ".git", ".idea", ".vscode", "db.sqlite3"}
IGNORED_SUFFIXES = (".pyc", ".pyo")


def is_ignored(name: str) -> bool:
    """Чи є файл або каталог службовим (кеш, віртуальне середовище, база даних)."""
    return name in IGNORED_NAMES or name.endswith(IGNORED_SUFFIXES)


def scan_directory(path: str, prefix: str = "") -> list[str]:
    """Рекурсивно сканує каталог і повертає його структуру у вигляді дерева.

    Args:
        path: шлях до каталогу.
        prefix: відступ для форматування дерева.

    Returns:
        Список рядків зі структурою каталогу.
    """
    tree = []
    try:
        entries = sorted(e for e in os.listdir(path) if not is_ignored(e))
    except OSError:
        return tree

    for index, name in enumerate(entries):
        is_last = index == len(entries) - 1
        connector = "└── " if is_last else "├── "
        full_path = os.path.join(path, name)
        if os.path.isdir(full_path):
            tree.append(f"{prefix}{connector}{name}/")
            tree.extend(scan_directory(full_path, prefix + ("    " if is_last else "│   ")))
        else:
            tree.append(f"{prefix}{connector}{name}")
    return tree


def analyze_project(path: str) -> dict:
    """Аналізує проєкт і збирає статистику.

    Args:
        path: кореневий каталог проєкту.

    Returns:
        Словник: кількість файлів .py, .html, .css, загальний розмір у байтах
        і список каталогів відносно кореня проєкту.
    """
    stats = {
        "py_files": 0,
        "html_files": 0,
        "css_files": 0,
        "total_size": 0,
        "directories": [],
    }
    for root, dirs, files in os.walk(path):
        dirs[:] = sorted(d for d in dirs if not is_ignored(d))
        rel_root = os.path.relpath(root, path)
        if rel_root != ".":
            stats["directories"].append(rel_root.replace(os.sep, "/"))

        for name in files:
            if is_ignored(name):
                continue
            stats["total_size"] += os.path.getsize(os.path.join(root, name))
            ext = os.path.splitext(name)[1].lower()
            if ext == ".py":
                stats["py_files"] += 1
            elif ext == ".html":
                stats["html_files"] += 1
            elif ext == ".css":
                stats["css_files"] += 1
    return stats


def print_table(rows: list[tuple[str, str, str]]) -> None:
    """Виводить порівняльну таблицю з рамкою."""
    headers = ("Характеристика", "Django", "Flask")
    widths = [max(len(str(row[i])) for row in [headers, *rows]) for i in range(3)]
    border = "+" + "+".join("-" * (w + 2) for w in widths) + "+"

    def fmt(row):
        return "| " + " | ".join(str(cell).ljust(w) for cell, w in zip(row, widths)) + " |"

    print(border)
    print(fmt(headers))
    print(border)
    for row in rows:
        print(fmt(row))
    print(border)


def compare_projects(django_path: str, flask_path: str):
    """Порівнює два проєкти: виводить їхні дерева та таблицю відмінностей.

    Args:
        django_path: шлях до Django-проєкту.
        flask_path: шлях до Flask-проєкту.
    """
    title("ПОРІВНЯННЯ СТРУКТУРИ ПРОЄКТІВ")

    section(f"Django: {django_path}/")
    print(f"{django_path}/")
    for line in scan_directory(django_path):
        print(line)
    django_stats = analyze_project(django_path)

    section(f"Flask: {flask_path}/")
    print(f"{flask_path}/")
    for line in scan_directory(flask_path):
        print(line)
    flask_stats = analyze_project(flask_path)

    section("Порівняльна таблиця")
    rows = [
        ("Файли .py", django_stats["py_files"], flask_stats["py_files"]),
        ("Файли .html", django_stats["html_files"], flask_stats["html_files"]),
        ("Файли .css", django_stats["css_files"], flask_stats["css_files"]),
        ("Каталоги", len(django_stats["directories"]), len(flask_stats["directories"])),
        ("Розмір (байт)", django_stats["total_size"], flask_stats["total_size"]),
    ]
    print_table([(name, str(d), str(f)) for name, d, f in rows])


def main() -> int:
    setup_console()
    for path in (DJANGO_PATH, FLASK_PATH):
        if not os.path.isdir(path):
            print(f"Каталог '{path}' не знайдено. Спершу виконайте попередні завдання.")
            return 1
    compare_projects(DJANGO_PATH, FLASK_PATH)
    return 0


if __name__ == "__main__":
    sys.exit(main())
