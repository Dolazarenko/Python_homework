"""Конфігурація Flask-додатка."""

import os


class Config:
    """Базова конфігурація."""

    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-only-change-me')
    DEBUG = False


class DevelopmentConfig(Config):
    """Конфігурація для розробки."""

    DEBUG = True


class ProductionConfig(Config):
    """Конфігурація для production. SECRET_KEY береться лише зі змінної оточення."""

    DEBUG = False
    SECRET_KEY = os.environ.get('SECRET_KEY')


config_by_name = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig,
}
