"""Головний файл Flask-додатка."""

from importlib.metadata import version

from flask import Flask, jsonify, request
from markupsafe import escape

from config import config_by_name


def create_app(config_name: str = 'default') -> Flask:
    """Фабрика додатка Flask.

    Args:
        config_name: ім'я конфігурації ('development', 'production' або 'default').

    Returns:
        Налаштований екземпляр Flask.

    Raises:
        ValueError: якщо конфігурації з таким ім'ям немає.
        RuntimeError: якщо в production не задано SECRET_KEY.
    """
    if config_name not in config_by_name:
        options = ', '.join(sorted(config_by_name))
        raise ValueError(f"Невідома конфігурація '{config_name}'. Доступні: {options}")

    app = Flask(__name__)
    app.config.from_object(config_by_name[config_name])
    app.json.ensure_ascii = False  # кирилиця в JSON читається без \u-кодів

    if not app.config.get('SECRET_KEY'):
        raise RuntimeError('Для production задайте змінну оточення SECRET_KEY')

    register_routes(app)
    return app


def register_routes(app: Flask):
    """Реєструє маршрути додатка."""

    @app.route('/')
    def index():
        """Головна сторінка."""
        return (
            "<!DOCTYPE html><html lang='uk'><head><meta charset='utf-8'>"
            "<title>Головна</title>"
            "<link rel='stylesheet' href='/static/style.css'></head><body>"
            "<h1>Практична робота №5: Flask</h1>"
            "<p>Мікрофреймворк Flask, створений через фабрику додатка.</p>"
            "<ul>"
            "<li><a href='/about'>Про додаток</a></li>"
            "<li><a href='/api/info'>Інформація у JSON</a></li>"
            "<li><a href='/greet/Гість'>Привітання за адресою</a></li>"
            "</ul></body></html>"
        )

    @app.route('/about')
    def about():
        """Сторінка 'Про додаток'."""
        return (
            "<!DOCTYPE html><html lang='uk'><head><meta charset='utf-8'>"
            "<title>Про додаток</title>"
            "<link rel='stylesheet' href='/static/style.css'></head><body>"
            "<h1>Про додаток</h1>"
            "<p>Це Flask-проєкт з рекомендованою структурою: app.py, config.py, "
            "static/ та templates/.</p>"
            "</body></html>"
        )

    @app.route('/api/info')
    def api_info():
        """API-ендпоінт з інформацією у JSON."""
        routes = sorted(
            rule.rule for rule in app.url_map.iter_rules() if rule.endpoint != 'static'
        )
        return jsonify({
            'framework': 'Flask',
            'version': version('flask'),
            'debug': app.debug,
            'routes': routes,
        })

    @app.route('/greet')
    @app.route('/greet/<name>')
    def greet(name=None):
        """Маршрут з динамічним параметром (/greet/Олена) або query-параметром (/greet?name=Олена)."""
        if not name:
            name = request.args.get('name', 'Гість')
        return f"<h1>Привіт, {escape(name)}!</h1>"


if __name__ == '__main__':
    application = create_app('development')
    application.run(debug=True, port=5000)
