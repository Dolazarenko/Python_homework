"""Views додатка pages."""

from django.http import HttpResponse
from django.utils.html import escape

COURSE_NAME = "Веб-розробка на Python"
LAB_NUMBER = 5
STUDENT_NAME = "Лазаренко Данило"


def _page(title: str, body: str) -> HttpResponse:
    """Загортає вміст у мінімальний HTML-документ."""
    html = (
        "<!DOCTYPE html>\n"
        "<html lang='uk'>\n"
        "<head><meta charset='utf-8'><title>" + escape(title) + "</title></head>\n"
        "<body>\n" + body + "\n</body>\n</html>"
    )
    return HttpResponse(html)


def index(request):
    """Головна сторінка."""
    body = (
        "<h1>Практична робота №5: Django</h1>\n"
        "<p>Це головна сторінка додатка pages, створеного командою startapp.</p>\n"
        "<ul>\n"
        "  <li><a href='/about/'>Про проєкт</a></li>\n"
        "  <li><a href='/contact/'>Контакт</a></li>\n"
        "  <li><a href='/admin/'>Адмін-панель</a></li>\n"
        "</ul>"
    )
    return _page("Головна", body)


def about(request):
    """Сторінка 'Про проєкт'."""
    body = (
        "<h1>Про проєкт</h1>\n"
        f"<p>Курс: {escape(COURSE_NAME)}</p>\n"
        f"<p>Практична робота: №{LAB_NUMBER}</p>\n"
        f"<p>Студент: {escape(STUDENT_NAME)}</p>"
    )
    return _page("Про проєкт", body)


def contact(request):
    """Контактна сторінка. Обробляє GET-параметр name, наприклад /contact/?name=Олена."""
    name = request.GET.get("name", "").strip()
    if name:
        body = f"<h1>Привіт, {escape(name)}!</h1>"
    else:
        body = (
            "<h1>Контакт</h1>\n"
            "<p>Щоб отримати персональне привітання, додайте ?name=ваше_ім'я до адреси.</p>"
        )
    return _page("Контакт", body)
